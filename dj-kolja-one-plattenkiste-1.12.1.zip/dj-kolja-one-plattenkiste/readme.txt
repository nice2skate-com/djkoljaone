=== DJ KOLJA ONE Plattenkiste ===
Songs aus der Mediathek für das DJ-Pult auf der Seite „Meine Musik“.

1. MP3 hochladen (Medien → Datei hinzufügen).
2. In den Datei-Details „Plattenkiste: Genre“ ausfüllen (oder Genre im MP3 hinterlegen).
3. BPM und Tonart (Camelot, z. B. 8A) werden beim Hochladen automatisch erkannt, sobald die Mediathek im Browser geöffnet ist – Korrektur in den Datei-Details möglich. Optional: Labelfarbe, Reihenfolge. Beschriftung = kleine Info-Zeile unter dem Titel.
4. Video: MP4 mit gleichem Dateinamen hochladen (song.mp3 + song.mp4) – wird automatisch verknüpft.
5. Übersicht: Medien → Plattenkiste.

Seit 1.4.0: Navigation bleibt beim Scrollen oben stehen, Anrufen + WhatsApp als Icons rechts im Menü, Cookie-Banner im DJ-KOLJA-ONE-Design, Link „Cookie-Richtlinie“ in der Fußzeile.

Seit 1.4.1: Keine blauen Markierungen mehr beim Ziehen am Crossfader. Kein 128-kbps-Hinweis mehr: Songs laufen in der hochgeladenen Qualität.

Seit 1.5.0: Seiten ohne Elementor (z. B. Cookie-Richtlinie) erscheinen im DJ-KOLJA-ONE-Design mit gleicher Kopf- und Fußzeile.

Seit 1.12.1: Klang und Laufruhe des Players verbessert: größerer Audio-Puffer (weniger Aussetzer), Limiter gegen Übersteuern beim Mixen, exakte Wiedergabegeschwindigkeit ohne Umrechnung, Filter in Neutralstellung ohne Höhenverlust; die Anzeige schreibt rund 94 % weniger Änderungen in die Seite und lässt dem Ton mehr Rechenzeit. Auf „Meine Musik“ ist die schwarze Lücke zwischen Einleitungstext und DJ-Pult entfernt.

Seit 1.12.0: Tempo-Regler an beiden Decks (±16 %), SYNC-Knopf (gleicht das Tempo an das andere Deck an, auch halbes/doppeltes Tempo) und KEY-Knopf (Key-Lock: Tonart bleibt beim Tempo-Ändern gleich). Automix: Mit dem + auf den Platten legst du Songs in eine Playlist; „Automix starten“ lädt sie nacheinander auf die Decks und mixt sie mit Tempo-Angleich, Überblendung und Bass-Tausch. Sobald du an Crossfader, Fadern, Tempo, Sync oder einer Platte eingreifst, übernimmst du manuell (die Decks laufen weiter); „Automix fortsetzen“ übergibt wieder. Auf der Seite „Meine Musik“ entfallen die beiden Hero-Buttons. Auf dem Handy erscheint beim Scrollen ein Menü-Knopf (Hamburger) für die Unterseiten.

Seit 1.11.0: Tonart-Erkennung (Camelot-System). Die Tonart wird beim Upload automatisch zusammen mit der BPM erkannt, am Deck und auf der Platte angezeigt; der Mixer zeigt, ob die beiden Songs harmonisch zusammenpassen (z. B. „8A + 9A · PASST“). In der Plattenkiste tragen die Platten Tonart und BPM, passende Songs sind grün/gelb markiert, der Knopf „Passt zu …“ blendet unpassende aus. Bestehende Songs werden einmalig automatisch nachanalysiert.
