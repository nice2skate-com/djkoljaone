#!/bin/sh
# Baut ZIP + Beschreibungsdatei für den Update-Kanal. Aufruf: sh make_release.sh "Änderungstext als HTML"
set -e
P=/home/claude/plugin/dj-kolja-one-plattenkiste
V=$(sed -n "s/^ \* Version: *//p" $P/dj-kolja-one-plattenkiste.php | tr -d ' \r')
grep -q "define( 'KJO_VERSION', '$V' )" $P/dj-kolja-one-plattenkiste.php || { echo "KJO_VERSION passt nicht zu $V"; exit 1; }
cd /home/claude/release && rm -f dj-kolja-one-plattenkiste-$V.zip
(cd /home/claude/plugin && zip -qr /home/claude/release/dj-kolja-one-plattenkiste-$V.zip dj-kolja-one-plattenkiste)
S=$(sha256sum dj-kolja-one-plattenkiste-$V.zip | cut -d' ' -f1)
python3 - "$V" "$S" "$1" <<'PY'
import json,sys
v,s,c=sys.argv[1:4]
json.dump({"version":v,"download_url":f"dj-kolja-one-plattenkiste-{v}.zip","sha256":s,"requires":"6.0","tested":"6.8","requires_php":"7.4","changelog":c},open("/home/claude/release/plattenkiste.json","w"),ensure_ascii=False,indent=1)
PY
echo "Release $V fertig"; ls -la /home/claude/release
