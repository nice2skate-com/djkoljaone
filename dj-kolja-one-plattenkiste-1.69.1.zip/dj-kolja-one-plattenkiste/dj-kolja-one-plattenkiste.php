<?php
/**
 * Plugin Name: DJ KOLJA ONE Plattenkiste
 * Description: Liefert deine Songs aus der Mediathek an das DJ-Pult auf „Meine Musik“ – mit Genre, BPM, Tonart (Camelot), Tempo-Regler, Sync, Automix, Video und Sterne-Bewertungen der Besucher.
 * Version:     1.69.1
 * Author:      DJ KOLJA ONE
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
define( 'KJO_VERSION', '1.69.1' );
define( 'KJO_USTID', 'DE331619498' ); // Umsatzsteuer-Identifikationsnummer (Bescheid BZSt vom 25.07.2020)
require_once __DIR__ . '/kjo-verleih.php';
require_once __DIR__ . '/kjo-kalender.php';
require_once __DIR__ . '/kjo-bilder.php';
require_once __DIR__ . '/kjo-freistellen.php';
require_once __DIR__ . '/kjo-kontakt.php';
require_once __DIR__ . '/kjo-leads.php';
require_once __DIR__ . '/kjo-backup.php';
require_once __DIR__ . '/kjo-aktion.php';
require_once __DIR__ . '/kjo-songwunsch.php';
require_once __DIR__ . '/kjo-musikliste.php';
require_once __DIR__ . '/kjo-tempo.php';
require_once __DIR__ . '/kjo-cache.php';
require_once __DIR__ . '/kjo-kennenlernen.php';
require_once __DIR__ . '/kjo-angebot.php';
require_once __DIR__ . '/kjo-social.php';
require_once __DIR__ . '/kjo-social-kommentar.php';
require_once __DIR__ . '/kjo-meta-pixel.php';
require_once __DIR__ . '/kjo-statistik.php';

/* ---------------------------------------------------------------
 * Hilfsfunktionen
 * ------------------------------------------------------------- */

function kjm_is_audio( $post ) {
	return $post && 'attachment' === $post->post_type && 0 === strpos( (string) $post->post_mime_type, 'audio/' );
}

/** Zwischenspeicher leeren (Elementor + gängige Cache-Plugins), damit neue Pult-Versionen sofort erscheinen. Liefert die Namen der geleerten Speicher. */
function kjm_purge_caches() {
	$done = array();
	if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
		\Elementor\Plugin::$instance->files_manager->clear_cache();
		$done[] = 'Elementor';
	}
	delete_post_meta_by_key( '_elementor_element_cache' ); // Elementor „Element Caching“.
	if ( function_exists( 'kjo_cache_leeren' ) ) {
		kjo_cache_leeren();
		$done[] = 'Seiten-Cache';
	}
	if ( function_exists( 'rocket_clean_domain' ) ) {
		rocket_clean_domain();
		$done[] = 'WP Rocket';
	}
	if ( function_exists( 'w3tc_flush_all' ) ) {
		w3tc_flush_all();
		$done[] = 'W3 Total Cache';
	}
	if ( function_exists( 'wp_cache_clear_cache' ) ) {
		wp_cache_clear_cache();
		$done[] = 'WP Super Cache';
	}
	if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
		sg_cachepress_purge_cache();
		$done[] = 'SG Optimizer';
	}
	if ( class_exists( 'autoptimizeCache' ) && method_exists( 'autoptimizeCache', 'clearall' ) ) {
		autoptimizeCache::clearall();
		$done[] = 'Autoptimize';
	}
	if ( has_action( 'litespeed_purge_all' ) ) {
		do_action( 'litespeed_purge_all' );
		$done[] = 'LiteSpeed';
	}
	return $done;
}

/**
 * Elementor-Seiten aus dem Plugin-Ordner „seiten/“ (<slug>.json) in die gleichnamigen WordPress-Seiten einspielen.
 * Läuft nur auf Knopfdruck (Medien → Plattenkiste). Der bisherige Inhalt bleibt als Sicherung erhalten.
 */
function kjo_seiten_sync( $only = null ) {
	$out = array();
	foreach ( (array) glob( __DIR__ . '/seiten/*.json' ) as $file ) {
		$slug = basename( $file, '.json' );
		if ( $only && $slug !== $only ) {
			continue;
		}
		$page = get_page_by_path( $slug );
		$neu  = array( 'dj-neu-ulm' => 'DJ Neu-Ulm', 'equipment' => 'Mein Equipment', 'technik-mieten' => 'Musikanlage, Licht & Partyequipment mieten' );
		if ( ! $page && isset( $neu[ $slug ] ) ) { // Neue Seiten (seit 1.22.0, DJ Neu-Ulm seit 1.53.0) werden beim ersten Einspielen angelegt.
			$pid = wp_insert_post(
				array(
					'post_type'   => 'page',
					'post_status' => 'publish',
					'post_title'  => $neu[ $slug ],
					'post_name'   => $slug,
					'meta_input'  => array( '_wp_page_template' => 'elementor_canvas' ),
				)
			);
			$page = $pid && ! is_wp_error( $pid ) ? get_post( $pid ) : null;
		}
		if ( ! $page ) {
			$out[ $slug ] = 'Seite nicht gefunden';
			continue;
		}
		$content = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore
		if ( ! is_array( $content ) || ! $content ) {
			$out[ $slug ] = 'Vorlage ungültig';
			continue;
		}
		$old = get_post_meta( $page->ID, '_elementor_data', true );
		/* Impressum: Nur die Fußzeile wird ersetzt, der vorhandene Text der Seite bleibt unverändert. Die Datenschutzerklärung wird seit 1.21.4 komplett aus der Vorlage übernommen. */
		if ( 'impressum' === $slug ) {
			$cur = is_string( $old ) ? json_decode( $old, true ) : $old;
			if ( ! is_array( $cur ) || ! $cur ) {
				$out[ $slug ] = 'kein vorhandener Inhalt – übersprungen';
				continue;
			}
			$foot = end( $content );
			$hit  = null;
			foreach ( $cur as $k => $el ) {
				$j = wp_json_encode( $el );
				if ( false !== strpos( $j, 'Jedes Event findet nur einmal statt' ) && false !== strpos( $j, 'Datenschutz' ) ) {
					$hit = $k; // letzte passende Stelle gewinnt (Fußzeile steht unten).
				}
			}
			if ( null === $hit ) {
				$out[ $slug ] = 'Fußzeile nicht gefunden – übersprungen';
				continue;
			}
			update_post_meta( $page->ID, '_kjo_backup_elementor_data', wp_slash( is_string( $old ) ? $old : wp_json_encode( $old ) ) );
			wp_save_post_revision( $page->ID );
			$cur[ $hit ] = $foot;
			$cur         = kjo_impressum_ustid( $cur );
			update_post_meta( $page->ID, '_elementor_data', wp_slash( wp_json_encode( $cur ) ) );
			update_post_meta( $page->ID, '_elementor_edit_mode', 'builder' );
			delete_post_meta( $page->ID, '_elementor_css' );
			delete_post_meta( $page->ID, '_elementor_element_cache' );
			clean_post_cache( $page->ID );
			$out[ $slug ] = 'nur Fußzeile aktualisiert';
			continue;
		}
		$new = wp_json_encode( $content );
		if ( $old && ( is_string( $old ) ? $old : wp_json_encode( $old ) ) !== $new ) { // Sicherung nicht mit der neuen Fassung überschreiben.
			update_post_meta( $page->ID, '_kjo_backup_elementor_data', wp_slash( is_string( $old ) ? $old : wp_json_encode( $old ) ) );
		}
		wp_save_post_revision( $page->ID );
		update_post_meta( $page->ID, '_elementor_data', wp_slash( $new ) );
		update_post_meta( $page->ID, '_elementor_edit_mode', 'builder' );
		delete_post_meta( $page->ID, '_elementor_css' );
		delete_post_meta( $page->ID, '_elementor_element_cache' );
		clean_post_cache( $page->ID );
		$out[ $slug ] = 'eingespielt';
	}
	if ( function_exists( 'kjo_cache_leeren' ) ) {
		kjo_cache_leeren();
	}
	return $out;
}
/* Datenschutzerklärung einmalig automatisch aktualisieren (neuer Stand mit Google Analytics und Microsoft Clarity), sobald ein Admin das Dashboard öffnet. Der bisherige Inhalt bleibt als Sicherung erhalten. */
add_action(
	'admin_init',
	function () {
		if ( current_user_can( 'manage_options' ) && '2026-10-verleih' !== get_option( 'kjo_ds_stand' ) ) {
			update_option( 'kjo_ds_stand', '2026-10-verleih', false );
			kjo_seiten_sync( 'datenschutz' );
			if ( function_exists( 'kjm_purge_caches' ) ) {
				kjm_purge_caches();
			}
		}
	},
	20
);
/** Inhalt vor dem letzten Einspielen wiederherstellen. */
function kjo_seiten_restore() {
	$out = array();
	foreach ( (array) glob( __DIR__ . '/seiten/*.json' ) as $file ) {
		$slug = basename( $file, '.json' );
		$page = get_page_by_path( $slug );
		$bak  = $page ? get_post_meta( $page->ID, '_kjo_backup_elementor_data', true ) : '';
		if ( ! $bak ) {
			$out[ $slug ] = 'keine Sicherung';
			continue;
		}
		update_post_meta( $page->ID, '_elementor_data', wp_slash( $bak ) );
		delete_post_meta( $page->ID, '_elementor_css' );
		delete_post_meta( $page->ID, '_elementor_element_cache' );
		clean_post_cache( $page->ID );
		$out[ $slug ] = 'wiederhergestellt';
	}
	if ( function_exists( 'kjo_cache_leeren' ) ) {
		kjo_cache_leeren();
	}
	return $out;
}
/* Automatisches Leeren direkt nach dem SFTP-Deploy: Der Deploy legt eine Einmal-Datei mit zufälligem Token ab und ruft diese Adresse auf. */
add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'kjm/v1',
			'/purge',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => function ( WP_REST_Request $req ) {
					$file = __DIR__ . '/.purge-token';
					$sent = (string) $req->get_header( 'x-kjm-token' );
					if ( '' === $sent || ! is_readable( $file ) || ( time() - (int) filemtime( $file ) ) > 900 ) {
						return new WP_Error( 'kjm_purge', 'Nicht erlaubt.', array( 'status' => 403 ) );
					}
					$want = trim( (string) file_get_contents( $file ) ); // phpcs:ignore
					@unlink( $file ); // phpcs:ignore -- Token gilt nur einmal.
					if ( '' === $want || ! hash_equals( $want, $sent ) ) {
						return new WP_Error( 'kjm_purge', 'Nicht erlaubt.', array( 'status' => 403 ) );
					}
					update_option( 'kjm_cache_ver', KJO_VERSION, false );
					return rest_ensure_response( array( 'ok' => true, 'geleert' => kjm_purge_caches(), 'version' => KJO_VERSION ) );
				},
			)
		);
	}
);
/*
 * Elementor-CSS direkt in die Seite schreiben statt als eigene Datei (uploads/elementor/css/…).
 * Grund: Nach dem Leeren des Elementor-Zwischenspeichers fehlen diese Dateien, bis jemand die Seite neu
 * erzeugt – liefert ein Seiten-/Server-Cache dann noch altes HTML aus, erscheint die Website ohne Gestaltung
 * (weiße Seite, Menü als Liste). Eingebettetes CSS kann nicht fehlen; auch Microsoft Clarity zeigt die
 * Aufzeichnungen dann korrekt. Abschalten: add_filter( 'kjo_css_inline', '__return_false' );
 */
function kjo_css_inline_ensure() {
	if ( ! apply_filters( 'kjo_css_inline', true ) || ! class_exists( '\Elementor\Plugin' ) ) {
		return false;
	}
	if ( 'internal' !== get_option( 'elementor_css_print_method' ) ) {
		update_option( 'elementor_css_print_method', 'internal' );
		return true;
	}
	return false;
}
add_action(
	'admin_init',
	function () {
		if ( current_user_can( 'manage_options' ) && kjo_css_inline_ensure() ) {
			kjm_purge_caches();
		}
	},
	5
);
/* Nach jedem Update (auch per SFTP-Deploy) einmalig leeren, sobald jemand das Dashboard öffnet. */
add_action(
	'admin_init',
	function () {
		if ( KJO_VERSION !== get_option( 'kjm_cache_ver' ) && current_user_can( 'manage_options' ) ) {
			update_option( 'kjm_cache_ver', KJO_VERSION, false );
			kjm_purge_caches();
		}
	}
);


/** Wellenform + Beatgrid prüfen und bereinigen (aus dem Browser). Liefert ein Array oder null. */
function kjm_wave_clean( $w ) {
	if ( ! is_array( $w ) || empty( $w['d'] ) || empty( $w['n'] ) ) {
		return null;
	}
	$n   = (int) $w['n'];
	$bin = base64_decode( (string) $w['d'], true );
	if ( $n < 40 || $n > 20000 || false === $bin || strlen( $bin ) !== 3 * $n ) {
		return null;
	}
	return array(
		'dt'    => 0.05,
		'n'     => $n,
		'd'     => base64_encode( $bin ), // phpcs:ignore
		'dur'   => round( max( 1, min( 7200, (float) ( isset( $w['dur'] ) ? $w['dur'] : $n * 0.05 ) ) ), 2 ),
		'first' => round( max( 0, min( 10, (float) ( isset( $w['first'] ) ? $w['first'] : 0 ) ) ), 3 ),
		'bpm'   => round( max( 0, min( 250, (float) ( isset( $w['bpm'] ) ? $w['bpm'] : 0 ) ) ), 2 ),
		'bar'   => max( 0, min( 3, (int) ( isset( $w['bar'] ) ? $w['bar'] : 0 ) ) ),
	);
}
/** Gespeicherte Wellenform eines Songs oder null. */
function kjm_wave_get( $id ) {
	$j = get_post_meta( $id, 'kjm_wave', true );
	$w = is_string( $j ) && '' !== $j ? json_decode( $j, true ) : null;
	return is_array( $w ) ? $w : null;
}

/** Tonart im Camelot-Format (1A–12B) oder ''. Akzeptiert z. B. „8a“ oder „08A“. */
function kjm_key_clean( $v ) {
	$v = strtoupper( trim( (string) $v ) );
	$v = preg_replace( '/^0+(?=\d)/', '', $v );
	return preg_match( '/^(1[0-2]|[1-9])[AB]$/', $v ) ? $v : '';
}
function kjm_key( $id ) {
	return kjm_key_clean( get_post_meta( $id, 'kjm_key', true ) );
}

/** Genre: eigenes Feld, sonst das Genre aus der MP3-Datei (ID3). */
function kjm_genre( $id ) {
	$g = trim( (string) get_post_meta( $id, 'kjm_genre', true ) );
	if ( '' === $g ) {
		$m = wp_get_attachment_metadata( $id );
		if ( ! empty( $m['genre'] ) ) {
			$g = trim( (string) $m['genre'] );
		}
	}
	return $g;
}

/** Video: eigenes Feld, sonst ein Video in der Mediathek mit gleichem Dateinamen (z. B. song.mp3 + song.mp4). */
function kjm_video( $id ) {
	$v = trim( (string) get_post_meta( $id, 'kjm_video', true ) );
	if ( '' !== $v ) {
		return $v;
	}
	$file = get_attached_file( $id );
	if ( ! $file ) {
		return '';
	}
	$base   = pathinfo( $file, PATHINFO_FILENAME );
	$videos = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'video',
			'post_status'    => 'inherit',
			'posts_per_page' => 10,
			'no_found_rows'  => true,
			'meta_query'     => array(
				array(
					'key'     => '_wp_attached_file',
					'value'   => $base . '.',
					'compare' => 'LIKE',
				),
			),
		)
	);
	foreach ( $videos as $vid ) {
		if ( pathinfo( (string) get_attached_file( $vid->ID ), PATHINFO_FILENAME ) === $base ) {
			return (string) wp_get_attachment_url( $vid->ID );
		}
	}
	return '';
}

function kjm_rating( $id ) {
	$sum = (int) get_post_meta( $id, 'kjm_sum', true );
	$cnt = (int) get_post_meta( $id, 'kjm_count', true );
	return array(
		'avg'   => $cnt ? round( $sum / $cnt, 1 ) : 0,
		'count' => $cnt,
	);
}

/* Testdaten-Bewertungen (seit 1.50.0): nur zum Testen der Darstellung, im Pult überall als „Testdaten“ gekennzeichnet.
 * Echte Bewertungen werden weiter gespeichert und nicht verändert; ausschalten zeigt wieder die echten Werte. */
function kjm_testdaten() {
	return '1' === get_option( 'kjm_testdaten', '' );
}
function kjm_test_rating( $id ) {
	$h   = crc32( 'kjm-test-' . $id );
	$neu = strtotime( get_post_field( 'post_date_gmt', $id ) . ' UTC' ) > (int) get_option( 'kjm_testdaten_ab', 0 );
	$cnt = $neu ? 100 + $h % 101 : 300 + $h % 201; // bestehende Songs 300–500, neue 100–200
	return array(
		'avg'   => round( 4 + ( ( $h >> 8 ) % 11 ) / 10, 1 ), // 4,0–5,0
		'count' => $cnt,
	);
}

function kjm_visible( $id ) {
	return '' !== kjm_genre( $id ) && ! get_post_meta( $id, 'kjm_hide', true );
}

/* Cover: Beitragsbild für MP3s erlauben – WordPress übernimmt dann das Cover aus der MP3 automatisch. */
add_action(
	'init',
	function () {
		add_post_type_support( 'attachment:audio', 'thumbnail' );
	}
);

/* ---------------------------------------------------------------
 * Bilder und Videos der Website: Anzeigehöhe in px (überschreibt die Standardhöhe von 400 px).
 * Die Breite ergibt sich aus dem Seitenverhältnis; ist der Platz zu schmal, wird verhältnisgleich kleiner.
 * ------------------------------------------------------------- */
function kjo_is_site_media( $post ) {
	return $post && 'attachment' === $post->post_type && preg_match( '#^(image|video)/#', (string) $post->post_mime_type );
}
add_filter(
	'attachment_fields_to_edit',
	function ( $fields, $post ) {
		if ( ! kjo_is_site_media( $post ) ) {
			return $fields;
		}
		$h = (int) get_post_meta( $post->ID, 'kjo_h', true );
		$fields['kjo_h'] = array(
			'label' => 'Website: Höhe (px)',
			'input' => 'html',
			'html'  => '<input type="number" min="0" max="2000" step="10" style="width:7em" name="attachments[' . $post->ID . '][kjo_h]" value="' . ( $h ? $h : '' ) . '">',
			'helps' => 'Optional. Höhe, in der dieses Bild bzw. Video auf der Website gezeigt wird, z. B. 300. Die Breite passt sich im Seitenverhältnis an. Leer = Standard (400 px). Auf schmalen Bildschirmen wird es bei Bedarf verhältnisgleich kleiner.',
		);
		return $fields;
	},
	20,
	2
);
add_filter(
	'attachment_fields_to_save',
	function ( $post, $att ) {
		$id = isset( $post['ID'] ) ? (int) $post['ID'] : 0;
		if ( ! $id || ! isset( $att['kjo_h'] ) || ! current_user_can( 'edit_post', $id ) || ! kjo_is_site_media( get_post( $id ) ) ) {
			return $post;
		}
		$h = min( 2000, absint( $att['kjo_h'] ) );
		if ( $h ) {
			update_post_meta( $id, 'kjo_h', $h );
		} else {
			delete_post_meta( $id, 'kjo_h' );
		}
		kjo_media_flush();
		return $post;
	},
	20,
	2
);

/* ---------------------------------------------------------------
 * Zusätzliche Felder in der Mediathek (nur bei MP3/Audio)
 * ------------------------------------------------------------- */

add_filter(
	'attachment_fields_to_edit',
	function ( $fields, $post ) {
		if ( ! kjm_is_audio( $post ) ) {
			return $fields;
		}
		$id  = $post->ID;
		$m   = wp_get_attachment_metadata( $id );
		$id3 = ! empty( $m['genre'] ) ? $m['genre'] : '';
		$r   = kjm_rating( $id );

		$fields['kjm_genre'] = array(
			'label' => 'Plattenkiste: Genre',
			'input' => 'text',
			'value' => get_post_meta( $id, 'kjm_genre', true ),
			'helps' => $id3 ? 'Leer lassen = Genre aus der MP3-Datei („' . esc_html( $id3 ) . '“).' : 'z. B. House, Pop, Party, Latin. Ohne Genre erscheint der Song nicht im DJ-Pult.',
		);
		$fields['kjm_bpm']   = array(
			'label' => 'Plattenkiste: BPM',
			'input' => 'text',
			'value' => get_post_meta( $id, 'kjm_bpm', true ),
			'helps' => 'Tempo des Songs, z. B. 124 (optional).',
		);
		$fields['kjm_key']   = array(
			'label' => 'Plattenkiste: Tonart (Camelot)',
			'input' => 'text',
			'value' => get_post_meta( $id, 'kjm_key', true ),
			'helps' => 'Wird beim Hochladen automatisch erkannt, z. B. 8A (a-Moll) oder 5B (Es-Dur). Hier kannst du sie korrigieren.',
		);
		$fields['kjm_video'] = array(
			'label' => 'Plattenkiste: Video-URL',
			'input' => 'text',
			'value' => get_post_meta( $id, 'kjm_video', true ),
			'helps' => 'Optional. Leer lassen, wenn ein MP4 mit gleichem Dateinamen in der Mediathek liegt – es wird automatisch gefunden.',
		);
		$fields['kjm_color'] = array(
			'label' => 'Plattenkiste: Labelfarbe',
			'input' => 'text',
			'value' => get_post_meta( $id, 'kjm_color', true ),
			'helps' => 'Optional, z. B. #B29D75. Leer = automatisch.',
		);
		$fields['kjm_order'] = array(
			'label' => 'Plattenkiste: Reihenfolge',
			'input' => 'text',
			'value' => get_post_meta( $id, 'kjm_order', true ),
			'helps' => 'Optional. Kleinere Zahl = weiter vorne im Genre.',
		);
		$fields['kjm_link']  = array(
			'label' => 'Link zum Teilen',
			'input' => 'html',
			'html'  => '<input type="text" readonly class="widefat" onclick="this.select()" value="' . esc_attr( home_url( '/meine-musik/?song=' . $id ) ) . '"><br><small>Öffnet „Meine Musik“ mit diesem Song auf Deck A – ein Tipp startet ihn. Für ein Genre: <code>' . esc_html( home_url( '/meine-musik/?mix=house' ) ) . '</code></small>',
		);
		$qr_url = home_url( '/meine-musik/?song=' . $id . '&bewerten=1&utm_source=qr&utm_medium=karte&utm_campaign=bewerten' );
		$fields['kjm_qr'] = array(
			'label' => 'QR-Code zum Bewerten',
			'input' => 'html',
			'html'  => '<div class="kjm-qr" data-url="' . esc_attr( $qr_url ) . '" data-titel="' . esc_attr( get_the_title( $id ) ) . '" data-file="' . esc_attr( 'qr-bewerten-' . sanitize_title( get_the_title( $id ) ) . '.png' ) . '"></div><small>Für Karte am DJ-Pult, Bildschirm oder Story: Der Scan öffnet „Meine Musik“ mit diesem Song auf Deck A und den Bewertungs-Sternen. Link: <code>' . esc_html( $qr_url ) . '</code></small>',
		);
		$fields['kjm_shares'] = array(
			'label' => 'Geteilt',
			'input' => 'html',
			'html'  => esc_html( (int) get_post_meta( $id, 'kjm_shares', true ) . '-mal über den Teilen-Knopf im DJ-Pult' ),
		);
		$rd                     = (string) get_post_meta( $id, 'kjm_release', true );
		$fields['kjm_release']  = array(
			'label' => 'Release (Instagram)',
			'input' => 'html',
			'html'  => '<input type="date" name="attachments[' . $id . '][kjm_release]" value="' . esc_attr( $rd ) . '"> <label><input type="checkbox" name="attachments[' . $id . '][kjm_release_erl]" value="1" ' . checked( (bool) get_post_meta( $id, 'kjm_release_erl', true ), true, false ) . '> erl. (veröffentlicht)</label><br><small>Release-Tag ist Dienstag, 19 Uhr. Gleiche Angabe wie in der Spalte „Release“ unter Medien → Plattenkiste; dort verteilt „Termine planen“ alle offenen Songs.</small>',
		);
		$fields['kjm_hide']  = array(
			'label' => 'Plattenkiste',
			'input' => 'html',
			'html'  => '<label><input type="checkbox" name="attachments[' . $id . '][kjm_hide]" value="1" ' . checked( (bool) get_post_meta( $id, 'kjm_hide', true ), true, false ) . '> im DJ-Pult ausblenden</label>',
		);
		$fields['kjm_stats'] = array(
			'label' => 'Bewertung',
			'input' => 'html',
			'html'  => ( $r['count'] ? esc_html( number_format_i18n( $r['avg'], 1 ) . ' von 5 · ' . $r['count'] . ' Bewertung(en)' ) : 'Noch keine Bewertung' )
				. ( $r['count'] ? '<br><label><input type="checkbox" name="attachments[' . $id . '][kjm_reset]" value="1"> Bewertungen zurücksetzen</label>' : '' ),
		);
		return $fields;
	},
	10,
	2
);

add_filter(
	'attachment_fields_to_save',
	function ( $post, $att ) {
		$id = isset( $post['ID'] ) ? (int) $post['ID'] : 0;
		if ( ! $id || ! kjm_is_audio( get_post( $id ) ) || ! current_user_can( 'edit_post', $id ) ) {
			return $post;
		}
		if ( isset( $att['kjm_genre'] ) ) {
			update_post_meta( $id, 'kjm_genre', sanitize_text_field( $att['kjm_genre'] ) );
		}
		if ( isset( $att['kjm_bpm'] ) ) {
			$b = absint( $att['kjm_bpm'] );
			update_post_meta( $id, 'kjm_bpm', $b ? $b : '' );
		}
		if ( isset( $att['kjm_key'] ) ) {
			update_post_meta( $id, 'kjm_key', kjm_key_clean( $att['kjm_key'] ) );
			delete_post_meta( $id, 'kjm_pending' );
		}
		if ( isset( $att['kjm_video'] ) ) {
			update_post_meta( $id, 'kjm_video', esc_url_raw( trim( $att['kjm_video'] ) ) );
		}
		if ( isset( $att['kjm_color'] ) ) {
			$c = sanitize_hex_color( trim( $att['kjm_color'] ) );
			update_post_meta( $id, 'kjm_color', $c ? $c : '' );
		}
		if ( isset( $att['kjm_order'] ) ) {
			update_post_meta( $id, 'kjm_order', '' === trim( $att['kjm_order'] ) ? '' : intval( $att['kjm_order'] ) );
		}
		if ( isset( $att['kjm_genre'] ) ) { // Formular wurde abgeschickt → Checkbox auswerten.
			update_post_meta( $id, 'kjm_hide', empty( $att['kjm_hide'] ) ? '' : '1' );
		}
		if ( isset( $att['kjm_release'] ) ) { // Release-Datum und „erl.“ (seit 1.68.1)
			$d = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $att['kjm_release'] ) ? $att['kjm_release'] : '';
			$e = ! empty( $att['kjm_release_erl'] );
			update_post_meta( $id, 'kjm_release', $e && '' === $d ? wp_date( 'Y-m-d' ) : $d );
			$e ? update_post_meta( $id, 'kjm_release_erl', 1 ) : delete_post_meta( $id, 'kjm_release_erl' );
		}
		if ( ! empty( $att['kjm_reset'] ) ) {
			delete_post_meta( $id, 'kjm_sum' );
			delete_post_meta( $id, 'kjm_count' );
		}
		return $post;
	},
	10,
	2
);

/* ---------------------------------------------------------------
 * REST-API für das DJ-Pult
 *   GET  /wp-json/kjm/v1/songs
 *   POST /wp-json/kjm/v1/rate   { id, stars }
 * ------------------------------------------------------------- */

add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'kjm/v1',
			'/songs',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => 'kjm_rest_songs',
			)
		);
		register_rest_route(
			'kjm/v1',
			'/wave',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => function ( WP_REST_Request $req ) {
					$id = (int) $req['id'];
					if ( ! kjm_is_audio( get_post( $id ) ) || ! kjm_visible( $id ) ) {
						return new WP_Error( 'kjm_wave', 'Unbekannter Song.', array( 'status' => 404 ) );
					}
					$w = kjm_wave_get( $id );
					if ( ! $w ) {
						return new WP_Error( 'kjm_wave', 'Noch keine Wellenform.', array( 'status' => 404 ) );
					}
					$res = rest_ensure_response( $w );
					$res->header( 'Cache-Control', 'private, max-age=3600' );
					return $res;
				},
			)
		);
		register_rest_route(
			'kjm/v1',
			'/share',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => function ( WP_REST_Request $req ) {
					$id = (int) $req['id'];
					if ( ! kjm_is_audio( get_post( $id ) ) || ! kjm_visible( $id ) ) {
						return new WP_Error( 'kjm_share', 'Unbekannter Song.', array( 'status' => 404 ) );
					}
					$ip = md5( 'kjm_sh' . $id . ( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' ) );
					if ( get_transient( 'kjm_sh_' . $ip ) ) {
						return array( 'ok' => true ); // pro Besucher und Song höchstens einmal pro Stunde zählen
					}
					set_transient( 'kjm_sh_' . $ip, 1, HOUR_IN_SECONDS );
					$n = (int) get_post_meta( $id, 'kjm_shares', true ) + 1;
					update_post_meta( $id, 'kjm_shares', $n );
					return array( 'ok' => true );
				},
			)
		);
		register_rest_route(
			'kjm/v1',
			'/rate',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => 'kjm_rest_rate',
				'args'                => array(
					'id'    => array(
						'required' => true,
						'type'     => 'integer',
					),
					'stars' => array(
						'required' => true,
						'type'     => 'integer',
						'minimum'  => 1,
						'maximum'  => 5,
					),
				),
			)
		);
	}
);

function kjm_rest_songs() {
	$posts = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'audio',
			'post_status'    => 'inherit',
			'posts_per_page' => 300,
			'orderby'        => 'date',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		)
	);
	$out = array();
	foreach ( $posts as $p ) {
		if ( ! kjm_visible( $p->ID ) ) {
			continue;
		}
		$m     = wp_get_attachment_metadata( $p->ID );
		$r     = kjm_testdaten() ? kjm_test_rating( $p->ID ) : kjm_rating( $p->ID );
		$order = get_post_meta( $p->ID, 'kjm_order', true );
		$out[] = array(
			'id'    => $p->ID,
			'titel' => html_entity_decode( $p->post_title, ENT_QUOTES, 'UTF-8' ),
			'info'  => '' !== $p->post_excerpt ? wp_strip_all_tags( $p->post_excerpt ) : ( ! empty( $m['artist'] ) ? $m['artist'] : '' ),
			'genre' => kjm_genre( $p->ID ),
			'bpm'   => (int) get_post_meta( $p->ID, 'kjm_bpm', true ),
			'key'   => kjm_key( $p->ID ),
			'farbe' => (string) get_post_meta( $p->ID, 'kjm_color', true ),
			'audio' => kjm_stream_url( $p->ID, 'a' ),
			'video' => kjm_stream_url( $p->ID, 'v' ),
			'cover' => wp_make_link_relative( (string) get_the_post_thumbnail_url( $p->ID, 'medium_large' ) ),
			'album' => ! empty( $m['album'] ) ? html_entity_decode( (string) $m['album'], ENT_QUOTES, 'UTF-8' ) : '',
			'wave'  => kjm_wave_get( $p->ID ) ? 1 : 0,
			'dauer' => ! empty( $m['length_formatted'] ) ? $m['length_formatted'] : '',
			'avg'   => $r['avg'],
			'count' => $r['count'],
			'test'  => kjm_testdaten() ? 1 : 0,
			'_o'    => '' === $order ? PHP_INT_MAX : (int) $order,
		);
	}
	usort(
		$out,
		function ( $a, $b ) {
			$ra = kjm_genre_rank( $a['genre'] );
			$rb = kjm_genre_rank( $b['genre'] );
			if ( $ra !== $rb ) {
				return $ra < $rb ? -1 : 1;
			}
			if ( $ra >= 1000 && strcasecmp( $a['genre'], $b['genre'] ) ) {
				return strcasecmp( $a['genre'], $b['genre'] );
			}
			return $a['_o'] === $b['_o'] ? 0 : ( $a['_o'] < $b['_o'] ? -1 : 1 );
		}
	);
	foreach ( $out as &$o ) {
		unset( $o['_o'] );
	}
	$res = rest_ensure_response( $out );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

/*
 * Song-Releases (seit 1.68.0): Jeden Dienstag um 19 Uhr erscheint ein Song als Reel auf Instagram, in der Reihenfolge des Pults
 * (Genres, dann Songs pro Genre). Pro Song: kjm_release (Datum Y-m-d) und kjm_release_erl (1 = veröffentlicht).
 * „Termine planen“ verteilt alle offenen Songs ab dem nächsten freien Dienstag; erledigte bleiben unverändert.
 */
define( 'KJM_RELEASE_TAG', 2 ); // Dienstag (ISO: 1 = Montag)
define( 'KJM_RELEASE_ZEIT', '19:00' );

/* Sichtbare Songs in der Reihenfolge des Pults. */
function kjm_pult_ids() {
	$posts = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'audio',
			'post_status'    => 'inherit',
			'posts_per_page' => 300,
			'orderby'        => 'date',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		)
	);
	$l = array();
	foreach ( $posts as $p ) {
		if ( kjm_visible( $p->ID ) ) {
			$o   = get_post_meta( $p->ID, 'kjm_order', true );
			$l[] = array( $p->ID, kjm_genre( $p->ID ), '' === $o ? PHP_INT_MAX : (int) $o );
		}
	}
	usort(
		$l,
		function ( $a, $b ) {
			$ra = kjm_genre_rank( $a[1] );
			$rb = kjm_genre_rank( $b[1] );
			if ( $ra !== $rb ) {
				return $ra < $rb ? -1 : 1;
			}
			if ( $ra >= 1000 && strcasecmp( $a[1], $b[1] ) ) {
				return strcasecmp( $a[1], $b[1] );
			}
			return $a[2] === $b[2] ? 0 : ( $a[2] < $b[2] ? -1 : 1 );
		}
	);
	return wp_list_pluck( $l, 0 );
}

/* Erster Release-Dienstag, der noch nicht vorbei ist (heute zählt bis 19 Uhr) und nach dem letzten erledigten Release liegt. */
function kjm_release_start( $nach = '' ) {
	$tz = wp_timezone();
	$d  = new DateTimeImmutable( 'now', $tz );
	if ( (int) $d->format( 'N' ) === KJM_RELEASE_TAG && $d->format( 'H:i' ) >= KJM_RELEASE_ZEIT ) {
		$d = $d->modify( '+1 day' );
	}
	while ( (int) $d->format( 'N' ) !== KJM_RELEASE_TAG ) {
		$d = $d->modify( '+1 day' );
	}
	if ( $nach && $d->format( 'Y-m-d' ) <= $nach ) {
		$d = new DateTimeImmutable( $nach, $tz );
		do {
			$d = $d->modify( '+1 day' );
		} while ( (int) $d->format( 'N' ) !== KJM_RELEASE_TAG );
	}
	return $d;
}

/* Plant alle offenen Songs neu: ein Song pro Dienstag. Gibt id => Datum zurück. */
function kjm_release_plan() {
	$ids     = kjm_pult_ids();
	$letzter = '';
	foreach ( $ids as $id ) {
		$d = (string) get_post_meta( $id, 'kjm_release', true );
		if ( get_post_meta( $id, 'kjm_release_erl', true ) && $d > $letzter ) {
			$letzter = $d;
		}
	}
	$tag = kjm_release_start( $letzter );
	$out = array();
	foreach ( $ids as $id ) {
		if ( get_post_meta( $id, 'kjm_release_erl', true ) ) {
			continue;
		}
		$out[ $id ] = $tag->format( 'Y-m-d' );
		update_post_meta( $id, 'kjm_release', $out[ $id ] );
		$tag = $tag->modify( '+7 days' );
	}
	return $out;
}

function kjm_release_cell( $id ) {
	$d = (string) get_post_meta( $id, 'kjm_release', true );
	$e = (bool) get_post_meta( $id, 'kjm_release_erl', true );
	return '<span style="white-space:nowrap"><input type="date" class="kjm-rel-d" data-id="' . (int) $id . '" value="' . esc_attr( $d ) . '" style="width:140px"> <label title="veröffentlicht"><input type="checkbox" class="kjm-rel-e" data-id="' . (int) $id . '"' . checked( $e, true, false ) . '> erl.</label></span>';
}

/* Kasten über der Track-Liste: nächster Release und „Termine planen“. */
function kjm_release_box() {
	$heute = wp_date( 'Y-m-d' );
	$next  = null;
	foreach ( kjm_pult_ids() as $id ) {
		$d = (string) get_post_meta( $id, 'kjm_release', true );
		if ( $d && $d >= $heute && ! get_post_meta( $id, 'kjm_release_erl', true ) && ( ! $next || $d < $next[1] ) ) {
			$next = array( $id, $d );
		}
	}
	$wt = array( '', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So' );
	echo '<div style="margin:8px 0 12px;padding:10px 14px;background:#fff;border-left:4px solid #B29D75"><strong>Release-Plan:</strong> jeden Dienstag um 19 Uhr ein Song als Reel, in der Reihenfolge des Pults. ';
	if ( $next ) {
		$t = new DateTimeImmutable( $next[1], wp_timezone() );
		echo 'Nächster Release: <strong>' . esc_html( $wt[ (int) $t->format( 'N' ) ] . ', ' . $t->format( 'd.m.Y' ) . ', ' . KJM_RELEASE_ZEIT . ' Uhr – ' . get_the_title( $next[0] ) ) . '</strong>. ';
	} else {
		echo 'Noch kein offener Termin geplant. ';
	}
	echo '<button type="button" class="button" id="kjm-rel-plan">Termine planen</button> <span id="kjm-rel-msg" class="description">Nach dem Posten bei „erl.“ abhaken. Erledigte Songs behalten ihr Datum.</span></div>';
}

add_action(
	'wp_ajax_kjm_release',
	function () {
		check_ajax_referer( 'kjm_bpm' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( null, 403 );
		}
		if ( ! empty( $_POST['plan'] ) ) {
			wp_send_json_success( kjm_release_plan() );
		}
		$id = (int) ( $_POST['id'] ?? 0 );
		if ( ! $id || ! current_user_can( 'edit_post', $id ) || ! kjm_is_audio( get_post( $id ) ) ) {
			wp_send_json_error( null, 400 );
		}
		$d = sanitize_text_field( wp_unslash( $_POST['datum'] ?? '' ) );
		$d = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ? $d : '';
		$e = ! empty( $_POST['erl'] );
		if ( $e && '' === $d ) {
			$d = wp_date( 'Y-m-d' ); // abgehakt ohne Datum: heute
		}
		update_post_meta( $id, 'kjm_release', $d );
		$e ? update_post_meta( $id, 'kjm_release_erl', 1 ) : delete_post_meta( $id, 'kjm_release_erl' );
		wp_send_json_success( array( 'datum' => $d ) );
	}
);

/* Einmalig (1.68.0): Electric Blue (5111) ist bereits erschienen, die übrigen Songs bekommen ihre Dienstage. */
add_action(
	'admin_init',
	function () {
		if ( get_option( 'kjm_release_init' ) ) {
			return;
		}
		update_option( 'kjm_release_init', 1, false );
		if ( kjm_is_audio( get_post( 5111 ) ) && ! get_post_meta( 5111, 'kjm_release_erl', true ) ) {
			update_post_meta( 5111, 'kjm_release_erl', 1 );
		}
		kjm_release_plan(); // Termine für alle weiteren Songs vorbelegen
	}
);

/* Einmalig (1.68.1): Got the Summer Feeling (5169) erschien am 18.10.2026; offene Songs rücken einen Dienstag vor. */
add_action(
	'admin_init',
	function () {
		if ( get_option( 'kjm_release_fix1' ) || ! get_option( 'kjm_release_init' ) ) {
			return;
		}
		update_option( 'kjm_release_fix1', 1, false );
		if ( kjm_is_audio( get_post( 5169 ) ) ) {
			update_post_meta( 5169, 'kjm_release', '2026-10-18' );
			update_post_meta( 5169, 'kjm_release_erl', 1 );
			kjm_release_plan();
		}
	},
	11
);

/* Reihenfolge der Genres im Pult (Option kjm_genre_order); unbekannte Genres folgen alphabetisch. */
function kjm_genre_rank( $genre ) {
	static $go = null;
	if ( null === $go ) {
		$go = get_option( 'kjm_genre_order', array() );
		$go = is_array( $go ) ? array_values( $go ) : array();
	}
	$i = array_search( $genre, $go, true );
	return false === $i ? 1000 : (int) $i;
}

/* Admin: Genres und Songs pro Genre in der Reihenfolge des Pults sortieren (▲▼, wird sofort gespeichert). */
function kjm_order_box( $posts ) {
	$groups = array();
	foreach ( $posts as $p ) {
		if ( ! kjm_visible( $p->ID ) ) {
			continue;
		}
		$groups[ kjm_genre( $p->ID ) ][] = $p;
	}
	if ( ! $groups ) {
		return;
	}
	uksort(
		$groups,
		function ( $a, $b ) {
			$ra = kjm_genre_rank( $a );
			$rb = kjm_genre_rank( $b );
			return $ra !== $rb ? ( $ra < $rb ? -1 : 1 ) : strcasecmp( $a, $b );
		}
	);
	foreach ( $groups as &$l ) {
		usort(
			$l,
			function ( $a, $b ) {
				$oa = get_post_meta( $a->ID, 'kjm_order', true );
				$ob = get_post_meta( $b->ID, 'kjm_order', true );
				$oa = '' === $oa ? PHP_INT_MAX : (int) $oa;
				$ob = '' === $ob ? PHP_INT_MAX : (int) $ob;
				return $oa === $ob ? 0 : ( $oa < $ob ? -1 : 1 );
			}
		);
	}
	unset( $l );
	echo '<h2>Reihenfolge im Pult</h2><p class="description">Mit ▲ ▼ verschiebst du Genres und die Songs innerhalb eines Genres. Die Änderung wird sofort gespeichert und gilt im Pult und in der Plattenkiste. <span id="kjm-ord-msg"></span></p>';
	echo '<div id="kjm-ord" style="max-width:640px">';
	foreach ( $groups as $g => $l ) {
		echo '<div class="kjm-og" data-g="' . esc_attr( $g ) . '" style="border:1px solid #c3c4c7;background:#fff;margin:0 0 10px;padding:6px 10px"><div style="display:flex;gap:6px;align-items:center;font-weight:600;padding:4px 0"><span style="flex:1">' . esc_html( $g ?: '–' ) . '</span><button type="button" class="button button-small kjm-az" title="Songs A–Z">A–Z</button><button type="button" class="button button-small kjm-up" title="Genre nach oben">▲</button><button type="button" class="button button-small kjm-dn" title="Genre nach unten">▼</button></div><ul style="margin:0">';
		foreach ( $l as $p ) {
			echo '<li class="kjm-ot" data-id="' . (int) $p->ID . '" style="display:flex;gap:6px;align-items:center;margin:0;padding:3px 0;border-top:1px solid #eee"><span style="flex:1">' . esc_html( $p->post_title ) . '</span><button type="button" class="button button-small kjm-up" title="nach oben">▲</button><button type="button" class="button button-small kjm-dn" title="nach unten">▼</button></li>';
		}
		echo '</ul></div>';
	}
	echo '</div>';
	echo '<script>(function(){var box=document.getElementById("kjm-ord"),msg=document.getElementById("kjm-ord-msg"),AJ=' . wp_json_encode( admin_url( 'admin-ajax.php', 'relative' ) ) . ',N=' . wp_json_encode( wp_create_nonce( 'kjm_bpm' ) ) . ';
function save(){var G=[],T={};[].forEach.call(box.querySelectorAll(".kjm-og"),function(g){var n=g.getAttribute("data-g");G.push(n);T[n]=[].map.call(g.querySelectorAll(".kjm-ot"),function(t){return +t.getAttribute("data-id")})});
 var f=new FormData();f.append("action","kjm_save_order");f.append("_ajax_nonce",N);f.append("genres",JSON.stringify(G));f.append("tracks",JSON.stringify(T));msg.textContent="speichere …";
 fetch(AJ,{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json()}).then(function(j){msg.textContent=j&&j.success?"gespeichert ✓":"Fehler beim Speichern"}).catch(function(){msg.textContent="Fehler beim Speichern"})}
function mv(el,d){var o=d<0?el.previousElementSibling:el.nextElementSibling;if(!o)return false;if(d<0)el.parentNode.insertBefore(el,o);else el.parentNode.insertBefore(o,el);return true}
box.addEventListener("click",function(e){var b=e.target.closest("button");if(!b)return;var t=b.closest(".kjm-ot"),g=b.closest(".kjm-og");
 if(b.classList.contains("kjm-az")){var ul=g.querySelector("ul"),a=[].slice.call(ul.children);a.sort(function(x,y){return x.textContent.localeCompare(y.textContent,"de")});a.forEach(function(x){ul.appendChild(x)});save();return}
 var up=b.classList.contains("kjm-up");if(mv(t||g,up?-1:1))save()})})();</script>';
}

function kjm_rest_rate( WP_REST_Request $req ) {
	$id    = (int) $req['id'];
	$stars = (int) $req['stars'];
	$post  = get_post( $id );
	if ( ! kjm_is_audio( $post ) || ! kjm_visible( $id ) ) {
		return new WP_Error( 'kjm_song', 'Unbekannter Song.', array( 'status' => 404 ) );
	}
	if ( $stars < 1 || $stars > 5 ) {
		return new WP_Error( 'kjm_stars', 'Bitte 1 bis 5 Sterne.', array( 'status' => 400 ) );
	}
	// Mehrfach-Bewertungen verhindern: nur ein gekürzter, gesalzener Hash (keine IP im Klartext), 30 Tage.
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'kjm_v_' . substr( hash_hmac( 'sha256', $ip . '|' . $id, wp_salt( 'nonce' ) ), 0, 32 );
	if ( get_transient( $key ) ) {
		return new WP_Error( 'kjm_voted', 'Du hast diesen Song bereits bewertet.', array_merge( array( 'status' => 429 ), kjm_rating( $id ) ) );
	}
	set_transient( $key, 1, 30 * DAY_IN_SECONDS );
	$sum = (int) get_post_meta( $id, 'kjm_sum', true ) + $stars;
	$cnt = (int) get_post_meta( $id, 'kjm_count', true ) + 1;
	update_post_meta( $id, 'kjm_sum', $sum );
	update_post_meta( $id, 'kjm_count', $cnt );
	return rest_ensure_response(
		array(
			'id'    => $id,
			'avg'   => round( $sum / $cnt, 1 ),
			'count' => $cnt,
		)
	);
}

/* ---------------------------------------------------------------
 * Übersicht: Medien → Plattenkiste
 * ------------------------------------------------------------- */

add_action(
	'admin_menu',
	function () {
		add_media_page( 'Plattenkiste', 'Plattenkiste', 'upload_files', 'kjm-plattenkiste', 'kjm_admin_page' );
	}
);

function kjm_admin_page() {
	$posts = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'audio',
			'post_status'    => 'inherit',
			'posts_per_page' => 300,
			'no_found_rows'  => true,
		)
	);
	echo '<div class="wrap"><h1>Plattenkiste</h1>';
	if ( isset( $_GET['kjm_purge'] ) && current_user_can( 'manage_options' ) && wp_verify_nonce( isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '', 'kjm_purge' ) ) { // phpcs:ignore
		$d = kjm_purge_caches();
		echo '<div class="notice notice-success inline"><p>Zwischenspeicher geleert' . ( $d ? ': ' . esc_html( implode( ', ', $d ) ) : '' ) . '. Falls die Seite noch alt aussieht, zusätzlich den Cache deines Hosters leeren und die Seite neu laden.</p></div>';
	}
	foreach ( array( 'kjo_seiten' => 'kjo_seiten_sync', 'kjo_seiten_back' => 'kjo_seiten_restore' ) as $q => $fn ) {
		if ( isset( $_GET[ $q ] ) && current_user_can( 'manage_options' ) && wp_verify_nonce( isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '', $q ) ) { // phpcs:ignore
			$r = $fn();
			$l = array();
			foreach ( $r as $k => $v ) {
				$l[] = esc_html( $k . ': ' . $v );
			}
			echo '<div class="notice notice-success inline"><p>' . implode( ' · ', $l ) . '. ' . esc_html( implode( ', ', kjm_purge_caches() ) ) . ' geleert.</p></div>';
		}
	}
	if ( isset( $_POST['kjm_test_nonce'] ) && current_user_can( 'manage_options' ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kjm_test_nonce'] ) ), 'kjm_test' ) ) {
		$an = ! empty( $_POST['kjm_testdaten'] );
		if ( $an && ! kjm_testdaten() ) {
			update_option( 'kjm_testdaten_ab', time(), false );
		}
		update_option( 'kjm_testdaten', $an ? '1' : '', false );
		kjm_purge_caches();
		echo '<div class="notice notice-success inline"><p>' . ( $an ? 'Testdaten-Bewertungen sind an – im Pult als „Testdaten“ gekennzeichnet.' : 'Testdaten aus – das Pult zeigt wieder die echten Bewertungen.' ) . '</p></div>';
	}
	echo '<form method="post" style="margin:12px 0;padding:10px 14px;border-left:4px solid ' . ( kjm_testdaten() ? '#dba617' : '#c3c4c7' ) . ';background:#fff">' . wp_nonce_field( 'kjm_test', 'kjm_test_nonce', true, false ) . '<label><input type="checkbox" name="kjm_testdaten" value="1" ' . checked( kjm_testdaten(), true, false ) . '> <strong>Testdaten-Bewertungen anzeigen</strong></label> <button class="button">Speichern</button><br><span class="description">Zum Testen der Darstellung: bestehende Songs 300–500, neue 100–200 Bewertungen mit 4,0–5,0 Sternen. Im Pult steht an jeder Bewertung sichtbar „Testdaten“. Echte Bewertungen werden weiter gezählt und sind nach dem Ausschalten wieder zu sehen.</span></form>';
	echo '<p>So kommt ein Song ins DJ-Pult: MP3 unter <strong>Medien → Datei hinzufügen</strong> hochladen, Titel prüfen und ein <strong>Genre</strong> eintragen. Ein Video erscheint automatisch, wenn eine MP4 mit gleichem Dateinamen in der Mediathek liegt.</p>';
	kjo_update_box();
	echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'upload.php?page=kjm-plattenkiste&kjm_purge=1' ), 'kjm_purge' ) ) . '">Zwischenspeicher leeren</a> <span class="description">Wenn nach einem Update auf der Seite noch die alte Version erscheint.</span></p>';
	if ( glob( __DIR__ . '/seiten/*.json' ) ) {
		echo '<p><a class="button" onclick="return confirm(\'Die Seiten der Website (Start, Leistungen, Orte, Meine Musik, Über mich, FAQ, Kontakt, Einsatzgebiete) werden durch die neue Fassung ersetzt; bei Impressum und Datenschutz nur die Fußzeile. Der alte Inhalt wird gesichert. Fortfahren?\')" href="' . esc_url( wp_nonce_url( admin_url( 'upload.php?page=kjm-plattenkiste&kjo_seiten=1' ), 'kjo_seiten' ) ) . '">Seiten aus Vorlage einspielen</a> <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'upload.php?page=kjm-plattenkiste&kjo_seiten_back=1' ), 'kjo_seiten_back' ) ) . '">Letzten Stand wiederherstellen</a> <span class="description">Leistungs-, Orts- und weitere Seiten mit Galerie; der vorherige Inhalt wird gesichert.</span></p>';
	}
	$n = kjm_protect_sync();
	if ( false === $n ) {
		echo '<div class="notice notice-warning inline"><p><strong>Download-Schutz nur teilweise aktiv:</strong> Die Adressen der Songs sind versteckt, aber die Sperrdatei <code>wp-content/uploads/.htaccess</code> konnte nicht geschrieben werden.</p></div>';
	} else {
		echo '<div class="notice notice-success inline"><p><strong>Download-Schutz aktiv:</strong> ' . (int) $n . ' Datei(en) sind für den direkten Aufruf gesperrt. Das Pult spielt sie über zeitlich begrenzte Links ab.</p></div>';
	}
	echo '<p>Die Songs laufen im Pult in der Qualität, in der du sie hochlädst. Der direkte Download der Dateien ist gesperrt.</p>';
	kjm_order_box( $posts );
	echo '<p class="kjm-filter" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:16px 0 8px"><input type="search" id="kjm-f-q" placeholder="Titel suchen …" style="min-width:220px"> <select id="kjm-f-g" aria-label="Genre"><option value="">Alle Genres</option></select> <select id="kjm-f-p" aria-label="Im Pult"><option value="">Im Pult: alle</option><option value="ja">nur im Pult</option><option value="nein">nicht im Pult</option></select> <select id="kjm-f-r" aria-label="Release"><option value="">Release: alle</option><option value="offen">nur offen</option><option value="erl">nur erledigt</option></select> <span id="kjm-f-n" style="color:#646970"></span></p>';
	kjm_release_box();
	echo '<table class="widefat striped" id="kjm-tracks"><thead><tr><th>Titel</th><th>Genre</th><th>BPM</th><th>Tonart</th><th>Qualität</th><th>Video</th><th>Bewertung</th><th>Im Pult</th><th>Release</th><th></th></tr></thead><tbody>';
	if ( ! $posts ) {
		echo '<tr><td colspan="10">Noch keine MP3s in der Mediathek.</td></tr>';
	}
	foreach ( $posts as $p ) {
		$r   = kjm_rating( $p->ID );
		$bpm = get_post_meta( $p->ID, 'kjm_bpm', true );
		$key = kjm_key( $p->ID );
		echo '<tr><td>' . esc_html( $p->post_title ) . '</td><td>' . esc_html( kjm_genre( $p->ID ) ?: '–' ) . '</td><td><span class="kjm-bpm-val">' . esc_html( $bpm ?: '–' ) . '</span></td><td><span class="kjm-key-val">' . esc_html( $key ?: '–' ) . '</span> <button type="button" class="button button-small kjm-bpm-btn" data-id="' . (int) $p->ID . '" data-has="' . ( $bpm && $key && kjm_wave_get( $p->ID ) ? 1 : 0 ) . '" data-url="' . esc_url( wp_make_link_relative( (string) wp_get_attachment_url( $p->ID ) ) ) . '">erkennen</button></td><td>' . kjm_quality( $p->ID ) . '</td><td>' . ( kjm_video( $p->ID ) ? 'ja' : '–' ) . '</td><td>' . ( $r['count'] ? esc_html( number_format_i18n( $r['avg'], 1 ) . ' (' . $r['count'] . ')' ) : '–' ) . '</td><td>' . ( kjm_visible( $p->ID ) ? 'ja' : 'nein' ) . '</td><td>' . kjm_release_cell( $p->ID ) . '</td><td><a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">Bearbeiten</a></td></tr>';
	}
	echo '</tbody></table>';
	echo <<<'KJMTAB'
<style>#kjm-tracks th.kjm-s{cursor:pointer;user-select:none;white-space:nowrap}#kjm-tracks th.kjm-s:after{content:" ↕";color:#a7aaad;font-size:11px}#kjm-tracks th.kjm-asc:after{content:" ▲";color:#2271b1}#kjm-tracks th.kjm-desc:after{content:" ▼";color:#2271b1}</style>
<script>
/* Track-Liste: Spalten per Klick sortieren, nach Titel, Genre und „Im Pult“ filtern (seit 1.63.0) */
(function(){var t=document.getElementById("kjm-tracks");if(!t)return;var tb=t.tBodies[0],rows=[].slice.call(tb.rows).filter(function(r){return r.cells.length>1}),
 q=document.getElementById("kjm-f-q"),g=document.getElementById("kjm-f-g"),pu=document.getElementById("kjm-f-p"),fr=document.getElementById("kjm-f-r"),n=document.getElementById("kjm-f-n"),col=-1,dir=1;
function txt(r,i){return(r.cells[i]?r.cells[i].textContent:"").replace("neu erkennen","").replace("erkennen","").trim()}
function rel(r){var d=r.querySelector(".kjm-rel-d"),e=r.querySelector(".kjm-rel-e");return{d:d?d.value:"",e:!!(e&&e.checked)}}
function val(r,i){if(i===8){var x=rel(r);return x.d?(x.e?"0":"1")+x.d:(x.e?"0":null)}var s=txt(r,i),m;if(s===""||s==="–")return null;
 if(i===2||i===4){m=s.match(/[\d.,]+/);return m?parseFloat(m[0].replace(",",".")):null}
 if(i===3){m=s.match(/^(\d+)([AB])/i);return m?+m[1]*2+(m[2].toUpperCase()==="B"?1:0):null}
 if(i===6){m=s.match(/([\d,]+)\s*\((\d+)\)/);return m?parseFloat(m[1].replace(",","."))*1000+ +m[2]:null}
 return s.toLowerCase()}
[].forEach.call(t.tHead.rows[0].cells,function(th,i){if(i>8)return;th.classList.add("kjm-s");th.title="Sortieren";th.addEventListener("click",function(){dir=col===i?-dir:1;col=i;
 [].forEach.call(t.tHead.rows[0].cells,function(c){c.classList.remove("kjm-asc","kjm-desc")});th.classList.add(dir>0?"kjm-asc":"kjm-desc");
 rows.sort(function(a,b){var x=val(a,i),y=val(b,i);if(x===null&&y===null)return 0;if(x===null)return 1;if(y===null)return -1;
  return(typeof x==="number"?x-y:String(x).localeCompare(String(y),"de"))*dir}).forEach(function(r){tb.appendChild(r)})})});
var gs={};rows.forEach(function(r){var v=txt(r,1);gs[v]=1});Object.keys(gs).sort(function(a,b){return a.localeCompare(b,"de")}).forEach(function(v){var o=document.createElement("option");o.value=v;o.textContent=v==="–"?"(ohne Genre)":v;g.appendChild(o)});
function f(){var s=q.value.trim().toLowerCase(),k=0;rows.forEach(function(r){var ok=(!s||txt(r,0).toLowerCase().indexOf(s)>-1)&&(!g.value||txt(r,1)===g.value)&&(!pu.value||txt(r,7).toLowerCase()===pu.value)&&(!fr.value||(fr.value==="erl")===rel(r).e);r.style.display=ok?"":"none";if(ok)k++});
 n.textContent=k===rows.length?rows.length+" Songs":k+" von "+rows.length+" Songs"}
q.addEventListener("input",f);g.addEventListener("change",f);pu.addEventListener("change",f);fr.addEventListener("change",f);document.addEventListener("kjm:rel",f);f()})();
</script>
KJMTAB;
	echo '<p><button type="button" class="button button-primary" id="kjm-bpm-all">BPM &amp; Tonart für alle Songs ohne Angabe erkennen</button> <span id="kjm-bpm-msg"></span></p>';
	echo '<p class="description">Neue MP3s werden beim Hochladen automatisch analysiert (BPM und Tonart im Camelot-Format, z. B. 8A). Die Erkennung läuft in deinem Browser und dauert pro Song ein paar Sekunden. Stimmt ein Wert nicht (z. B. halbes oder doppeltes Tempo, Dur/Moll verwechselt), trag ihn beim Song von Hand ein.</p>';
	echo '</div>';
	$nonce = wp_create_nonce( 'kjm_bpm' );
	echo '<script>' . file_get_contents( __DIR__ . '/assets/kjm-bpm.js' ) . file_get_contents( __DIR__ . '/assets/kjm-admin.js' ) . // phpcs:ignore
		'(function(){var AJ=' . wp_json_encode( admin_url( 'admin-ajax.php', 'relative' ) ) . ',N=' . wp_json_encode( $nonce ) . ',msg=document.getElementById("kjm-bpm-msg");
function run(btn){var row=btn.parentNode.parentNode,bc=row.querySelector(".kjm-bpm-val"),kc=row.querySelector(".kjm-key-val");btn.disabled=true;btn.textContent="läuft …";
 return kjmAdmin.analyse(btn.getAttribute("data-url")).then(function(res){if(!res.bpm&&!res.key)throw new Error("weder Takt noch Tonart klar erkannt");
  return kjmAdmin.save(AJ,N,btn.getAttribute("data-id"),res).then(function(d){if(d.bpm)bc.textContent=d.bpm;if(d.key)kc.textContent=d.key;btn.setAttribute("data-has",d.bpm&&d.key?"1":"0");btn.textContent="neu erkennen";btn.disabled=false;return true})})
 .catch(function(e){btn.textContent="erkennen";btn.disabled=false;msg.textContent="Fehler: "+e.message;return false})}
[].forEach.call(document.querySelectorAll(".kjm-bpm-btn"),function(b){if(b.getAttribute("data-has")==="1")b.textContent="neu erkennen";b.addEventListener("click",function(){msg.textContent="";run(b)})});
document.getElementById("kjm-bpm-all").addEventListener("click",function(){var l=[].filter.call(document.querySelectorAll(".kjm-bpm-btn"),function(b){return b.getAttribute("data-has")!=="1"}),i=0,all=this,bad=0;
 if(!l.length){msg.textContent="Alle Songs haben schon BPM, Tonart und Wellenform.";return}all.disabled=true;
 (function next(){if(i>=l.length){all.disabled=false;msg.textContent="Fertig: "+(l.length-bad)+" erkannt"+(bad?", "+bad+" ohne klares Ergebnis (bitte von Hand eintragen).":".");return}msg.textContent="Song "+(i+1)+" von "+l.length+" …";run(l[i++]).then(function(ok){if(!ok)bad++;next()})})()});
/* Release-Spalte: Datum/erl. sofort speichern, „Termine planen“ füllt alle offenen Songs */
var rm=document.getElementById("kjm-rel-msg");function post(o){var f=new FormData();f.append("action","kjm_release");f.append("_ajax_nonce",N);for(var k in o)f.append(k,o[k]);return fetch(AJ,{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json()})}
function wd(inp){var v=inp.value,s=inp.parentNode.querySelector(".kjm-rel-w");if(!s){s=document.createElement("small");s.className="kjm-rel-w";inp.parentNode.appendChild(s)}var d=v?new Date(v+"T12:00:00"):null;s.textContent=d?" "+["So","Mo","Di","Mi","Do","Fr","Sa"][d.getDay()]:"";s.style.color=d&&d.getDay()!==2?"#b32d2e":"#646970"}
function rs(id){var d=document.querySelector(".kjm-rel-d[data-id=\""+id+"\"]"),e=document.querySelector(".kjm-rel-e[data-id=\""+id+"\"]");rm.textContent="speichere …";
 post({id:id,datum:d.value,erl:e.checked?1:""}).then(function(j){if(!j.success)throw 0;d.value=j.data.datum;wd(d);rm.textContent="gespeichert.";document.dispatchEvent(new Event("kjm:rel"))}).catch(function(){rm.textContent="Speichern fehlgeschlagen."})}
[].forEach.call(document.querySelectorAll(".kjm-rel-d"),function(d){wd(d);d.addEventListener("change",function(){rs(d.getAttribute("data-id"))})});
[].forEach.call(document.querySelectorAll(".kjm-rel-e"),function(e){e.addEventListener("change",function(){rs(e.getAttribute("data-id"))})});
var pb=document.getElementById("kjm-rel-plan");if(pb)pb.addEventListener("click",function(){if(!confirm("Alle offenen Songs (ohne „erl.“) bekommen neue Termine: ab dem nächsten freien Dienstag, ein Song pro Woche, in der Reihenfolge des Pults. Von Hand eingetragene Termine offener Songs werden dabei überschrieben. Fortfahren?"))return;pb.disabled=true;rm.textContent="plane …";
 post({plan:1}).then(function(j){pb.disabled=false;if(!j.success)throw 0;var k=0;for(var id in j.data){var d=document.querySelector(".kjm-rel-d[data-id=\""+id+"\"]");if(d){d.value=j.data[id];wd(d);k++}}rm.textContent=k+" Termine geplant. Die Anzeige „Nächster Release“ aktualisiert sich beim Neuladen.";document.dispatchEvent(new Event("kjm:rel"))}).catch(function(){pb.disabled=false;rm.textContent="Planen fehlgeschlagen."})});
})();</script>';
}

/* Speichert die Reihenfolge der Genres und der Songs pro Genre. */
add_action(
	'wp_ajax_kjm_save_order',
	function () {
		check_ajax_referer( 'kjm_bpm' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( null, 403 );
		}
		$g = json_decode( (string) wp_unslash( $_POST['genres'] ?? '' ), true ); // phpcs:ignore
		$t = json_decode( (string) wp_unslash( $_POST['tracks'] ?? '' ), true ); // phpcs:ignore
		if ( ! is_array( $g ) || ! is_array( $t ) ) {
			wp_send_json_error( null, 400 );
		}
		update_option( 'kjm_genre_order', array_values( array_map( 'sanitize_text_field', $g ) ), false );
		foreach ( $t as $ids ) {
			foreach ( (array) $ids as $pos => $id ) {
				$id = (int) $id;
				if ( $id && current_user_can( 'edit_post', $id ) && kjm_is_audio( get_post( $id ) ) ) {
					update_post_meta( $id, 'kjm_order', (int) $pos + 1 );
				}
			}
		}
		wp_send_json_success();
	}
);

/* Speichert BPM und/oder Tonart (vom Browser erkannt). Ohne Werte (fail=1): nur „offen“-Markierung löschen. */
add_action(
	'wp_ajax_kjm_save_bpm',
	function () {
		check_ajax_referer( 'kjm_bpm' );
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( ! $id || ! current_user_can( 'edit_post', $id ) || ! kjm_is_audio( get_post( $id ) ) ) {
			wp_send_json_error( null, 400 );
		}
		$out = array();
		$bpm = isset( $_POST['bpm'] ) ? (int) $_POST['bpm'] : 0;
		if ( $bpm >= 40 && $bpm <= 220 ) {
			update_post_meta( $id, 'kjm_bpm', $bpm );
			$out['bpm'] = $bpm;
		}
		$key = isset( $_POST['key'] ) ? kjm_key_clean( wp_unslash( $_POST['key'] ) ) : '';
		if ( '' !== $key ) {
			update_post_meta( $id, 'kjm_key', $key );
			$out['key'] = $key;
		}
		if ( isset( $_POST['wave'] ) ) {
			$w = kjm_wave_clean( json_decode( (string) wp_unslash( $_POST['wave'] ), true ) ); // phpcs:ignore
			if ( $w ) {
				update_post_meta( $id, 'kjm_wave', wp_slash( wp_json_encode( $w ) ) );
				$out['wave'] = 1;
			}
		}
		delete_post_meta( $id, 'kjm_pending' );
		wp_send_json_success( $out );
	}
);

/* Neue Audio-Uploads vormerken; ein Browser mit offener Mediathek analysiert sie automatisch. */
add_action(
	'add_attachment',
	function ( $id ) {
		if ( kjm_is_audio( get_post( $id ) ) ) {
			update_post_meta( $id, 'kjm_pending', '1' );
		}
	}
);
/* Einmalig nach dem Update: vorhandene Songs ohne Tonart zur automatischen Erkennung vormerken. */
add_action(
	'admin_init',
	function () {
		if ( '1' === get_option( 'kjm_key_mig' ) || ! current_user_can( 'upload_files' ) ) {
			return;
		}
		$ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'audio',
				'post_status'    => 'inherit',
				'posts_per_page' => 300,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		foreach ( $ids as $id ) {
			if ( '' === kjm_key( $id ) ) {
				update_post_meta( $id, 'kjm_pending', '1' );
			}
		}
		update_option( 'kjm_key_mig', '1', false );
	}
);
/* Einmalig nach dem Update: vorhandene Songs ohne Wellenform zur automatischen Analyse vormerken. */
add_action(
	'admin_init',
	function () {
		if ( '1' === get_option( 'kjm_wave_mig' ) || ! current_user_can( 'upload_files' ) ) {
			return;
		}
		$ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'audio',
				'post_status'    => 'inherit',
				'posts_per_page' => 300,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		foreach ( $ids as $id ) {
			if ( ! kjm_wave_get( $id ) ) {
				update_post_meta( $id, 'kjm_pending', '1' );
			}
		}
		update_option( 'kjm_wave_mig', '1', false );
	}
);
add_action(
	'wp_ajax_kjm_pending',
	function () {
		check_ajax_referer( 'kjm_bpm' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( null, 403 );
		}
		$ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'audio',
				'post_status'    => 'inherit',
				'meta_key'       => 'kjm_pending', // phpcs:ignore
				'meta_value'     => '1', // phpcs:ignore
				'posts_per_page' => 5,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$out = array();
		foreach ( $ids as $id ) {
			$out[] = array(
				'id'    => (int) $id,
				'url'   => wp_make_link_relative( (string) wp_get_attachment_url( $id ) ),
				'titel' => get_the_title( $id ),
				'bpm'   => (int) get_post_meta( $id, 'kjm_bpm', true ),
				'key'   => kjm_key( $id ),
			);
		}
		wp_send_json_success( $out );
	}
);
add_action(
	'admin_footer',
	function () {
		global $pagenow;
		if ( ! current_user_can( 'upload_files' ) || ! in_array( $pagenow, array( 'upload.php', 'media-new.php', 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		if ( 'upload.php' === $pagenow && isset( $_GET['page'] ) && 'kjm-plattenkiste' === $_GET['page'] ) { // phpcs:ignore
			return; // Dort gibt es den Knopf „erkennen“.
		}
		echo '<script>' . file_get_contents( __DIR__ . '/assets/kjm-bpm.js' ) . file_get_contents( __DIR__ . '/assets/kjm-admin.js' ) . // phpcs:ignore
			'(function(){var AJ=' . wp_json_encode( admin_url( 'admin-ajax.php', 'relative' ) ) . ',N=' . wp_json_encode( wp_create_nonce( 'kjm_bpm' ) ) . ',busy=false,box=null,tried={};
function toast(t){if(!box){box=document.createElement("div");box.style.cssText="position:fixed;right:20px;bottom:20px;z-index:200000;background:#1d2327;color:#fff;padding:10px 14px;border-radius:4px;font-size:13px;box-shadow:0 2px 8px rgba(0,0,0,.3)";document.body.appendChild(box)}box.textContent=t;box.style.display=t?"block":"none"}
function check(){if(busy)return;busy=true;fetch(AJ+"?action=kjm_pending&_wpnonce="+encodeURIComponent(N),{credentials:"same-origin"}).then(function(r){return r.json()}).then(function(j){
  var l=((j&&j.success&&j.data)||[]).filter(function(x){return !tried[x.id]});if(!l.length){busy=false;if(box)setTimeout(function(){toast("")},4000);return}
  var i=0;(function next(){if(i>=l.length){busy=false;toast("Plattenkiste: BPM, Tonart und Wellenform erkannt ✓");setTimeout(check,500);return}var s=l[i++];tried[s.id]=1;toast("Plattenkiste: analysiere (BPM, Tonart, Wellenform) – "+s.titel+" …");
   kjmAdmin.analyse(s.url,s).then(function(res){return kjmAdmin.save(AJ,N,s.id,res)}).catch(function(){return kjmAdmin.save(AJ,N,s.id,{})}).then(next,next)})()}).catch(function(){busy=false})}
check();setInterval(check,15000);
})();</script>';
	}
);

/* Musik-Pult: Das Plugin liefert immer die aktuelle Version des Pults aus,
 * egal welcher Stand im HTML-Widget der Seite „Meine Musik“ gespeichert ist. */
function kjm_deck_html() {
	$file = __DIR__ . '/assets/musikpult.html';
	if ( ! is_readable( $file ) ) {
		return '';
	}
	$api = wp_make_link_relative( rest_url( 'kjm/v1' ) );
	return '<script>window.KJM_API=' . wp_json_encode( untrailingslashit( $api ) ) . ';</script>' . file_get_contents( $file ); // phpcs:ignore
}
/* Start-Pult (Startseite): ebenfalls immer die aktuelle Version aus dem Plugin ausliefern. */
function kjo_start_deck_html() {
	$file = __DIR__ . '/assets/startdeck.html';
	return is_readable( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore
}
add_filter(
	'elementor/widget/render_content',
	function ( $content, $widget ) {
		if ( is_object( $widget ) && method_exists( $widget, 'get_name' ) && 'html' === $widget->get_name() ) {
			if ( false !== strpos( (string) $content, 'id="kjm"' ) ) {
				$deck = kjm_deck_html();
				if ( '' !== $deck ) {
					return $deck;
				}
			}
			if ( false !== strpos( (string) $content, 'id="kjv"' ) && preg_match( '/id="kjv" data-key="([a-z0-9_,]+)"/', (string) $content, $km ) ) {
				$file = __DIR__ . '/assets/galerie.html';
				if ( is_readable( $file ) ) {
					return str_replace( '__KEY__', $km[1], (string) file_get_contents( $file ) ); // phpcs:ignore
				}
			}
			if ( false !== strpos( (string) $content, 'id="kjoSvg"' ) ) {
				$deck = kjo_start_deck_html();
				if ( '' !== $deck ) {
					return $deck;
				}
			}
		}
		return $content;
	},
	10,
	2
);
add_shortcode( 'kjo_startpult', 'kjo_start_deck_html' );

/* QR-Code zum Bewerten in der Mediathek (seit 1.48.0): Generator lokal (qrcode-generator, MIT), keine externen Dienste. */
add_action(
	'admin_enqueue_scripts',
	function ( $hook ) {
		if ( ! current_user_can( 'upload_files' ) || ! in_array( $hook, array( 'upload.php', 'post.php' ), true ) ) {
			return;
		}
		wp_enqueue_script( 'kjm-qrcode', plugins_url( 'assets/qrcode.js', __FILE__ ), array(), KJO_VERSION, true );
		wp_add_inline_script( 'kjm-qrcode', <<<'KJMQR'
(function(){function draw(el){if(el.getAttribute("data-done")||typeof qrcode!=="function")return;el.setAttribute("data-done","1");var u=el.getAttribute("data-url"),t=el.getAttribute("data-titel")||"";
 var q=qrcode(0,"M");q.addData(u);q.make();var n=q.getModuleCount(),W=1200,cell=Math.floor((W-180)/n),qs=cell*n,off=Math.floor((W-qs)/2),H=W+250;
 var c=document.createElement("canvas");c.width=W;c.height=H;var x=c.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,W,H);x.fillStyle="#0F0C07";
 for(var r=0;r<n;r++)for(var k=0;k<n;k++)if(q.isDark(r,k))x.fillRect(off+k*cell,off+r*cell,cell,cell);
 x.textAlign="center";x.font="600 66px sans-serif";x.fillText("★★★★★  Song bewerten",W/2,W+60);x.font="46px sans-serif";x.fillText(t.length>42?t.slice(0,41)+"…":t,W/2,W+135);x.fillStyle="#8C7650";x.font="38px sans-serif";x.fillText("DJ KOLJA ONE · dj-kolja-one.de",W/2,W+205);
 var d=c.toDataURL("image/png"),img=new Image();img.src=d;img.alt="QR-Code";img.style.cssText="width:170px;height:auto;border:1px solid #ccd0d4;display:block;margin:4px 0 6px";
 var a=document.createElement("a");a.href=d;a.download=el.getAttribute("data-file")||"qr-bewerten.png";a.className="button";a.textContent="Als PNG herunterladen";el.appendChild(img);el.appendChild(a)}
 function scan(){[].forEach.call(document.querySelectorAll(".kjm-qr:not([data-done])"),draw)}
 scan();if(window.MutationObserver)new MutationObserver(scan).observe(document.body,{childList:true,subtree:true})})();
KJMQR
		);
	}
);
add_shortcode( 'kjo_musikpult', 'kjm_deck_html' );


/* ------------------------------------------------------------------
 * Bild-/Video-Platzhalter (seit 1.2.0)
 * Dateien in der Mediathek, die start_*, event_*, ueber_*, kolja_*, equip_*, paket_* oder
 * region_* heissen, werden automatisch dem gleichnamigen Platzhalter
 * zugeordnet. Bild = Hintergrund, Video = Player mit Start/Stop-Knopf.
 * ------------------------------------------------------------------ */
/** Startseiten-Video aus dem Plugin ergänzen (außerhalb des Zwischenspeichers, damit es nie fehlt). Mediathek hat Vorrang. */
function kjo_media_motion( $map ) {
	foreach ( array( 'start_motion', 'start_motion_hoch' ) as $k ) {
		if ( empty( $map[ $k ]['vid'] ) && file_exists( __DIR__ . '/assets/motion/' . $k . '.mp4' ) ) {
			$map[ $k ] = array(
				'vid' => plugins_url( 'assets/motion/' . $k . '.mp4', __FILE__ ) . '?v=1',
				'img' => plugins_url( 'assets/motion/' . $k . '.jpg', __FILE__ ) . '?v=1',
			);
		}
	}
	/* Intro-Videos der Seiten (seit 1.65.0) aus assets/intro/ – gleichnamige Dateien in der Mediathek (intro_hochzeit.mp4 …) haben Vorrang. */
	foreach ( (array) glob( __DIR__ . '/assets/intro/intro_*.mp4' ) as $f ) {
		$k = basename( $f, '.mp4' );
		if ( empty( $map[ $k ]['vid'] ) ) {
			$v         = (string) filemtime( $f );
			$map[ $k ] = array( 'vid' => plugins_url( 'assets/intro/' . $k . '.mp4', __FILE__ ) . '?v=' . $v );
			if ( file_exists( __DIR__ . '/assets/intro/' . $k . '.jpg' ) ) {
				$map[ $k ]['img'] = plugins_url( 'assets/intro/' . $k . '.jpg', __FILE__ ) . '?v=' . $v;
			}
		}
	}
	return $map;
}
function kjo_media_map() {
	$map = get_transient( 'kjo_media_map6' );
	if ( is_array( $map ) ) {
		return $map;
	}
	$map = array();
	$ids = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => array( 'image', 'video' ),
			'posts_per_page' => 2000,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
		)
	);
	foreach ( $ids as $id ) {
		$file = get_post_meta( $id, '_wp_attached_file', true );
		if ( ! $file ) {
			continue;
		}
		$base = strtolower( wp_basename( $file ) );
		if ( ! preg_match( '/^((?:start|event|ueber|kolja|region|equip|paket|intro)_[a-z0-9_]+?)(?:-scaled|-rotated|-frei|-\d+)*(?:\.(?:jpe?g|png|webp|gif|mp4|m4v|webm|mov)_?)*\.(jpe?g|png|webp|gif|mp4|m4v|webm|mov)$/', $base, $m ) ) {
			continue;
		}
		$kind = in_array( $m[2], array( 'mp4', 'm4v', 'webm', 'mov' ), true ) ? 'vid' : 'img';
		$url  = 'img' === $kind && function_exists( 'kjo_img_web_url' ) ? kjo_img_web_url( $id ) : wp_get_attachment_url( $id ); // Fotos in Web-Größe statt Original
		if ( $url ) {
			$map[ $m[1] ][ $kind ] = set_url_scheme( $url );
			if ( 'img' === $kind && function_exists( 'kjo_img_small_url' ) && ( $sm = kjo_img_small_url( $id ) ) ) { // phpcs:ignore
				$map[ $m[1] ]['sm'] = set_url_scheme( $sm );
			}
			if ( 'img' === $kind && 0 === strpos( $m[1], 'equip_' ) ) {
				$map[ $m[1] ]['full'] = set_url_scheme( wp_get_attachment_url( $id ) ); // Originalgröße für die Vergrößerung (Pläne mit kleiner Schrift)
			}
			$h = (int) get_post_meta( $id, 'kjo_h', true );
			if ( $h && ( 'vid' === $kind || empty( $map[ $m[1] ]['h'] ) ) ) {
				$map[ $m[1] ]['h'] = $h; // Video hat Vorrang, wenn beide eine Höhe haben.
			}
		}
	}
	/* Ortsbild ohne Nummer (z. B. event_biberach.jpg) zählt als Platz 1. */
	foreach ( array_keys( $map ) as $k ) {
		if ( preg_match( '/^event_[a-z_]+$/', $k ) && ! preg_match( '/_(text|\d+)$/', $k ) && ! isset( $map[ $k . '_1' ] ) ) {
			$map[ $k . '_1' ] = $map[ $k ];
		}
	}
	set_transient( 'kjo_media_map6', $map, DAY_IN_SECONDS );
	return $map;
}
function kjo_media_flush() {
	delete_transient( 'kjo_media_map5' );
}
add_action( 'add_attachment', 'kjo_media_flush' );
add_action( 'edit_attachment', 'kjo_media_flush' );
add_action( 'delete_attachment', 'kjo_media_flush' );
add_filter(
	'wp_update_attachment_metadata',
	function ( $data ) {
		kjo_media_flush();
		return $data;
	}
);

add_action(
	'wp_head',
	function () {
		if ( is_admin() || ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->preview ) && \Elementor\Plugin::$instance->preview->is_preview_mode() ) ) {
			return;
		}
		/* Platzhalter ohne Bild/Video werden gar nicht erst angezeigt (kein Leerraum). */
		$keep = '';
		foreach ( kjo_media_map() as $name => $e ) {
			if ( ! empty( $e['img'] ) || ! empty( $e['vid'] ) ) {
				$keep .= ':not(.kjo-m-' . preg_replace( '/[^a-z0-9_]/', '', (string) $name ) . ')';
			}
		}
		echo '<style id="kjo-media-hide">[class*="kjo-m-"]:not(.kjo-tile)' . $keep . '{display:none!important}</style>' . "\n"; // phpcs:ignore
	},
	5
);

add_action(
	'wp_footer',
	function () {
		if ( is_admin() ) {
			return;
		}
		echo '<style id="kjo-media-css">' . KJO_MEDIA_CSS . '</style>';
		echo '<script id="kjo-media-js">window.KJO_MEDIA=' . wp_json_encode( (object) kjo_media_motion( kjo_media_map() ) ) . ';' . KJO_MEDIA_JS . '</script>';
	},
	50
);


/* ------------------------------------------------------------------
 * Download-Schutz (seit 1.3.0)
 * 1) Das Pult bekommt nur zeitlich begrenzte, signierte Links.
 * 2) Der direkte Aufruf der Song-Dateien wird per .htaccess gesperrt
 *    (angemeldete Admins können sie in der Mediathek weiter anhören).
 * ------------------------------------------------------------------ */
function kjm_quality( $id ) {
	$m = wp_get_attachment_metadata( $id );
	if ( empty( $m['bitrate'] ) ) {
		return '–';
	}
	$k = (int) round( $m['bitrate'] / 1000 );
	return $k . ' kbps';
}

function kjm_url_to_path( $url ) {
	$up = wp_get_upload_dir();
	$a  = preg_replace( '#^https?:#i', '', $up['baseurl'] );
	$b  = preg_replace( '#^https?:#i', '', (string) $url );
	if ( '' === $b || 0 !== strpos( $b, $a . '/' ) ) {
		return '';
	}
	$rel = ltrim( substr( $b, strlen( $a ) ), '/' );
	if ( false !== strpos( $rel, '..' ) ) {
		return '';
	}
	return trailingslashit( $up['basedir'] ) . $rel;
}

function kjm_stream_path( $id, $kind ) {
	if ( 'v' === $kind ) {
		return kjm_url_to_path( kjm_video( $id ) );
	}
	return (string) get_attached_file( $id );
}

function kjm_sig( $id, $kind, $exp ) {
	return substr( hash_hmac( 'sha256', $id . '|' . $kind . '|' . $exp, wp_salt( 'auth' ) ), 0, 32 );
}

function kjm_stream_url( $id, $kind ) {
	if ( 'v' === $kind ) {
		$v = kjm_video( $id );
		if ( '' === $v ) {
			return '';
		}
		if ( '' === kjm_url_to_path( $v ) ) {
			return $v; // externes Video: unverändert.
		}
	}
	$exp = (int) ( ceil( ( time() + 3 * HOUR_IN_SECONDS ) / HOUR_IN_SECONDS ) * HOUR_IN_SECONDS );
	return add_query_arg(
		array(
			'kjm_stream' => (int) $id,
			'k'          => $kind,
			'e'          => $exp,
			'sig'        => kjm_sig( (int) $id, $kind, $exp ),
		),
		wp_make_link_relative( home_url( '/' ) )
	);
}

add_action(
	'init',
	function () {
		if ( ! isset( $_GET['kjm_stream'] ) ) { // phpcs:ignore
			return;
		}
		$id   = (int) $_GET['kjm_stream']; // phpcs:ignore
		$kind = isset( $_GET['k'] ) && 'v' === $_GET['k'] ? 'v' : 'a'; // phpcs:ignore
		$exp  = isset( $_GET['e'] ) ? (int) $_GET['e'] : 0; // phpcs:ignore
		$sig  = isset( $_GET['sig'] ) ? (string) wp_unslash( $_GET['sig'] ) : ( isset( $_GET['s'] ) ? (string) wp_unslash( $_GET['s'] ) : '' ); // phpcs:ignore
		$deny = function ( $code ) {
			status_header( $code );
			nocache_headers();
			header( 'Content-Type: text/plain; charset=utf-8' );
			echo 403 === $code ? 'Nicht erlaubt.' : 'Nicht gefunden.';
			exit;
		};
		if ( $exp < time() || ! hash_equals( kjm_sig( $id, $kind, $exp ), $sig ) ) {
			$deny( 403 );
		}
		// Direkter Aufruf in der Adresszeile / fremde Seiten.
		// Nur echte Seitenaufrufe sperren (Adresszeile). Audio-/Video-Player senden nie "navigate".
		$mode = isset( $_SERVER['HTTP_SEC_FETCH_MODE'] ) ? strtolower( (string) $_SERVER['HTTP_SEC_FETCH_MODE'] ) : '';
		if ( 'navigate' === $mode ) {
			$deny( 403 );
		}
		$ref = isset( $_SERVER['HTTP_REFERER'] ) ? (string) $_SERVER['HTTP_REFERER'] : '';
		if ( '' !== $ref ) {
			$rh = strtolower( (string) wp_parse_url( $ref, PHP_URL_HOST ) );
			$hh = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
			$qh = isset( $_SERVER['HTTP_HOST'] ) ? strtolower( preg_replace( '/:\d+$/', '', (string) $_SERVER['HTTP_HOST'] ) ) : '';
			$rh = preg_replace( '/^www\./', '', $rh );
			if ( $rh !== preg_replace( '/^www\./', '', $hh ) && $rh !== preg_replace( '/^www\./', '', $qh ) ) {
				$deny( 403 );
			}
		}
		$post = get_post( $id );
		if ( ! kjm_is_audio( $post ) || ! kjm_visible( $id ) ) {
			$deny( 404 );
		}
		$path = kjm_stream_path( $id, $kind );
		if ( '' === $path || ! is_file( $path ) || ! is_readable( $path ) ) {
			$deny( 404 );
		}
		$size  = filesize( $path );
		$start = 0;
		$end   = $size - 1;
		$code  = 200;
		if ( isset( $_SERVER['HTTP_RANGE'] ) && preg_match( '/bytes=(\d*)-(\d*)/', (string) $_SERVER['HTTP_RANGE'], $m ) ) {
			if ( '' === $m[1] && '' !== $m[2] ) {
				$start = max( 0, $size - (int) $m[2] );
			} else {
				$start = (int) $m[1];
				if ( '' !== $m[2] ) {
					$end = min( $end, (int) $m[2] );
				}
			}
			if ( $start > $end || $start >= $size ) {
				status_header( 416 );
				header( 'Content-Range: bytes */' . $size );
				exit;
			}
			$code = 206;
		}
		$type = wp_check_filetype( $path );
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 0 ); // phpcs:ignore
		}
		status_header( $code );
		header( 'Content-Type: ' . ( $type['type'] ? $type['type'] : 'application/octet-stream' ) );
		header( 'Accept-Ranges: bytes' );
		header( 'Content-Length: ' . ( $end - $start + 1 ) );
		if ( 206 === $code ) {
			header( 'Content-Range: bytes ' . $start . '-' . $end . '/' . $size );
		}
		header( 'Content-Disposition: inline' );
		header( 'Cache-Control: private, max-age=3600' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Robots-Tag: noindex' );
		if ( 'HEAD' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) ) {
			exit;
		}
		$fh = fopen( $path, 'rb' ); // phpcs:ignore
		fseek( $fh, $start );
		$left = $end - $start + 1;
		while ( $left > 0 && ! feof( $fh ) && ! connection_aborted() ) {
			$chunk = fread( $fh, (int) min( 262144, $left ) ); // phpcs:ignore
			if ( false === $chunk ) {
				break;
			}
			echo $chunk; // phpcs:ignore
			$left -= strlen( $chunk );
			flush();
		}
		fclose( $fh ); // phpcs:ignore
		exit;
	},
	1
);

/** Impressum: USt-IdNr. vor den Hinweis zur Kleinunternehmerregelung setzen, falls sie dort noch fehlt (seit 1.64.0). */
function kjo_impressum_ustid( $el ) {
	if ( is_array( $el ) ) {
		foreach ( $el as $k => $v ) {
			$el[ $k ] = kjo_impressum_ustid( $v );
		}
		return $el;
	}
	if ( is_string( $el ) && false !== strpos( $el, 'Gemäß § 19 UStG' ) && false === strpos( $el, KJO_USTID ) ) {
		$el = preg_replace( '/(<p>)?(Gemäß § 19 UStG)/u', '$1Umsatzsteuer-Identifikationsnummer gemäß § 27a UStG: ' . KJO_USTID . '<br>$2', $el, 1 );
	}
	return $el;
}

/** Sperrliste in wp-content/uploads/.htaccess schreiben. Rückgabe: Anzahl gesperrter Dateien oder false. */
function kjm_protect_sync( $remove = false ) {
	$up    = wp_get_upload_dir();
	$base  = trailingslashit( $up['basedir'] );
	$files = array();
	if ( ! $remove ) {
		$ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_mime_type' => 'audio',
				'post_status'    => 'inherit',
				'posts_per_page' => 300,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		foreach ( $ids as $id ) {
			foreach ( array( (string) get_attached_file( $id ), kjm_url_to_path( kjm_video( $id ) ) ) as $f ) {
				if ( '' !== $f && 0 === strpos( $f, $base ) ) {
					$files[ substr( $f, strlen( $base ) ) ] = 1;
				}
			}
		}
	}
	$lines = array();
	if ( $files ) {
		$lines[] = '<IfModule mod_rewrite.c>';
		$lines[] = 'RewriteEngine On';
		foreach ( array_keys( $files ) as $rel ) {
			$lines[] = 'RewriteCond %{HTTP_COOKIE} !wordpress_logged_in_ [NC]';
			$lines[] = 'RewriteRule ^' . str_replace( ' ', '\\ ', preg_quote( $rel, '#' ) ) . '$ - [F,L]';
		}
		$lines[] = '</IfModule>';
	}
	$sum = md5( implode( "\n", $lines ) );
	if ( ! $remove && get_option( 'kjm_protect_sum' ) === $sum && file_exists( $base . '.htaccess' ) ) {
		return count( $files );
	}
	if ( ! function_exists( 'insert_with_markers' ) ) {
		require_once ABSPATH . 'wp-admin/includes/misc.php';
	}
	if ( ! is_dir( $base ) || ! insert_with_markers( $base . '.htaccess', 'DJ KOLJA ONE Plattenkiste', $lines ) ) {
		return false;
	}
	update_option( 'kjm_protect_sum', $sum, false );
	return count( $files );
}
function kjm_protect_later() {
	if ( ! has_action( 'shutdown', 'kjm_protect_run' ) ) {
		add_action( 'shutdown', 'kjm_protect_run' );
	}
}
function kjm_protect_run() {
	kjm_protect_sync();
}
add_action( 'add_attachment', 'kjm_protect_later' );
add_action( 'edit_attachment', 'kjm_protect_later' );
add_action( 'deleted_post', 'kjm_protect_later' );
add_action(
	'admin_init',
	function () {
		if ( '1.5.1' !== get_option( 'kjm_ver' ) ) {
			update_option( 'kjm_ver', '1.5.1', false );
			kjm_protect_later();
		}
	}
);
register_activation_hook( __FILE__, 'kjm_protect_run' );
register_deactivation_hook(
	__FILE__,
	function () {
		kjm_protect_sync( true );
		delete_option( 'kjm_protect_sum' );
	}
);


/* ------------------------------------------------------------------
 * Icons, Teilen-Vorschau und Suchmaschinen-Angaben (seit 1.6.0)
 * ------------------------------------------------------------------ */
function kjo_asset( $file ) {
	return plugins_url( 'assets/' . $file, __FILE__ );
}

function kjo_has_seo_plugin() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || class_exists( 'The_SEO_Framework\Load' );
}

/** Kurzbeschreibung je Seite (für Google und für die Vorschau beim Teilen). */
function kjo_description() {
	$map = array(
		'start'          => 'DJ KOLJA ONE – Premium DJ mit professioneller Moderation für Hochzeiten, Geburtstage, Firmenfeiern und Events in Oberschwaben, Ulm und dem Allgäu. Jetzt Wunschtermin prüfen.',
		'hochzeits-dj'   => 'Hochzeits-DJ für Memmingen, Ulm und das Allgäu: persönliche Musikplanung, professionelle Moderation und eine volle Tanzfläche – vom ersten Song bis zum letzten.',
		'geburtstags-dj' => 'Geburtstags-DJ für runde Geburtstage und private Feiern: Musik für alle Generationen, geprüfte Technik und Moderation auf Wunsch.',
		'firmenfeier-dj' => 'DJ für Firmenfeiern, Weihnachtsfeiern, Sommerfeste und Galas: Musik und Moderation, abgestimmt auf euren Ablauf und eure Gäste.',
		'event-dj'       => 'Event-DJ für Stadtfeste, Vereinsfeiern, Open Airs und Silvesterpartys – mit skalierbarer Technik und professioneller Moderation.',
		'meine-musik'    => 'Legt selbst auf: Am interaktiven DJ-Pult könnt ihr eigene Songs von DJ KOLJA ONE anhören, mixen und mit Sternen bewerten.',
		'ueber-mich'     => 'Über DJ KOLJA ONE: seit über 10 Jahren DJ und Moderator aus Fellheim bei Memmingen. Jedes Event findet nur einmal statt.',
		'faq'            => 'Häufige Fragen zu Buchung, Kosten, Musikwünschen, Technik und Ablauf – kurz und ehrlich beantwortet von DJ KOLJA ONE.',
		'einsatzgebiete' => 'Mobiler DJ für Memmingen, Ulm, Neu-Ulm, Biberach, Ravensburg, Kempten, Füssen, Kaufbeuren, Landsberg und Umgebung.',
		'kontakt'        => 'Wunschtermin unverbindlich anfragen: per Formular, Telefon oder WhatsApp. Ich melde mich innerhalb von 24 Stunden.',
	);
	if ( is_front_page() ) {
		return $map['start'];
	}
	if ( is_singular() ) {
		$post = get_queried_object();
		if ( $post && isset( $map[ $post->post_name ] ) ) {
			return $map[ $post->post_name ];
		}
		if ( $post && 0 === strpos( $post->post_name, 'dj-' ) ) {
			return get_the_title( $post ) . ' – DJ KOLJA ONE für Hochzeit, Geburtstag, Firmenfeier und Event in der Region. Persönliche Planung, professionelle Moderation, geprüfte Technik.';
		}
		if ( $post && has_excerpt( $post ) ) {
			return wp_strip_all_tags( get_the_excerpt( $post ) );
		}
	}
	return 'DJ KOLJA ONE – Premium DJ für Hochzeiten, Firmenevents und besondere Feste. Jedes Event findet nur einmal statt.';
}

// Sicherheitsheader (seit 1.44.1) – bewusst ohne Content-Security-Policy, damit Elementor, YouTube, GA4 und Clarity weiterlaufen.
add_action(
	'send_headers',
	function () {
		if ( headers_sent() || is_admin() ) {
			return;
		}
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		if ( is_ssl() ) {
			header( 'Strict-Transport-Security: max-age=' . (int) apply_filters( 'kjo_hsts_max_age', 2592000 ) ); // 30 Tage, ohne Subdomains
		}
	}
);

// Eigene Icons statt des WordPress-Standards.
add_action(
	'init',
	function () {
		remove_action( 'wp_head', 'wp_site_icon', 99 );
	}
);
add_action(
	'do_faviconico',
	function () {
		// Direkt ausliefern statt umleiten: Google holt /favicon.ico gern ohne Weiterleitung.
		$f = __DIR__ . '/assets/favicon.ico';
		if ( is_readable( $f ) ) {
			header( 'Content-Type: image/x-icon' );
			header( 'Cache-Control: public, max-age=604800' );
			readfile( $f ); // phpcs:ignore
			exit;
		}
		wp_safe_redirect( kjo_asset( 'favicon.ico' ), 301 );
		exit;
	},
	1
);

add_action(
	'wp_head',
	function () {
		echo "\n" . '<link rel="icon" href="' . esc_url( kjo_asset( 'favicon.ico' ) ) . '" sizes="48x48">' . "\n";
		echo '<link rel="icon" href="' . esc_url( kjo_asset( 'icon-192.png' ) ) . '" type="image/png" sizes="192x192">' . "\n";
		echo '<link rel="icon" href="' . esc_url( kjo_asset( 'icon.svg' ) ) . '" type="image/svg+xml">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url( kjo_asset( 'apple-touch-icon.png' ) ) . '">' . "\n";
		echo '<link rel="manifest" href="' . esc_url( kjo_asset( 'site.webmanifest' ) ) . '">' . "\n";
		echo '<meta name="theme-color" content="#0F0C07">' . "\n";
		echo '<meta name="apple-mobile-web-app-title" content="DJ KOLJA ONE">' . "\n";
		echo '<meta name="application-name" content="DJ KOLJA ONE">' . "\n";
		echo '<meta name="format-detection" content="telephone=no">' . "\n";
		if ( kjo_has_seo_plugin() || is_404() || is_search() ) {
			return;
		}
		$desc  = kjo_description();
		$title = wp_get_document_title();
		$url   = is_front_page() ? home_url( '/' ) : ( is_singular() ? get_permalink() : home_url( '/' ) );
		$img   = kjo_asset( 'teilen.jpg' );
		if ( ! kjo_seo_seite() ) { // Seiten aus der Vorlage bekommen Beschreibung, Titel und URL weiter unten (sonst doppelt)
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
			echo '<meta property="og:type" content="website">' . "\n";
			echo '<meta property="og:locale" content="de_DE">' . "\n";
			echo '<meta property="og:site_name" content="DJ KOLJA ONE">' . "\n";
			echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
			echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
			echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
		}
		echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
		echo '<meta property="og:image:width" content="1200">' . "\n";
		echo '<meta property="og:image:height" content="630">' . "\n";
		echo '<meta property="og:image:alt" content="DJ KOLJA ONE – Jedes Event findet nur einmal statt.">' . "\n";
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		if ( is_front_page() && ! is_readable( __DIR__ . '/schema.json' ) ) { // sonst steht das Unternehmen im @graph (kein doppelter Block)
			$ld = array(
				'@context'    => 'https://schema.org',
				'@type'       => 'EntertainmentBusiness',
				'name'        => 'DJ KOLJA ONE',
				'description' => $desc,
				'url'         => home_url( '/' ),
				'image'       => $img,
				'logo'        => kjo_asset( 'icon-512.png' ),
				'telephone'   => '+491727273707',
				'slogan'      => 'Jedes Event findet nur einmal statt.',
				'address'     => array(
					'@type'           => 'PostalAddress',
					'addressLocality' => 'Fellheim',
					'addressRegion'   => 'Bayern',
					'addressCountry'  => 'DE',
				),
				'areaServed'  => array( 'Memmingen', 'Ulm', 'Neu-Ulm', 'Biberach', 'Ravensburg', 'Kempten', 'Füssen', 'Kaufbeuren', 'Landsberg am Lech', 'Allgäu', 'Oberschwaben' ),
			);
			echo '<script type="application/ld+json">' . wp_json_encode( $ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
		}
	},
	2
);
// Icon auch im WordPress-Adminbereich und auf der Login-Seite.
foreach ( array( 'admin_head', 'login_head' ) as $kjo_hook ) {
	add_action(
		$kjo_hook,
		function () {
			echo '<link rel="icon" href="' . esc_url( kjo_asset( 'icon.svg' ) ) . '" type="image/svg+xml"><link rel="apple-touch-icon" href="' . esc_url( kjo_asset( 'apple-touch-icon.png' ) ) . '">';
		}
	);
}

/* ------------------------------------------------------------------
 * Eigener Update-Kanal (seit 1.8.0)
 * Das Plugin liest eine kleine Beschreibungsdatei (JSON) von der unter
 * Medien → Plattenkiste hinterlegten Adresse. Steht dort eine neuere
 * Version, bietet WordPress das Update wie bei jedem anderen Plugin an.
 * ------------------------------------------------------------------ */
function kjo_update_url() {
	$u = trim( (string) get_option( 'kjo_update_url', '' ) );
	if ( '' === $u ) {
		return '';
	}
	$host = (string) wp_parse_url( $u, PHP_URL_HOST );
	$ok   = 0 === strpos( $u, 'https://' ) || in_array( $host, array( 'localhost', '127.0.0.1' ), true );
	return $ok ? $u : '';
}

/** Beschreibungsdatei holen (6 Stunden zwischengespeichert). */
function kjo_update_info( $force = false ) {
	$url = kjo_update_url();
	if ( '' === $url ) {
		return null;
	}
	$key = 'kjo_upd_' . md5( $url );
	if ( ! $force ) {
		$c = get_site_transient( $key );
		if ( is_array( $c ) ) {
			return empty( $c['version'] ) ? null : $c;
		}
	}
	$res  = wp_remote_get( add_query_arg( 't', time(), $url ), array( 'timeout' => 10, 'headers' => array( 'Accept' => 'application/json' ) ) );
	$info = array( 'error' => '' );
	if ( is_wp_error( $res ) ) {
		$info['error'] = $res->get_error_message();
	} elseif ( 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		$info['error'] = 'Antwort ' . (int) wp_remote_retrieve_response_code( $res );
	} else {
		$j = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $j ) || empty( $j['version'] ) || empty( $j['download_url'] ) ) {
			$info['error'] = 'Beschreibungsdatei unvollständig';
		} else {
			$dl = (string) $j['download_url'];
			// Relative Angabe (nur Dateiname) → gleicher Ordner wie die Beschreibungsdatei.
			if ( ! preg_match( '#^https?://#i', $dl ) ) {
				$dl = trailingslashit( preg_replace( '#/[^/]*$#', '', strtok( $url, '?' ) ) ) . ltrim( $dl, '/' );
			}
			if ( wp_parse_url( $dl, PHP_URL_HOST ) !== wp_parse_url( $url, PHP_URL_HOST ) && empty( $j['allow_other_host'] ) ) {
				$info['error'] = 'Download liegt auf einem anderen Server als die Beschreibungsdatei';
			} elseif ( ! preg_match( '/^\d+(\.\d+){1,3}$/', (string) $j['version'] ) ) {
				$info['error'] = 'Versionsnummer ungültig';
			} else {
				$info = array(
					'error'        => '',
					'version'      => (string) $j['version'],
					'download_url' => esc_url_raw( $dl ),
					'sha256'       => isset( $j['sha256'] ) ? strtolower( preg_replace( '/[^a-f0-9]/i', '', (string) $j['sha256'] ) ) : '',
					'requires'     => isset( $j['requires'] ) ? (string) $j['requires'] : '6.0',
					'tested'       => isset( $j['tested'] ) ? (string) $j['tested'] : '',
					'requires_php' => isset( $j['requires_php'] ) ? (string) $j['requires_php'] : '7.4',
					'changelog'    => isset( $j['changelog'] ) ? wp_kses_post( (string) $j['changelog'] ) : '',
				);
			}
		}
	}
	$info['checked'] = time();
	set_site_transient( $key, $info, empty( $info['version'] ) ? HOUR_IN_SECONDS : 6 * HOUR_IN_SECONDS );
	update_option( 'kjo_update_last', $info, false );
	return empty( $info['version'] ) ? null : $info;
}

add_filter(
	'pre_set_site_transient_update_plugins',
	function ( $tr ) {
		if ( ! is_object( $tr ) ) {
			return $tr;
		}
		$info = kjo_update_info();
		$base = plugin_basename( __FILE__ );
		$item = (object) array(
			'id'           => 'kjo/' . $base,
			'slug'         => dirname( $base ),
			'plugin'       => $base,
			'new_version'  => $info ? $info['version'] : KJO_VERSION,
			'url'          => home_url( '/' ),
			'package'      => $info ? $info['download_url'] : '',
			'tested'       => $info ? $info['tested'] : '',
			'requires'     => $info ? $info['requires'] : '',
			'requires_php' => $info ? $info['requires_php'] : '',
			'icons'        => array( '1x' => kjo_asset( 'icon-192.png' ), 'svg' => kjo_asset( 'icon.svg' ) ),
		);
		if ( $info && version_compare( $info['version'], KJO_VERSION, '>' ) ) {
			$tr->response[ $base ] = $item;
			unset( $tr->no_update[ $base ] );
		} else {
			$tr->no_update[ $base ] = $item;
			unset( $tr->response[ $base ] );
		}
		return $tr;
	}
);

// Fenster „Details ansehen“.
add_filter(
	'plugins_api',
	function ( $res, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || dirname( plugin_basename( __FILE__ ) ) !== $args->slug ) {
			return $res;
		}
		$info = kjo_update_info();
		return (object) array(
			'name'          => 'DJ KOLJA ONE Plattenkiste',
			'slug'          => $args->slug,
			'version'       => $info ? $info['version'] : KJO_VERSION,
			'author'        => 'DJ KOLJA ONE',
			'homepage'      => home_url( '/' ),
			'requires'      => $info ? $info['requires'] : '6.0',
			'tested'        => $info ? $info['tested'] : '',
			'requires_php'  => $info ? $info['requires_php'] : '7.4',
			'download_link' => $info ? $info['download_url'] : '',
			'sections'      => array(
				'changelog' => $info && $info['changelog'] ? $info['changelog'] : '<p>Keine Angaben.</p>',
			),
		);
	},
	10,
	3
);

// Prüfsumme der heruntergeladenen Datei kontrollieren, wenn die Beschreibungsdatei eine nennt.
add_filter(
	'upgrader_pre_download',
	function ( $reply, $package ) {
		$info = kjo_update_info();
		if ( ! $info || $package !== $info['download_url'] || '' === $info['sha256'] ) {
			return $reply;
		}
		$tmp = download_url( $package );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		if ( ! hash_equals( $info['sha256'], hash_file( 'sha256', $tmp ) ) ) {
			wp_delete_file( $tmp );
			return new WP_Error( 'kjo_checksum', 'Die heruntergeladene Datei stimmt nicht mit der Prüfsumme überein. Update abgebrochen.' );
		}
		return $tmp;
	},
	10,
	2
);

add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		$links[] = '<a href="' . esc_url( admin_url( 'upload.php?page=kjm-plattenkiste#kjo-update' ) ) . '">Updates</a>';
		return $links;
	}
);

function kjo_update_box() {
	if ( ! current_user_can( 'update_plugins' ) ) {
		return;
	}
	$msg = '';
	if ( isset( $_POST['kjo_update_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kjo_update_nonce'] ) ), 'kjo_update' ) ) {
		if ( isset( $_POST['kjo_update_url'] ) ) {
			update_option( 'kjo_update_url', esc_url_raw( trim( (string) wp_unslash( $_POST['kjo_update_url'] ) ) ), false );
		}
		kjo_update_info( true );
		delete_site_transient( 'update_plugins' );
		wp_update_plugins();
		$msg = 'Geprüft.';
	}
	$raw  = (string) get_option( 'kjo_update_url', '' );
	$url  = kjo_update_url();
	$last = get_option( 'kjo_update_last' );
	echo '<div id="kjo-update" class="card" style="max-width:none;margin:14px 0"><h2 style="margin-top:0">Plugin-Updates</h2>';
	echo '<p>Installiert: <strong>Version ' . esc_html( KJO_VERSION ) . '</strong>. ';
	if ( '' === $raw ) {
		echo 'Es ist noch keine Update-Adresse hinterlegt – Updates kommen weiter per ZIP-Upload.';
	} elseif ( '' === $url ) {
		echo '<span style="color:#b32d2e">Die Update-Adresse muss mit https:// beginnen.</span>';
	} elseif ( is_array( $last ) && ! empty( $last['error'] ) ) {
		echo '<span style="color:#b32d2e">Letzte Prüfung fehlgeschlagen: ' . esc_html( $last['error'] ) . '</span>';
	} elseif ( is_array( $last ) && ! empty( $last['version'] ) ) {
		if ( version_compare( $last['version'], KJO_VERSION, '>' ) ) {
			echo '<strong>Version ' . esc_html( $last['version'] ) . ' ist verfügbar.</strong> <a class="button button-primary" href="' . esc_url( admin_url( 'plugins.php' ) ) . '">Zur Plugin-Liste und aktualisieren</a>';
		} else {
			echo 'Du hast die aktuelle Version.';
		}
		echo ' <span class="description">(geprüft ' . esc_html( wp_date( 'd.m.Y H:i', (int) $last['checked'] ) ) . ')</span>';
	}
	echo '</p><form method="post">';
	wp_nonce_field( 'kjo_update', 'kjo_update_nonce' );
	echo '<label for="kjo_update_url"><strong>Update-Adresse</strong></label><br><input type="url" class="regular-text code" style="width:100%;max-width:720px" id="kjo_update_url" name="kjo_update_url" value="' . esc_attr( $raw ) . '" placeholder="https://…/plattenkiste.json"> ';
	echo '<button class="button">Speichern und jetzt prüfen</button> ' . esc_html( $msg );
	echo '</form></div>';
}

define( 'KJO_MEDIA_CSS', <<<'KJOCSS'
[class*="kjo-m-"]{border:1px solid rgba(178,157,117,.55)!important;border-radius:6px!important;box-shadow:0 14px 30px rgba(0,0,0,.5)!important;overflow:hidden;box-sizing:border-box!important;min-height:0!important;height:auto!important;flex:0 1 auto!important;align-self:center!important;margin-left:auto;margin-right:auto;background-position:center!important;background-size:cover!important;aspect-ratio:4/3;width:min(100%,300px)}@media(max-width:1024px){.kjo-tiles,.kjo-tiles>.e-con-inner{flex-direction:row!important;flex-wrap:nowrap!important;justify-content:flex-start!important;align-items:flex-start!important}.kjo-tiles{overflow-x:auto!important;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;scrollbar-width:none;padding-bottom:14px!important}.kjo-tiles::-webkit-scrollbar{display:none}.kjo-tiles .kjo-tilecard{flex:0 0 72%!important;width:72%!important;max-width:72%!important;scroll-snap-align:start}}@media(min-width:768px) and (max-width:1024px){.kjo-tiles .kjo-tilecard{flex-basis:42%!important;width:42%!important;max-width:42%!important}}.kjo-vid>video.kjo-hold{opacity:0}.kjo-vid{position:relative!important;overflow:hidden!important}.kjo-solo{justify-content:center!important}.kjo-solo>.kjo-txt{width:100%!important;max-width:780px;margin-left:auto;margin-right:auto}.kjo-vid>video{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;object-position:center;cursor:pointer;background:#1A1712;z-index:1}.kjo-vid>.kjo-pb{position:absolute;left:5%;bottom:4%;width:clamp(32px,20%,54px);aspect-ratio:1;height:auto;min-height:0;border-radius:50%!important;background:#161310!important;border:1.5px solid #B29D75!important;color:#B29D75!important;box-shadow:0 0 0 5px rgba(178,157,117,.16),0 8px 20px rgba(0,0,0,.55);padding:0!important;margin:0;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:2;transition:background .2s,color .2s,box-shadow .2s;-webkit-appearance:none;appearance:none}.kjo-vid>.kjo-pb:hover,.kjo-vid>.kjo-pb:focus-visible{box-shadow:0 0 0 7px rgba(178,157,117,.28),0 8px 20px rgba(0,0,0,.55);outline:none}.kjo-vid>.kjo-pb svg{width:46%;height:46%;display:block;fill:currentColor}.kjo-vid>.kjo-pb .kjo-i2{display:none}.kjo-vid.kjo-on>.kjo-pb{background:#B29D75!important;color:#0F0C07!important}.kjo-vid.kjo-on>.kjo-pb .kjo-i1{display:none}.kjo-vid.kjo-on>.kjo-pb .kjo-i2{display:block}@media(min-width:1025px){.kjo-split,.kjo-split>.e-con-inner{flex-wrap:nowrap!important;align-items:center!important}.kjo-split [class*="kjo-m-"]{max-width:46%!important;flex:0 1 auto!important;margin:0!important}.kjo-split .kjo-txt{flex:1 1 0!important;min-width:0!important;width:auto!important}}.kjo-tilecard{justify-content:flex-start!important}.kjo-tilecard>:last-child{margin-top:auto!important}.kjo-tile.kjo-tile[class*="kjo-m-"]{width:100%!important;max-width:none!important;aspect-ratio:auto!important;height:400px!important;min-height:400px!important;align-self:stretch!important;margin:0!important;background-color:#16130F!important;background-position:center!important;background-size:contain!important;background-repeat:no-repeat!important}.kjo-tile.kjo-ph{display:flex!important;align-items:center;justify-content:center;background:radial-gradient(circle at 50% 42%,rgba(178,157,117,.2),rgba(178,157,117,0) 62%),#16130F!important}.kjo-tile.kjo-ph svg{width:30%;max-width:84px;height:auto;fill:none;stroke:#B29D75;stroke-width:1.3;stroke-linecap:round;stroke-linejoin:round;opacity:.9}
KJOCSS
);
define( 'KJO_MEDIA_JS', <<<'KJOJS'
(function(){
var M=window.KJO_MEDIA||{};
var AN={hochzeit:"einer Hochzeit",geburtstag:"einem Geburtstag",firmenfeier:"einer Firmenfeier",events:"einem Event"};
function altFor(n){n=String(n||"").toLowerCase();var x;
  if(n==="kolja_portrait")return "Kolja Tönges, DJ und Moderator – DJ KOLJA ONE";
  if((x=n.match(/^start_(hochzeit|geburtstag|firmenfeier|events)$/)))return "DJ KOLJA ONE bei "+AN[x[1]];
  if((x=n.match(/^event_(hochzeit|geburtstag|firmenfeier|events)_(text|\d+)$/)))return "DJ KOLJA ONE bei "+AN[x[1]]+(x[2]==="text"?"":" – Eindruck "+x[2]);
  if((x=n.match(/^ueber_(\d+)$/)))return "Hinter dem DJ-Pult mit DJ KOLJA ONE – Eindruck "+x[1];
  if((x=n.match(/^start_(\d+)$/)))return "DJ KOLJA ONE live im Einsatz – Eindruck "+x[1];
  return "";}
window.KJO_ALT=altFor;
var ICO={hochzeit:'<circle cx="18" cy="28" r="10"/><circle cx="30" cy="28" r="10"/><path d="M27 10l3-4 3 4-3 3z"/>',
geburtstag:'<path d="M10 40h28V26H10z"/><path d="M10 31c3 3 6 3 9 0s6-3 10 0 6 3 9 0"/><path d="M18 26v-7M24 26v-7M30 26v-7"/><path d="M18 15c-1.5-1.5 0-3.5 0-4.5 1 1 1.5 3 0 4.5zM24 15c-1.5-1.5 0-3.5 0-4.5 1 1 1.5 3 0 4.5zM30 15c-1.5-1.5 0-3.5 0-4.5 1 1 1.5 3 0 4.5z"/>',
firmenfeier:'<path d="M14 8h8l-1 12a3 3 0 0 1-6 0zM26 8h8l-1 12a3 3 0 0 1-6 0zM18 23v15M30 23v15M13 38h10M25 38h10"/>',
events:'<path d="M24 44V30"/><path d="M24 20v-8M24 20l6-6M24 20l8 0M24 20l6 6M24 20l-6 6M24 20h-8M24 20l-6-6"/><circle cx="24" cy="9.5" r="1.3"/><circle cx="32" cy="12" r="1.3"/><circle cx="34.5" cy="20" r="1.3"/><circle cx="32" cy="28" r="1.3"/><circle cx="16" cy="28" r="1.3"/><circle cx="13.5" cy="20" r="1.3"/><circle cx="16" cy="12" r="1.3"/><path d="M38 6l1 2.5 2.5 1-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1zM9 33l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>'};
function one(el){
  if(el.getAttribute("data-kjo"))return;
  var m=(String(el.className).match(/kjo-m-([a-z0-9_]+)/i)||[])[1]; if(!m)return;
  el.setAttribute("data-kjo","1");
  var e=M[m.toLowerCase()]||{};
  /* Bild erst kurz vor dem Sichtbarwerden laden; auf schmalen Plätzen (Handy) die kleinere Fassung */
  function bg(){var w=el.getBoundingClientRect().width*(window.devicePixelRatio||1),u=(e.sm&&w>0&&w<=1100)?e.sm:e.img;el.style.backgroundImage='url("'+u+'")';el.style.backgroundSize="cover";el.style.backgroundPosition="center";}
  if(e.img){if(!e.vid&&"IntersectionObserver" in window){var io=new IntersectionObserver(function(x){for(var k=0;k<x.length;k++)if(x[k].isIntersecting){io.disconnect();bg();return}},{rootMargin:"600px 0px"});io.observe(el)}else bg();}
  var al=altFor(m);if(al&&e.img&&!e.vid){el.setAttribute("role","img");el.setAttribute("aria-label",al);}
  var tl=el.classList.contains("kjo-tile");
  if(tl&&!e.img&&!e.vid){el.classList.add("kjo-ph");el.style.backgroundImage="none";el.setAttribute("aria-hidden","true");el.innerHTML='<svg viewBox="0 0 48 48" aria-hidden="true">'+(ICO[m.replace(/^start_/,"")]||ICO.events)+'</svg>';return;}
  function fit(w,h){if(tl||!w||!h)return;var H=(e.h>0?e.h:400),W=Math.round(H*w/h),S=function(k,v){el.style.setProperty(k,v,"important");};S("aspect-ratio",w+" / "+h);S("width","min(100%,"+W+"px)");S("max-width","none");S("height","auto");S("min-height","0");}
  if(e.img){var pi=new Image();pi.onload=function(){fit(pi.naturalWidth,pi.naturalHeight);};pi.src=e.sm||e.img;}
  if(!e.vid)return;
  el.classList.add("kjo-vid");
  var v=document.createElement("video");
  v.setAttribute("playsinline","");v.playsInline=true;v.preload="metadata";
  if(e.img){v.src=e.vid;v.classList.add("kjo-hold");}else{v.src=e.vid+"#t=0.1";}
  var b=document.createElement("button");b.type="button";b.className="kjo-pb";b.setAttribute("aria-label","Video abspielen");
  b.innerHTML='<svg class="kjo-i1" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4.5v15l13-7.5z"/></svg><svg class="kjo-i2" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 4.5h4.2v15H6zM13.8 4.5H18v15h-4.2z"/></svg>';
  if(al)v.setAttribute("aria-label",al);
  v.addEventListener("loadedmetadata",function(){fit(v.videoWidth,v.videoHeight);});
  el.appendChild(v);el.appendChild(b);
  function set(on){el.classList.toggle("kjo-on",on);b.setAttribute("aria-label",on?"Video anhalten":"Video abspielen");}
  function tog(ev){ev.preventDefault();ev.stopPropagation();
    if(v.paused){var o=document.querySelectorAll(".kjo-vid>video");for(var i=0;i<o.length;i++){if(o[i]!==v)o[i].pause();}
      var p=v.play();if(p&&p.catch)p.catch(function(){});}
    else v.pause();}
  b.addEventListener("click",tog);v.addEventListener("click",tog);
  v.addEventListener("play",function(){set(true);});
  v.addEventListener("playing",function(){v.classList.remove("kjo-hold");});
  function rst(){set(false);if(e.img){v.classList.add("kjo-hold");v.load();}else{try{v.currentTime=0.1;}catch(x){}}}
  v.addEventListener("pause",rst);
  v.addEventListener("ended",rst);
}
function hid(e){return getComputedStyle(e).display==="none";}
function tidy(){
  var s=document.querySelectorAll(".kjo-split"),i,m;
  for(i=0;i<s.length;i++){m=s[i].querySelector(':scope>[class*="kjo-m-"]');if(m&&hid(m))s[i].classList.add("kjo-solo");}
  var g=document.querySelectorAll(".kjo-grp");
  for(i=0;i<g.length;i++){var c=g[i].querySelectorAll('[class*="kjo-m-"]'),any=false;for(var j=0;j<c.length;j++){if(!hid(c[j])){any=true;break;}}g[i].style.display=any?"":"none";}
}
function init(){var l=document.querySelectorAll('[class*="kjo-m-"]');for(var i=0;i<l.length;i++)one(l[i]);tidy();}
window.KJO_MEDIA_INIT=init;
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();

KJOJS
);

/* ------------------------------------------------------------------
 * Kopfzeile (seit 1.4.0)
 * 1) Navigation bleibt beim Scrollen oben stehen.
 * 2) Anrufen + WhatsApp als zwei Icons rechts in der Navigation.
 * 3) Cookie-Banner (Complianz) im DJ-KOLJA-ONE-Design.
 * 4) Link „Cookie-Richtlinie“ in der Fußzeile.
 * Nummer ändern: die zwei Zeilen direkt hier drunter anpassen.
 * ------------------------------------------------------------------ */
if ( ! defined( 'KJO_TEL' ) ) {
	define( 'KJO_TEL', '+491727273707' );
}
if ( ! defined( 'KJO_WA' ) ) {
	define( 'KJO_WA', '491727273707' );
}

define( 'KJO_HEAD_CSS', <<<'KJOCSS'
html,body{background-color:#0F0C07!important}@supports (overflow-x:clip){html,body{overflow-x:clip}}
#kjm,#kjo,#kjm svg,#kjo svg,#kjm svg text,#kjo svg text{-webkit-user-select:none;-moz-user-select:none;user-select:none;-webkit-touch-callout:none}
#kjm ::selection,#kjo ::selection{background:transparent}
#kjm ::-moz-selection,#kjo ::-moz-selection{background:transparent}
.kjo-head{position:-webkit-sticky!important;position:sticky!important;top:0;z-index:9990}
.kjo-navlinks{flex-wrap:nowrap!important}.kjo-navlinks .elementor-heading-title{white-space:nowrap}
@media(min-width:1025px) and (max-width:1280px){.kjo-navlinks{--gap:0 13px!important;gap:0 13px!important}.kjo-navlinks .elementor-heading-title{font-size:15px!important}}
.admin-bar .kjo-head{top:32px}
@media(max-width:782px){.admin-bar .kjo-head{top:46px}}
@media(max-width:600px){.admin-bar .kjo-head{top:0}}
.kjo-right{display:flex;align-items:center;gap:18px;flex:none}
.kjo-right>.elementor-widget-button{width:auto;flex:none}
.kjo-cta{display:flex;align-items:center;gap:10px;flex:none}
.kjo-cta a{width:40px;height:40px;display:flex;align-items:center;justify-content:center;border:1px solid rgba(178,157,117,.55);border-radius:50%;color:#B29D75;background:transparent;text-decoration:none;font-size:18px;line-height:1;transition:background .2s,color .2s,border-color .2s}
.kjo-cta a:hover,.kjo-cta a:focus-visible{background:#B29D75;border-color:#B29D75;color:#0F0C07;outline:none}
.kjo-cta svg{width:18px;height:18px;fill:currentColor;display:block}
@media(max-width:767px){.kjo-cta a,.kjo-cta .kjo-burger{width:44px;height:44px;font-size:20px}.kjo-cta svg{width:20px;height:20px}.kjo-head.kjo-small>.kjo-nav2{display:none!important}}
.kjo-cta .kjo-burger{display:none;align-items:center;justify-content:center;border:1px solid rgba(178,157,117,.55);border-radius:50%;color:#B29D75;background:transparent;padding:0;cursor:pointer;-webkit-appearance:none;appearance:none;transition:background .2s,color .2s}
.kjo-cta .kjo-burger:hover,.kjo-cta .kjo-burger:focus-visible,.kjo-head.kjo-open .kjo-burger{background:#B29D75;border-color:#B29D75;color:#0F0C07;outline:none}
.kjo-burger .kjo-x{display:none}.kjo-head.kjo-open .kjo-burger .kjo-b{display:none}.kjo-head.kjo-open .kjo-burger .kjo-x{display:block}
@media(max-width:767px){.kjo-head.kjo-small .kjo-burger{display:flex}
.kjo-head.kjo-small.kjo-open>.kjo-nav2{display:flex!important;flex-wrap:wrap;justify-content:center;gap:6px 22px;position:absolute;left:0;right:0;top:100%;padding:16px 20px 20px;background:#0F0C07;border-top:1px solid rgba(178,157,117,.3);border-bottom:1px solid rgba(178,157,117,.45);box-shadow:0 18px 30px rgba(0,0,0,.55)}
.kjo-head.kjo-small.kjo-open>.kjo-nav2 a{padding:8px 2px}}
.cmplz-cookiebanner{--cmplz_banner_background_color:#1A1712;--cmplz_banner_border_color:#B29D75;--cmplz_text_color:#F3F1E9;--cmplz_hyperlink_color:#B29D75;--cmplz_button_accept_background_color:#B29D75;--cmplz_button_accept_border_color:#B29D75;--cmplz_button_accept_text_color:#0F0C07;--cmplz_button_deny_background_color:#B29D75;--cmplz_button_deny_border_color:#B29D75;--cmplz_button_deny_text_color:#0F0C07;--cmplz_button_settings_background_color:#1A1712;--cmplz_button_settings_border_color:#A39E93;--cmplz_button_settings_text_color:#F3F1E9;--cmplz_slider_active_color:#B29D75;--cmplz_slider_inactive_color:#A39E93;--cmplz_slider_bullet_color:#0F0C07;background:#1A1712!important;border:1px solid rgba(178,157,117,.6)!important;border-radius:4px!important;color:#F3F1E9!important;font-family:"Fira Sans",sans-serif!important}
.cmplz-cookiebanner .cmplz-title,.cmplz-cookiebanner .cmplz-message,.cmplz-cookiebanner .cmplz-message p,.cmplz-cookiebanner .cmplz-category-title,.cmplz-cookiebanner .cmplz-description,.cmplz-cookiebanner .cmplz-always-active{color:#F3F1E9!important;font-family:"Fira Sans",sans-serif!important}
.cmplz-cookiebanner .cmplz-title{font-weight:300!important;letter-spacing:.02em}
.cmplz-cookiebanner .cmplz-categories .cmplz-category{background:#0F0C07!important}
.cmplz-cookiebanner .cmplz-divider{background:rgba(178,157,117,.3)!important;border-color:rgba(178,157,117,.3)!important}
.cmplz-cookiebanner .cmplz-btn{font-family:"Fira Sans",sans-serif!important;font-weight:500!important;border-radius:2px!important}
.cmplz-cookiebanner .cmplz-btn.cmplz-accept,.cmplz-cookiebanner .cmplz-btn.cmplz-deny{background:#B29D75!important;border:1px solid #B29D75!important;color:#0F0C07!important}
.cmplz-cookiebanner .cmplz-btn.cmplz-accept:hover,.cmplz-cookiebanner .cmplz-btn.cmplz-deny:hover{background:#C4B08A!important;border-color:#C4B08A!important}
.cmplz-cookiebanner .cmplz-btn.cmplz-view-preferences,.cmplz-cookiebanner .cmplz-btn.cmplz-save-preferences,.cmplz-cookiebanner .cmplz-btn.cmplz-manage-options{background:#1A1712!important;border:1px solid #A39E93!important;color:#F3F1E9!important}
.cmplz-cookiebanner .cmplz-links a,.cmplz-cookiebanner .cmplz-link,.cmplz-cookiebanner .cmplz-message a{color:#B29D75!important}
.cmplz-cookiebanner .cmplz-close,.cmplz-cookiebanner .cmplz-icon{color:#F3F1E9!important;fill:#F3F1E9!important}
#cmplz-manage-consent .cmplz-manage-consent{background:#1A1712!important;color:#F3F1E9!important;border:1px solid rgba(178,157,117,.6)!important;font-family:"Fira Sans",sans-serif!important}
KJOCSS
);

define( 'KJO_HEAD_JS', <<<'KJOJS'
(function(){
var C=window.KJO_HEAD||{};
function top(el){
  var p=el.closest?el.closest(".e-con.e-parent"):null; if(p)return p;
  p=el; while(p.parentNode&&p.parentNode.classList&&!p.parentNode.classList.contains("elementor"))p=p.parentNode;
  return p;
}
function stick(h){
  var small=false;
  function sc(){var y=window.pageYOffset||document.documentElement.scrollTop||0;
    if(!small&&y>220){small=true;h.classList.add("kjo-small");}
    else if(small&&y<40){small=false;h.classList.remove("kjo-small");h.classList.remove("kjo-open");}}
  window.addEventListener("scroll",sc,{passive:true}); sc();
  /* Handy: Beim Scrollen wird die zweite Menüzeile ausgeblendet – ein Menü-Knopf (Hamburger) holt sie bei Bedarf zurück. */
  var cta=h.querySelector(".kjo-cta"),nav=h.querySelector(".kjo-nav2");
  if(cta&&nav&&!cta.querySelector(".kjo-burger")){
    var b=document.createElement("button"); b.type="button"; b.className="kjo-burger"; b.setAttribute("aria-label","Menü öffnen"); b.setAttribute("aria-expanded","false");
    b.innerHTML='<svg class="kjo-b" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/></svg><svg class="kjo-x" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5l14 14M19 5L5 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/></svg>';
    cta.insertBefore(b,cta.firstChild);
    function set(o){h.classList.toggle("kjo-open",o);b.setAttribute("aria-expanded",o?"true":"false");b.setAttribute("aria-label",o?"Menü schließen":"Menü öffnen");}
    b.addEventListener("click",function(e){e.stopPropagation();set(!h.classList.contains("kjo-open"));});
    nav.addEventListener("click",function(e){if(e.target.closest&&e.target.closest("a"))set(false);});
    document.addEventListener("click",function(e){if(h.classList.contains("kjo-open")&&!h.contains(e.target))set(false);});
    document.addEventListener("keydown",function(e){if(e.key==="Escape")set(false);});
    window.addEventListener("scroll",function(){if(h.classList.contains("kjo-open")&&Math.abs((window.pageYOffset||0)-(window._kjoY||0))>120)set(false);},{passive:true});
    h.addEventListener("click",function(){window._kjoY=window.pageYOffset||0;},true);
  }
}
function head(){
  var st=document.querySelector(".kjo-head[data-static]");
  if(st){stick(st);return;}
  if(document.querySelector(".kjo-cta"))return;
  var logo=document.querySelector('.elementor img[src*="dj-kolja-one-logo-ohne-claim"]')||document.querySelector('.elementor img[src*="dj-kolja-one-logo"]');
  if(!logo)return;
  var w=logo.closest(".elementor-widget")||logo.parentNode, row=w.parentNode, h=top(row);
  if(!h||!row)return;
  h.classList.add("kjo-head");
  var n2=h.querySelector(":scope > .elementor-hidden-desktop")||h.querySelector(".elementor-hidden-desktop"); if(n2)n2.classList.add("kjo-nav2");
  var c=document.createElement("div"); c.className="kjo-cta";
  c.innerHTML='<a class="kjo-tel" href="tel:'+C.tel+'" aria-label="Anrufen" title="Anrufen">'+C.icoTel+'</a>'+
              '<a class="kjo-wa" href="https://wa.me/'+C.wa+'" target="_blank" rel="noopener" aria-label="WhatsApp schreiben" title="WhatsApp schreiben">'+C.icoWa+'</a>';
  var r=document.createElement("div"); r.className="kjo-right"; r.appendChild(c);
  var btn=null,k=row.children;
  for(var i=0;i<k.length;i++){if(k[i].classList&&k[i].classList.contains("elementor-widget-button")){btn=k[i];break;}}
  if(btn){row.insertBefore(r,btn);r.appendChild(btn);}else{row.appendChild(r);}
  stick(h);
}
function musikHero(){
  var a=document.querySelector('.elementor a[href$="#auflegen"]'); if(!a)return;
  var w=a.closest(".elementor-widget-button"); if(!w||!w.parentNode)return;
  var p=w.parentNode, k=p.children, only=true;
  for(var i=0;i<k.length;i++){if(!(k[i].classList&&k[i].classList.contains("elementor-widget-button")))only=false;}
  if(only)p.style.display="none"; else for(var j=0;j<k.length;j++){if(k[j].classList.contains("elementor-widget-button"))k[j].style.display="none";}
}
/* „Meine Musik“: schwarze Lücke zwischen Einleitungstext und DJ-Pult entfernen */
function musikGap(){
  var k=document.getElementById("kjm"),hint=document.getElementById("kjmHint"); if(!k||!hint)return;
  var r=k.closest("[data-elementor-type]")||k.closest(".elementor"); if(!r)return;
  function top(el){while(el&&el.parentNode&&el.parentNode!==r)el=el.parentNode;return el&&el.parentNode===r?el:null}
  var t=top(k),h1=r.querySelector("h1"),h=h1?top(h1):null; if(!t||!h||t===h)return;
  /* Rest-Abstand (Polster, Lücken, Abstandhalter, versteckte Buttons) messen und per Rand ausgleichen – unabhängig vom Seitenaufbau */
  /* Layout-Positionen (offsetTop) statt Bildschirmpositionen: Einblend-Animationen von Elementor verfälschen sonst die Messung und das Pult würde den Text überdecken */
  function Y(el){var y=0;while(el){y+=el.offsetTop||0;el=el.offsetParent;}return y;}
  function fit(){
    t.style.setProperty("margin-top","0","important"); t.style.setProperty("padding-top","0","important"); h.style.setProperty("padding-bottom","0","important");
    /* Der Pult-Abschnitt rückt per negativem Rand nach oben und hat einen deckenden Hintergrund: Der Kopf-Abschnitt muss darüber liegen, sonst wird sein Text abgeschnitten (weiße Splitter) */
    h.style.setProperty("position","relative"); h.style.setProperty("z-index","2"); t.style.setProperty("position","relative"); t.style.setProperty("z-index","1");
    var last=null,w=h.querySelectorAll(".elementor-widget,h1,p"),i,bt;
    for(i=0;i<w.length;i++){ if((w[i].textContent||"").trim()==="")continue; if(!w[i].offsetHeight)continue; bt=Y(w[i])+w[i].offsetHeight; if(last===null||bt>last)last=bt; }
    if(last===null||!hint.offsetHeight)return;
    var gap=Y(hint)-last, want=window.innerWidth<=600?20:28;
    if(gap>want)t.style.setProperty("margin-top",(-(gap-want))+"px","important");
    /* Sicherheitsnetz: Der Kopf-Abschnitt (liegt oben) darf nie den Hinweis/Laptop/Controller überdecken – ragt er trotz allem darüber hinaus, wird der Rand wieder zurückgenommen */
    var ov=Y(h)+h.offsetHeight-Y(hint)+6;
    if(ov>0){ t.style.setProperty("margin-top",Math.min(0,(parseFloat(t.style.marginTop)||0)+ov)+"px","important"); }
  }
  /* Leere Abstandhalter, Trenner und versteckte Container im Kopf-Abschnitt ausblenden, damit sein unsichtbarer „Schwanz“ nicht über das Pult ragt (am Handy wurde der Laptop oben abgeschnitten) */
  (function(){var a=h.querySelectorAll(".elementor-widget,.e-con"),i,e;for(i=0;i<a.length;i++){e=a[i]; if((e.textContent||"").trim()!=="")continue; if(e.querySelector("img,video,svg,iframe,canvas,input,button,a,i"))continue; e.style.setProperty("display","none","important");}
    var inn=h.querySelectorAll(".e-con-inner"); for(i=0;i<inn.length;i++)inn[i].style.setProperty("padding-bottom","0","important"); h.style.setProperty("padding-bottom","0","important");})();
  fit(); window.addEventListener("load",fit); window.addEventListener("resize",fit); setTimeout(fit,800); setTimeout(fit,2500);
  if(document.fonts&&document.fonts.ready)document.fonts.ready.then(fit);
}
function foot(){
  if(!C.cookie||document.querySelector(".kjo-cookie-link"))return;
  var a=document.querySelectorAll('.elementor a[href$="/datenschutz/"],.elementor a[href$="/datenschutz"]'); if(!a.length)return;
  var l=a[a.length-1], w=l.closest(".elementor-widget"); if(!w||!w.parentNode)return;
  var n=w.cloneNode(true), x=n.querySelector("a"); if(!x)return;
  n.classList.add("kjo-cookie-link"); x.setAttribute("href",C.cookie); x.textContent="Cookie-Richtlinie";
  w.parentNode.insertBefore(n,w.nextSibling);
}
function init(){try{head();}catch(e){}try{foot();}catch(e){}try{musikHero();}catch(e){}try{musikGap();}catch(e){}}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();
KJOJS
);

function kjo_icons() {
	$tel = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.6 21 3 13.4 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1l-2.3 2.2z"/></svg>';
	$wa  = kjo_fa_dir()
		? '<i class="fab fa-whatsapp" aria-hidden="true"></i>'
		: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3C6.9 3 3 6.7 3 11.2c0 2 .8 3.8 2.1 5.2L4 21l4.8-1.5c1 .3 2.1.5 3.2.5 5.1 0 9-3.7 9-8.2S17.1 3 12 3z"/></svg>';
	return array( $tel, $wa );
}

function kjo_fa_dir() {
	$d = WP_PLUGIN_DIR . '/elementor/assets/lib/font-awesome/css/';
	return ( file_exists( $d . 'fontawesome.min.css' ) && file_exists( $d . 'brands.min.css' ) ) ? $d : '';
}

function kjo_cookie_url() {
	foreach ( array( 'cookie-richtlinie-eu', 'cookie-richtlinie', 'cookie-policy-eu' ) as $slug ) {
		$p = get_page_by_path( $slug );
		if ( $p && 'publish' === $p->post_status ) {
			return get_permalink( $p );
		}
	}
	return '';
}

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( kjo_fa_dir() ) {
			$u = plugins_url( 'elementor/assets/lib/font-awesome/css/' );
			wp_enqueue_style( 'kjo-fa', $u . 'fontawesome.min.css', array(), '5' );
			wp_enqueue_style( 'kjo-fa-brands', $u . 'brands.min.css', array( 'kjo-fa' ), '5' );
		}
	},
	20
);

add_action(
	'wp_head',
	function () {
		echo '<style id="kjo-head-css">' . KJO_HEAD_CSS . '</style>';
	},
	99
);

add_action(
	'wp_footer',
	function () {
		if ( is_admin() ) {
			return;
		}
		list( $tel, $wa ) = kjo_icons();
		$cfg = array(
			'tel'    => KJO_TEL,
			'wa'     => KJO_WA,
			'icoTel' => $tel,
			'icoWa'  => $wa,
			'cookie' => kjo_cookie_url(),
		);
		echo '<script id="kjo-head-js">window.KJO_HEAD=' . wp_json_encode( $cfg ) . ';' . KJO_HEAD_JS . '</script>';
	},
	60
);


/* ------------------------------------------------------------------
 * Seiten ohne Elementor im DJ-KOLJA-ONE-Design (seit 1.5.0)
 * Betrifft z. B. die Cookie-Richtlinie von Complianz: gleiche Kopf-
 * und Fußzeile, dunkler Hintergrund, Fira Sans.
 * ------------------------------------------------------------------ */
function kjo_is_plain_page() {
	if ( ! is_page() || is_front_page() ) {
		return false;
	}
	return 'builder' !== get_post_meta( get_queried_object_id(), '_elementor_edit_mode', true );
}

add_filter(
	'template_include',
	function ( $t ) {
		return kjo_is_plain_page() ? __DIR__ . '/kjo-page.php' : $t;
	},
	99
);

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! kjo_is_plain_page() ) {
			return;
		}
		$up = wp_upload_dir();
		foreach ( array( 'firasans.css', 'fira-sans.css' ) as $f ) {
			if ( file_exists( $up['basedir'] . '/elementor/google-fonts/css/' . $f ) ) {
				wp_enqueue_style( 'kjo-firasans', $up['baseurl'] . '/elementor/google-fonts/css/' . $f, array(), '1' );
				break;
			}
		}
	},
	30
);

define( 'KJO_PLAIN_CSS', <<<'KJOCSS'
html{scroll-behavior:smooth}
body.kjo-plain{margin:0!important;padding:0!important;background:#0F0C07!important;color:#F3F1E9!important;font-family:"Fira Sans",-apple-system,"Segoe UI",Roboto,sans-serif!important;font-weight:400;font-size:17px;line-height:1.7;-webkit-font-smoothing:antialiased}
body.kjo-plain *{box-sizing:border-box}
.kjo-sh{display:flex;flex-direction:column;gap:8px;padding:16px 40px;background:#0F0C07;border-bottom:1px solid rgba(178,157,117,.25)}
.kjo-sh-row{display:flex;align-items:center;justify-content:space-between;gap:18px}
.kjo-sh-logo{flex:none;display:block;line-height:0}
.kjo-sh-logo img{width:210px;height:auto;display:block}
.kjo-sh-nav{display:flex;align-items:center;justify-content:center;gap:20px;flex-wrap:wrap}
.kjo-sh a.kjo-l{color:#F3F1E9;text-decoration:none;font-size:15px;line-height:1.15;transition:color .2s}
.kjo-sh a.kjo-l:hover{color:#B29D75}
.kjo-sh-btn{display:inline-block;flex:none;background:#B29D75;color:#0F0C07!important;text-decoration:none;font-size:13px;font-weight:500;letter-spacing:1.5px;text-transform:uppercase;padding:12px 18px;border-radius:2px;line-height:1;transition:background .2s}
.kjo-sh-btn:hover{background:#C4B08A}
.kjo-sh .kjo-nav2{display:none;flex-wrap:wrap;justify-content:center;gap:14px;padding-top:12px;border-top:1px solid rgba(178,157,117,.3)}
.kjo-sh .kjo-nav2 a.kjo-l{font-size:13px}
@media(max-width:1024px){.kjo-sh-nav{display:none}.kjo-sh .kjo-nav2{display:flex}}
@media(max-width:767px){.kjo-sh{padding:14px 20px}.kjo-sh-logo img{width:170px}.kjo-sh-btn{display:none}}
.kjo-doc{max-width:900px;margin:0 auto;padding:72px 24px 96px}
.kjo-doc h1{font-weight:300;font-size:clamp(34px,5vw,54px);line-height:1.15;margin:0 0 32px;color:#F3F1E9}
.kjo-doc h2{font-weight:300;font-size:26px;line-height:1.25;margin:44px 0 12px;color:#F3F1E9}
.kjo-doc h3,.kjo-doc h4,.kjo-doc h5{font-weight:500;font-size:17px;margin:20px 0 8px;color:#F3F1E9}
.kjo-doc p,.kjo-doc li,.kjo-doc span,.kjo-doc div,.kjo-doc i,.kjo-doc em,.kjo-doc label{color:inherit}
.kjo-doc p{margin:0 0 14px;color:#D9D5CA}
.kjo-doc a{color:#B29D75!important;text-decoration:underline;text-underline-offset:3px}
.kjo-doc a:hover{color:#C4B08A!important}
.kjo-doc #cmplz-document,.kjo-doc .cmplz-document{max-width:none!important;margin:0!important;color:#D9D5CA!important;font-size:17px!important;font-family:inherit!important}
.kjo-doc #cmplz-document h2,.kjo-doc #cmplz-document h3,.kjo-doc #cmplz-document h4,.kjo-doc #cmplz-document p,.kjo-doc #cmplz-document li{font-family:inherit!important}
.kjo-doc #cmplz-document p,.kjo-doc #cmplz-document li{font-size:17px!important;color:#D9D5CA!important}
.kjo-doc details,.kjo-doc .cmplz-dropdown{background:#1A1712!important;border:1px solid rgba(178,157,117,.25)!important;border-radius:3px;margin:10px 0!important;color:#F3F1E9!important}
.kjo-doc details summary,.kjo-doc .cmplz-dropdown summary{background:transparent!important;color:#F3F1E9!important;cursor:pointer}
.kjo-doc details summary h3,.kjo-doc details summary h4,.kjo-doc details summary p,.kjo-doc details summary div{color:#F3F1E9!important;background:transparent!important}
.kjo-doc .cookies-per-purpose{background:rgba(178,157,117,.25)!important;border:1px solid rgba(178,157,117,.25)!important}
.kjo-doc .cookies-per-purpose>div,.kjo-doc .cookies-per-purpose div{background:#0F0C07!important;color:#D9D5CA!important}
.kjo-doc .cookies-per-purpose .purpose,.kjo-doc .cookies-per-purpose h4{color:#F3F1E9!important}
.kjo-doc table{width:100%;border-collapse:collapse;margin:14px 0}
.kjo-doc th,.kjo-doc td{border:1px solid rgba(178,157,117,.25);padding:10px 12px;text-align:left;color:#D9D5CA;background:transparent}
.kjo-doc .cmplz-btn,.kjo-doc button,.kjo-doc input[type=submit]{background:#B29D75!important;border:1px solid #B29D75!important;color:#0F0C07!important;font-family:inherit!important;font-weight:500;border-radius:2px;padding:10px 16px;cursor:pointer}
.kjo-doc .cmplz-categories .cmplz-category,.kjo-doc .cmplz-category{background:#1A1712!important;color:#F3F1E9!important}
.kjo-doc .cmplz-category-title,.kjo-doc .cmplz-description,.kjo-doc .cmplz-always-active{color:#F3F1E9!important}
.kjo-sf{border-top:1px solid rgba(178,157,117,.2);padding:28px 40px;display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap;color:#A39E93;font-size:13px}
.kjo-sf nav{display:flex;gap:20px;flex-wrap:wrap}
.kjo-sf a{color:#A39E93;text-decoration:none;font-weight:300}
.kjo-sf a:hover{color:#B29D75}
@media(max-width:767px){.kjo-sf{padding:24px 20px;flex-direction:column;align-items:flex-start}.kjo-doc{padding:48px 20px 72px}}
KJOCSS
);

/**
 * Strukturierte Daten (JSON-LD) für Suchmaschinen: Unternehmen, Leistungen, FAQ, Breadcrumbs.
 * Die Angaben stammen aus schema.json (erzeugt von site/export.py aus den Seitentexten).
 * Abschalten: add_filter( 'kjo_schema_aktiv', '__return_false' ); (z. B. wenn ein SEO-Plugin schon Schema ausgibt).
 *
 * @param array  $d    Inhalt von schema.json
 * @param string $slug Seiten-Slug ('start' für die Startseite)
 * @param string $home Startseiten-URL mit abschließendem Schrägstrich
 * @return array|null  @graph-Dokument oder null, wenn für die Seite nichts ausgegeben wird
 */
function kjo_schema_graph( $d, $slug, $home ) {
	if ( empty( $d['business'] ) || empty( $d['pages'][ $slug ] ) ) {
		return null;
	}
	$b    = $d['business'];
	$p    = $d['pages'][ $slug ];
	$org  = $home . '#business';
	$url  = ( 'start' === $slug ) ? $home : $home . $slug . '/';
	$area = array();
	foreach ( (array) $b['areas'] as $o ) {
		$area[] = array( '@type' => 'City', 'name' => $o );
	}
	foreach ( (array) $b['regions'] as $r ) {
		$area[] = array( '@type' => 'AdministrativeArea', 'name' => $r );
	}
	$business = array(
		'@type'        => array( 'LocalBusiness', 'EntertainmentBusiness' ),
		'@id'          => $org,
		'name'         => $b['name'],
		'legalName'    => $b['legalName'],
		'url'          => $home,
		'description'  => $b['description'],
		'telephone'    => $b['telephone'],
		'email'        => $b['email'],
		'founder'      => array( '@type' => 'Person', 'name' => $b['founder'] ),
		'address'      => array(
			'@type'           => 'PostalAddress',
			'addressLocality' => $b['locality'],
			'postalCode'      => $b['postalCode'],
			'addressCountry'  => $b['country'],
		),
		'areaServed'   => $area,
		'sameAs'       => $b['sameAs'],
	);
	if ( ! empty( $b['vatID'] ) ) {
		$business['vatID'] = $b['vatID'];
	}
	if ( function_exists( 'kjo_asset' ) ) {
		$business['image'] = kjo_asset( 'teilen.jpg' );
		$business['logo']  = kjo_asset( 'icon-512.png' );
	}
	$business['slogan'] = 'Jedes Event findet nur einmal statt.';
	$graph = array( $business );
	$page  = array(
		'@type'    => 'WebPage',
		'@id'      => $url . '#seite',
		'url'      => $url,
		'name'     => $p['name'],
		'isPartOf' => array( '@id' => $home . '#website' ),
		'about'    => array( '@id' => $org ),
	);
	$graph[] = array( '@type' => 'WebSite', '@id' => $home . '#website', 'url' => $home, 'name' => $b['name'], 'alternateName' => 'DJ Kolja One', 'inLanguage' => 'de-DE', 'publisher' => array( '@id' => $org ) );
	if ( 'faq' === $p['kind'] ) {
		$page['@type'] = 'FAQPage';
	} elseif ( 'about' === $p['kind'] ) {
		$page['@type'] = 'AboutPage';
	} elseif ( 'contact' === $p['kind'] ) {
		$page['@type'] = 'ContactPage';
	}
	$graph[] = $page;
	if ( 'service' === $p['kind'] || 'city' === $p['kind'] ) {
		$svc = array(
			'@type'      => 'Service',
			'@id'        => $url . '#leistung',
			'name'       => $p['name'],
			'serviceType' => isset( $p['serviceType'] ) ? $p['serviceType'] : 'DJ und Moderation',
			'provider'   => array( '@id' => $org ),
		);
		if ( ! empty( $p['description'] ) ) {
			$svc['description'] = $p['description'];
		}
		if ( ! empty( $p['city'] ) ) {
			$svc['areaServed'] = array( '@type' => 'City', 'name' => $p['city'] );
		} else {
			$svc['areaServed'] = $area;
		}
		$graph[] = $svc;
	}
	if ( ! empty( $p['faq'] ) ) {
		$qs = array();
		foreach ( $p['faq'] as $qa ) {
			$qs[] = array( '@type' => 'Question', 'name' => $qa[0], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $qa[1] ) );
		}
		$graph[] = array( '@type' => 'FAQPage', '@id' => $url . '#faq', 'mainEntity' => $qs );
		if ( 'FAQPage' === $page['@type'] ) {
			array_pop( $graph ); // FAQ-Seite: nur ein FAQPage-Eintrag
			array_pop( $graph );
			$page['mainEntity'] = $qs;
			$graph[] = $page;
		}
	}
	if ( ! empty( $p['crumbs'] ) && count( $p['crumbs'] ) > 1 ) {
		$items = array();
		foreach ( $p['crumbs'] as $i => $c ) {
			$items[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => rtrim( $home, '/' ) . $c[1] );
		}
		$graph[] = array( '@type' => 'BreadcrumbList', '@id' => $url . '#brotkrumen', 'itemListElement' => $items );
	}
	return array( '@context' => 'https://schema.org', '@graph' => $graph );
}

add_action(
	'wp_head',
	function () {
		if ( is_admin() || is_feed() || is_preview() || ! apply_filters( 'kjo_schema_aktiv', true ) ) {
			return;
		}
		if ( class_exists( '\Elementor\Plugin' ) && \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
			return;
		}
		if ( ! is_singular( 'page' ) ) {
			return;
		}
		$slug = is_front_page() ? 'start' : get_post_field( 'post_name', get_queried_object_id() );
		$file = __DIR__ . '/schema.json';
		if ( ! $slug || ! is_readable( $file ) ) {
			return;
		}
		$d = json_decode( (string) file_get_contents( $file ), true );
		$g = is_array( $d ) ? kjo_schema_graph( $d, $slug, trailingslashit( home_url( '/' ) ) ) : null;
		if ( $g ) {
			echo '<script type="application/ld+json">' . wp_json_encode( $g, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ) . "</script>\n";
		}
	},
	20
);

/**
 * Seitentitel, Meta-Beschreibung und Social-Vorschau (Open Graph, Twitter Card) aus schema.json.
 * Wird nicht ausgegeben, wenn Yoast, Rank Math, AIOSEO oder SEOPress aktiv sind.
 * Abschalten: add_filter( 'kjo_seo_aktiv', '__return_false' );
 *
 * @return array|null array( titel, beschreibung, url, bild ) für die aktuelle Seite
 */
function kjo_seo_seite() {
	static $r = false;
	if ( false !== $r ) {
		return $r;
	}
	$r = null;
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || ! apply_filters( 'kjo_seo_aktiv', true ) ) {
		return $r;
	}
	if ( is_admin() || ! is_singular( 'page' ) ) {
		return $r;
	}
	$slug = is_front_page() ? 'start' : get_post_field( 'post_name', get_queried_object_id() );
	$file = __DIR__ . '/schema.json';
	if ( ! $slug || ! is_readable( $file ) ) {
		return $r;
	}
	$d = json_decode( (string) file_get_contents( $file ), true );
	$p = isset( $d['pages'][ $slug ] ) ? $d['pages'][ $slug ] : null;
	if ( ! $p || empty( $p['title'] ) || empty( $p['desc'] ) ) {
		return $r;
	}
	$r = array(
		'titel' => $p['title'],
		'desc'  => $p['desc'],
		'url'   => get_permalink( get_queried_object_id() ),
		'bild'  => (string) get_the_post_thumbnail_url( get_queried_object_id(), 'large' ),
	);
	return $r;
}

add_filter(
	'pre_get_document_title',
	function ( $t ) {
		$s = kjo_seo_seite();
		return $s ? $s['titel'] : $t;
	},
	20
);

add_action(
	'wp_head',
	function () {
		$s = kjo_seo_seite();
		if ( ! $s ) {
			return;
		}
		$m = array(
			array( 'name', 'description', $s['desc'] ),
			array( 'property', 'og:type', 'website' ),
			array( 'property', 'og:locale', 'de_DE' ),
			array( 'property', 'og:site_name', 'DJ KOLJA ONE' ),
			array( 'property', 'og:title', $s['titel'] ),
			array( 'property', 'og:description', $s['desc'] ),
			array( 'property', 'og:url', $s['url'] ),
			array( 'name', 'twitter:title', $s['titel'] ),
			array( 'name', 'twitter:description', $s['desc'] ),
		);
		if ( $s['bild'] ) {
			$m[] = array( 'property', 'og:image', $s['bild'] );
			$m[] = array( 'name', 'twitter:image', $s['bild'] );
		}
		foreach ( $m as $x ) {
			echo '<meta ' . $x[0] . '="' . esc_attr( $x[1] ) . '" content="' . esc_attr( $x[2] ) . '">' . "\n";
		}
	},
	4
);

/**
 * Barrierefreiheit (seit 1.53.4): korrigiert zwei Ausgaben von Elementor, die Lighthouse bemängelt.
 *  - Akkordeon-Titel haben role="button", Elementor setzt aber aria-selected (nur für Tabs erlaubt) → entfernen.
 *  - Logo-Links ohne Text (Bild mit leerem alt) bekommen einen Namen.
 */
add_action(
	'wp_footer',
	function () {
		if ( is_admin() ) {
			return;
		}
		echo '<script id="kjo-a11y">(function(){function fix(r){(r||document).querySelectorAll("[role=button][aria-selected]").forEach(function(e){e.removeAttribute("aria-selected")});'
			. 'document.querySelectorAll("a[href]").forEach(function(a){if(a.textContent.trim()||a.getAttribute("aria-label"))return;var i=a.querySelector("img");if(i&&!i.getAttribute("alt"))i.setAttribute("alt",/^(\\/|https?:\\/\\/[^\\/]+\\/?)$/.test(a.getAttribute("href"))?"DJ KOLJA ONE – zur Startseite":(a.title||"Link"))})}'
			. 'document.querySelectorAll(".elementor-accordion-title:not([href]),.elementor-toggle-title:not([href])").forEach(function(a){if(!a.getAttribute("role"))a.setAttribute("role","none")});fix();try{new MutationObserver(function(m){m.forEach(function(x){if(x.attributeName==="aria-selected"&&x.target.getAttribute("role")==="button")x.target.removeAttribute("aria-selected")})}).observe(document.body,{subtree:true,attributes:true,attributeFilter:["aria-selected"]})}catch(e){}})();</script>' . "\n";
	},
	30
);

/**
 * Conversion-Ereignisse für Google Analytics 4 / Google Ads und Microsoft Clarity:
 *  - generate_lead   Anfrageformular erfolgreich abgeschickt (WPForms)
 *  - click_whatsapp  Klick auf einen WhatsApp-Link
 *  - click_phone     Klick auf eine Telefonnummer
 *  - click_email     Klick auf die E-Mail-Adresse (die Adresse wird zusätzlich in die Zwischenablage kopiert)
 * Außerdem öffnen Instagram- und Facebook-Links immer in einem neuen Tab.
 * Gesendet wird über das vorhandene gtag (Site Kit) bzw. die dataLayer; ob Google dabei Cookies setzt,
 * entscheidet der Einwilligungsmodus (Complianz). Abschalten: add_filter( 'kjo_conversions', '__return_false' );
 */
add_action(
	'wp_footer',
	function () {
		if ( is_admin() || ! apply_filters( 'kjo_conversions', true ) ) {
			return;
		}
		echo '<script id="kjo-conversions">' . KJO_CONV_JS . '</script>' . "\n";
	},
	30
);
/**
 * Bilder vergrößern (seit 1.67.2): Container mit der Klasse „kjo-zoom“ (z. B. der Beispiel-Setup-Plan) öffnen per Klick
 * bildschirmfüllend in Originalgröße. Ein weiterer Klick aufs Bild zoomt auf volle Auflösung (verschiebbar), Esc/✕ schließt.
 */
add_action(
	'wp_footer',
	function () {
		if ( is_admin() ) {
			return;
		}
		?>
<script id="kjo-zoom">(function(){var Z=document.querySelectorAll(".kjo-zoom");if(!Z.length)return;
var st=document.createElement("style");st.textContent='.kjo-zoom{cursor:zoom-in}.kjo-zoom:focus-visible{outline:2px solid #B29D75;outline-offset:4px}.kjo-zm{position:fixed;inset:0;z-index:99995;background:rgba(8,6,4,.95);overflow:auto;display:flex;-webkit-overflow-scrolling:touch}.kjo-zm img{margin:auto;max-width:calc(100vw - 24px);max-height:calc(100vh - 24px);width:auto;height:auto;cursor:zoom-in;box-shadow:0 20px 50px rgba(0,0,0,.6)}.kjo-zm.gross img{max-width:none;max-height:none;width:auto;min-width:min(1600px,200vw);cursor:zoom-out}.kjo-zm button{all:unset;box-sizing:border-box;position:fixed;top:12px;right:12px;width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;border:1px solid rgba(178,157,117,.7);color:#F3F1E9;background:rgba(22,19,16,.85);font:300 30px/1 "Fira Sans",sans-serif;z-index:1}.kjo-zm button:hover,.kjo-zm button:focus-visible{background:#B29D75;color:#0F0C07}.kjo-zm p{position:fixed;left:0;right:0;bottom:10px;margin:0;text-align:center;font:400 13px "Fira Sans",sans-serif;color:#A39E93;pointer-events:none}';document.head.appendChild(st);
function src(z){var M=window.KJO_MEDIA||{},c=(z.className.match(/kjo-m-([a-z0-9_]+)/)||[])[1],e=c&&M[c];if(e&&(e.full||e.img))return e.full||e.img;var b=getComputedStyle(z).backgroundImage.match(/url\(["']?(.*?)["']?\)/);return b&&b[1];}
var last;function zu(o){o.remove();document.documentElement.style.overflow="";document.removeEventListener("keydown",esc);if(last)last.focus();}
function esc(e){if(e.key==="Escape"){var o=document.querySelector(".kjo-zm");if(o)zu(o);}}
function auf(z){var u=src(z);if(!u)return;last=z;var o=document.createElement("div");o.className="kjo-zm";o.setAttribute("role","dialog");o.setAttribute("aria-modal","true");o.setAttribute("aria-label","Bild vergrößert");
 o.innerHTML='<button type="button" aria-label="Schließen">×</button><img alt=""><p>Tippen zum Heranzoomen · Esc oder × zum Schließen</p>';var i=o.querySelector("img");i.src=u;i.alt=z.getAttribute("aria-label")||"";
 o.addEventListener("click",function(e){if(e.target===i){o.classList.toggle("gross");return;}zu(o);});
 document.body.appendChild(o);document.documentElement.style.overflow="hidden";document.addEventListener("keydown",esc);o.querySelector("button").focus();try{if(window.kjoTrack)window.kjoTrack("bild_zoom",{item_name:u.split("/").pop()});}catch(x){}}
[].forEach.call(Z,function(z){z.setAttribute("role","button");z.tabIndex=0;if(!z.getAttribute("aria-label"))z.setAttribute("aria-label","Bild vergrößern");
 z.addEventListener("click",function(){auf(z);});z.addEventListener("keydown",function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();auf(z);}});});})();</script>
		<?php
	},
	40
);
/**
 * Datumsfelder überall (seit 1.67.1): Ein Klick irgendwo ins Feld – auch aufs Kalendersymbol – öffnet den Kalender.
 * Der eigene Aufruf ersetzt das Standardverhalten, damit der Kalender nicht gleichzeitig auf- und wieder zugeht.
 * Tastatur-Eingabe (TT.MM.JJJJ) bleibt unverändert. Auf Website und im Admin-Bereich.
 */
function kjo_datum_klick_js() {
	echo '<script id="kjo-datum-klick">document.addEventListener("click",function(e){var t=e.target;if(!t||t.tagName!=="INPUT"||t.type!=="date"||t.disabled||t.readOnly||typeof t.showPicker!=="function")return;try{t.showPicker();e.preventDefault();}catch(x){}},true);</script>' . "\n";
}
add_action( 'wp_footer', 'kjo_datum_klick_js', 5 );
add_action( 'admin_footer', 'kjo_datum_klick_js', 5 );
/**
 * Kalender für das Feld „Wunschdatum“ im WPForms-Anfrageformular (seit 1.23.0).
 * WPForms Lite hat kein Datumsfeld: Über das vorhandene Textfeld wird ein unsichtbares Datumsfeld gelegt.
 * Ein Klick öffnet den Kalender des Browsers; ins Textfeld (und damit in die E-Mail) kommt z. B. „Samstag, 14.11.2026“.
 * Erkennt jedes WPForms-Textfeld, dessen Beschriftung „Datum“ enthält. Abschalten: add_filter( 'kjo_wpf_kalender', '__return_false' );
 */
add_action(
	'wp_footer',
	function () {
		if ( is_admin() || ! apply_filters( 'kjo_wpf_kalender', true ) ) {
			return;
		}
		echo '<style id="kjo-wpf-date-css">.kjo-dp-wrap{position:relative!important;display:block!important;width:100%}.kjo-dp-wrap input.kjo-dp-txt{cursor:pointer;padding-right:44px!important;background-image:url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27%3E%3Cpath fill=%27%23B29D75%27 d=%27M7 2v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2V2h-2v2H9V2zm-2 8h14v10H5z%27/%3E%3C/svg%3E")!important;background-repeat:no-repeat!important;background-position:right 14px center!important;background-size:20px!important}.kjo-dp-wrap input.kjo-dp{position:absolute!important;left:0!important;top:0!important;width:100%;height:100%;opacity:0;cursor:pointer;margin:0;padding:0;border:0;z-index:2;-webkit-appearance:none;appearance:none}.kjo-dp-open{background:none;border:0;padding:6px 0 0;color:#B29D75;font:13px "Fira Sans",sans-serif;text-decoration:underline;cursor:pointer}</style>';
		echo '<script id="kjo-wpf-date">' . KJO_WPF_DATE_JS . '</script>' . "\n";
	},
	31
);
define( 'KJO_WPF_DATE_JS', <<<'KJODATE'
(function(){
function iso(d){return d.getFullYear()+"-"+("0"+(d.getMonth()+1)).slice(-2)+"-"+("0"+d.getDate()).slice(-2);}
function nice(v){var p=v.split("-");if(p.length!==3)return v;var d=new Date(+p[0],+p[1]-1,+p[2]);try{return d.toLocaleDateString("de-DE",{weekday:"long",day:"2-digit",month:"2-digit",year:"numeric"});}catch(e){return p[2]+"."+p[1]+"."+p[0];}}
function fire(el){["input","change","keyup","blur"].forEach(function(t){try{el.dispatchEvent(new Event(t,{bubbles:true}));}catch(e){}});if(window.jQuery){try{window.jQuery(el).trigger("change").valid&&window.jQuery(el).valid();}catch(e){}}}
function setup(c){
  var lab=c.querySelector(".wpforms-field-label"),txt=c.querySelector('input[type="text"]');
  if(!lab||!txt||txt.classList.contains("kjo-dp-txt")||!/datum/i.test(lab.textContent))return;
  var wrap=document.createElement("div");wrap.className="kjo-dp-wrap";txt.parentNode.insertBefore(wrap,txt);wrap.appendChild(txt);
  var dp=document.createElement("input");dp.type="date";dp.className="kjo-dp";dp.min=iso(new Date());dp.tabIndex=-1;dp.setAttribute("aria-hidden","true");wrap.appendChild(dp);
  function size(){dp.style.height=txt.offsetHeight+"px";dp.style.bottom="auto";}size();window.addEventListener("resize",size);
  txt.classList.add("kjo-dp-txt");txt.readOnly=true;txt.setAttribute("inputmode","none");txt.setAttribute("autocomplete","off");
  if(!txt.getAttribute("placeholder"))txt.setAttribute("placeholder","Tag im Kalender wählen");
  function open(){try{if(dp.showPicker){dp.showPicker();return;}}catch(e){}try{dp.focus();dp.click();}catch(e){}}
  dp.addEventListener("click",function(){open();});
  txt.addEventListener("click",function(e){e.preventDefault();open();}); /* falls das Overlay vom Theme verschoben wird */
  txt.addEventListener("keydown",function(e){if(e.key==="Enter"||e.key===" "||e.key==="ArrowDown"){e.preventDefault();open();}});
  var av=null;
  function hint(cls,html){if(!av){av=document.createElement("div");av.className="kjo-av";av.setAttribute("role","status");av.setAttribute("aria-live","polite");}av.className="kjo-av "+cls;av.innerHTML=html;if(!av.parentNode)b.parentNode.insertBefore(av,b.nextSibling);}
  function check(v){var K=window.KJO_KAL;if(!K||!window.fetch)return;fetch(K.api+(K.api.indexOf("?")>-1?"&":"?")+"von="+v,{credentials:"omit"}).then(function(r){return r.json()}).then(function(j){if(dp.value!==v||!j||!j.dj)return;
    if(j.dj==="frei")hint("ok","✓ <strong>Termin noch verfügbar!</strong> Schickt mir eure Anfrage, ich melde mich innerhalb von 24 Stunden bei euch.");
    else if(j.dj==="vor")hint("vor","◐ <strong>Termin vorreserviert, fragt gerne trotzdem an.</strong> Wird die Reservierung nicht bestätigt, seid ihr als Nächste dran.");
    else if(j.equip!=="belegt")hint("no","✕ <strong>An diesem Tag bin ich leider schon ausgebucht.</strong> Musikanlage und Licht sind aber "+(j.equip==="teil"?"teilweise ":"")+"noch frei: <a href=\""+K.mieten+"?von="+v+"#pakete\">Nur Equipment mieten? →</a>");
    else hint("no","✕ <strong>An diesem Tag bin ich leider schon ausgebucht.</strong> Gerne frage ich in meinem DJ-Netzwerk nach einem Kollegen für euch, oder ihr wählt einen anderen Tag.");}).catch(function(){});}
  dp.addEventListener("change",function(){if(dp.value){txt.value=nice(dp.value);fire(txt);check(dp.value);}else if(av&&av.parentNode){av.parentNode.removeChild(av);}});
  var b=document.createElement("button");b.type="button";b.className="kjo-dp-open";b.textContent="Noch kein festes Datum?";
  b.addEventListener("click",function(){txt.value="noch offen – siehe Nachricht";dp.value="";if(av&&av.parentNode)av.parentNode.removeChild(av);fire(txt);var f=c.closest("form"),m=f&&f.querySelector("textarea");if(m){m.focus();if(!m.value)m.setAttribute("placeholder","Zeitraum oder mögliche Termine, z. B. „Sommer 2027, ein Samstag“");}});
  wrap.parentNode.insertBefore(b,wrap.nextSibling);
}
function init(){[].forEach.call(document.querySelectorAll(".wpforms-form .wpforms-field-text"),setup);}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();
KJODATE
);
define( 'KJO_CONV_JS', <<<'KJOCONV'
(function(){
var last={};
function send(name,params){
  var now=Date.now();if(last[name]&&now-last[name]<1500)return;last[name]=now;
  params=params||{};params.page_path=location.pathname;
  try{if(typeof window.gtag==="function"){window.gtag("event",name,params);}else{(window.dataLayer=window.dataLayer||[]).push(Object.assign({event:name},params));}}catch(e){}
  try{if(typeof window.clarity==="function"){window.clarity("event",name);}}catch(e){}
  try{document.dispatchEvent(new CustomEvent("kjo:track",{detail:{name:name,params:params}}));}catch(e){} /* z. B. für den Meta-Pixel (kjo-meta-pixel.php) */
}
window.kjoTrack=send;
function toast(msg){
  var d=document.createElement("div");d.textContent=msg;d.setAttribute("role","status");
  d.style.cssText="position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:100000;background:#1A1712;color:#F3F1E9;border:1px solid #B29D75;border-radius:4px;padding:12px 18px;font:15px/1.4 'Fira Sans',sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.5);max-width:90vw;text-align:center";
  document.body.appendChild(d);setTimeout(function(){d.style.transition="opacity .4s";d.style.opacity="0";},2600);setTimeout(function(){d.remove();},3100);
}
function copyMail(addr){
  function ok(){toast("E-Mail-Adresse kopiert: "+addr);}
  try{if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(addr).then(ok,function(){});return;}}catch(e){}
  try{var ta=document.createElement("textarea");ta.value=addr;ta.style.position="fixed";ta.style.opacity="0";document.body.appendChild(ta);ta.select();if(document.execCommand("copy"))ok();ta.remove();}catch(e){}
}
function ext(){var l=document.querySelectorAll('a[href*="instagram.com"],a[href*="facebook.com"]');for(var i=0;i<l.length;i++){l[i].setAttribute("target","_blank");var r=(l[i].getAttribute("rel")||"");if(r.indexOf("noopener")<0)l[i].setAttribute("rel",(r+" noopener").trim());}}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",ext);else ext();
document.addEventListener("click",function(ev){
  var a=ev.target&&ev.target.closest?ev.target.closest("a[href]"):null;if(!a)return;
  var h=(a.getAttribute("href")||"").toLowerCase();
  if(h.indexOf("mailto:")===0){send("click_email",{method:"email"});copyMail(decodeURIComponent(a.getAttribute("href").slice(7).split("?")[0]));}
  else if(h.indexOf("tel:")===0){send("click_phone",{method:"telefon"});}
  else if(h.indexOf("wa.me/")>-1||h.indexOf("whatsapp.com")>-1||h.indexOf("whatsapp:")===0){send("click_whatsapp",{method:"whatsapp"});}
},true);
var seen=false;
function lead(){if(seen)return;seen=true;send("generate_lead",{method:"formular"});}
if(window.jQuery){window.jQuery(document).on("wpformsAjaxSubmitSuccess",lead);}
document.addEventListener("wpformsAjaxSubmitSuccess",lead);
function check(){if(seen)return;var c=document.querySelector(".wpforms-confirmation-container-full,.wpforms-confirmation-container");if(c&&c.offsetParent!==null){lead();}}
if(document.querySelector(".wpforms-form,.wpforms-confirmation-container-full")){
  check();
  if(window.MutationObserver){new MutationObserver(check).observe(document.body,{childList:true,subtree:true});}
}
})();
KJOCONV
);

/**
 * Überschrift passend zur Suchanzeige (seit 1.27.0).
 * Google Ads hängt per „Suffix der finalen URL“ kw={keyword} an. Erkennt das Skript darin einen bekannten Anlass
 * (und optional einen Ort), wird die H1 der Leistungsseite z. B. zu „DJ für eure Weihnachtsfeier in Ulm“.
 * Es werden nur feste Wörter aus den Listen unten angezeigt – nie Text aus der URL.
 * Abschalten: add_filter( 'kjo_dyn_h1', '__return_false' );
 */
add_action(
	'wp_footer',
	function () {
		if ( is_admin() || ! apply_filters( 'kjo_dyn_h1', true ) ) {
			return;
		}
		if ( ! is_page( array( 'firmenfeier-dj', 'hochzeits-dj', 'geburtstags-dj', 'event-dj' ) ) ) {
			return;
		}
		echo '<script id="kjo-dyn-h1">' . KJO_DYN_H1_JS . '</script>' . "\n";
	},
	32
);

define( 'KJO_DYN_H1_JS', <<<'KJODYN'
(function(){
try{
  var m=location.search.match(/[?&]kw=([^&]*)/);if(!m)return;
  var kw=decodeURIComponent(m[1].replace(/\+/g," ")).toLowerCase();
  kw=kw.replace(/ae/g,"ä").replace(/oe/g,"ö").replace(/ue/g,"ü");
  var A=[["weihnachtsfeier","eure Weihnachtsfeier"],["betriebsfeier","eure Betriebsfeier"],["firmenevent","euer Firmenevent"],["firmenfeier","eure Firmenfeier"],["sommerfest","euer Sommerfest"],["jubiläum","euer Jubiläum"],["hochzeit","eure Hochzeit"],["geburtstag","euren Geburtstag"],["stadtfest","euer Stadtfest"],["vereinsfeier","eure Vereinsfeier"],["silvester","eure Silvesterparty"]];
  var O=[["neu-ulm","in Neu-Ulm"],["neu ulm","in Neu-Ulm"],["memmingen","in Memmingen"],["ulm","in Ulm"],["kempten","in Kempten"],["kaufbeuren","in Kaufbeuren"],["füssen","in Füssen"],["ravensburg","in Ravensburg"],["biberach","in Biberach"],["landsberg","in Landsberg am Lech"],["mindelheim","in Mindelheim"],["illertissen","in Illertissen"],["oberschwaben","in Oberschwaben"],["schwaben","in Schwaben"],["allgäu","im Allgäu"]];
  function find(L){for(var i=0;i<L.length;i++){if(kw.indexOf(L[i][0])>-1)return L[i][1];}return "";}
  var a=find(A);if(!a)return;
  var o=find(O)||"im Allgäu & Oberschwaben";
  var h=document.querySelector("h1");if(!h)return;
  var t=h.querySelector(".elementor-heading-title")||h;
  t.textContent="DJ für "+a+" "+o;
}catch(e){}
})();
KJODYN
);
