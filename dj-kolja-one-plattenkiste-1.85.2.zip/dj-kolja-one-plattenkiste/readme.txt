=== DJ KOLJA ONE Plattenkiste ===
Songs aus der Mediathek für das DJ-Pult auf der Seite „Meine Musik“.

1. MP3 hochladen (Medien → Datei hinzufügen).
2. In den Datei-Details „Plattenkiste: Genre“ ausfüllen (oder Genre im MP3 hinterlegen).
3. BPM und Tonart (Camelot, z. B. 8A) werden beim Hochladen automatisch erkannt, sobald die Mediathek im Browser geöffnet ist – Korrektur in den Datei-Details möglich. Optional: Labelfarbe, Reihenfolge. Beschriftung = kleine Info-Zeile unter dem Titel.
4. Video: MP4 mit gleichem Dateinamen hochladen (song.mp3 + song.mp4) – wird automatisch verknüpft.
5. Übersicht: Medien → Plattenkiste.

Seit 1.4.0: Navigation bleibt beim Scrollen oben stehen, Anrufen + WhatsApp als Icons rechts im Menü, Cookie-Banner im DJ-KOLJA-ONE-Design, Link „Cookie-Richtlinie“ in der Fußzeile.

Seit 1.4.1: Keine blauen Markierungen mehr beim Ziehen am Crossfader. Kein 128-kbps-Hinweis mehr: Songs laufen in der hochgeladenen Qualität.

Seit 1.5.0: Seiten ohne Elementor (z. B. Cookie-Richtlinie) erscheinen im DJ-KOLJA-ONE-Design mit gleicher Kopf- und Fußzeile.

Seit 1.85.2: Rechnungen: Knopf „Anschrift übernehmen“, wenn die Anschrift im Angebot nachträglich ergänzt oder korrigiert wurde (Nummer und Beträge bleiben, altes PDF bleibt erhalten, Verlauf hält die alte Anschrift fest).
Seit 1.85.1: Telegram: Auftragsbestätigung abfragen (GET /auto/ab/{id}) für den „Senden“-Knopf; /auto/ab liefert Summe und Name.
Seit 1.85.0: Auftragsbestätigung im Angebot (PDF „AB-<Nr.>“ mit Auftragssumme, optionalem Zahlungshinweis, Vertragsbedingungen/Mietvertrag; E-Mail und WhatsApp; Status „Auftrag bestätigt“, DJ-Anfrage „Gebucht“), auch über Telegram/n8n (REST /auto/ab).
Seit 1.84.2: Beamer-Fotos in voller Größe und ohne automatisches Freistellen (das hat das weiße Gerät mit ausgeschnitten) – alte Fassungen werden ersetzt. Bildergalerie der Geräte ohne Scrollbalken: am Computer umbrechend, am Handy wischen.
Seit 1.84.1: Beamer: 3 Fotos werden automatisch in die Mediathek übernommen (Gerätefotos aus assets/geraete/), HDMI-Kabel im Lieferumfang, 2 × HDMI.
Seit 1.84.0: Neues Gerät ViewSonic LSD500HD Laser-Beamer (neue Kategorie „Video & Beamer“), 55 € Tag, 80 € Wochenende, Kaution 350 €.
Seit 1.83.0: Social: Benutzerschlüssel aus dem Graph-API-Explorer direkt einfügen – die Website verlängert ihn und holt den dauerhaften Seitenschlüssel selbst, nennt fehlende Berechtigungen und prüft die Verbindung gleich mit. Song-Kommentar-Warnmail erklärt Code 190 und die Erneuerung Schritt für Schritt.
Seit 1.82.1: Paket XS: Hinweis ergänzt (Terrasse bei regenfreiem Wetter, bis zu 6 Akku-Scheinwerfer oder Cameo Thunder Wash dazubuchbar).
Seit 1.82.0: Neues Paket XS „Kompakt“ mit JBL PartyBox 720 und Kabelmikrofon (49 € Tag, 69 € Wochenende, Kaution 250 €) – für kleine Räume und Orte, an denen Stative stören; steht vor Paket S.
Seit 1.81.3: Mietpreis JBL PartyBox 720: 45 € pro Tag, 65 € Wochenende, Kaution 250 €.
Seit 1.81.2: Neues Gerät JBL PartyBox 720 im Verleih (Kategorie Lautsprecher, wird automatisch angelegt; Preis auf Anfrage, bis ein Mietpreis eingetragen ist).
Seit 1.81.1: Neue Playlist „Silvester Party 2026/27“ auf der Event-Seite und unter Meine Musik.
Seit 1.81.0: Alle 17 Spotify-Playlisten „DJ KOLJA ONE …“: Meine Musik zeigt alle nach Themen (Tanzfläche; Hochzeit, Empfang & Dinner; Geburtstag, Firmenfeier & mehr), Startseite die sechs Genre-Playlisten, Hochzeit/Geburtstag/Firmenfeier/Event je sechs passende. Shortcode [kjo_playlists auswahl="…" gruppen="1"].
Seit 1.80.2: Playlisten: Play-Symbol und Pfeile als goldene Grafik (statt bunter Emojis auf iPhone); DJ-Pult und Startseiten-Pult: ▶ wird als Schriftzeichen statt Emoji angezeigt.
Seit 1.80.1: Weihnachtsfeier-Hinweis auf der Firmenfeier-Seite stellt sich nach Monat selbst um (Okt.–Dez. kurzfristig anfragen); Anlass-Texte der Mietpakete werden automatisch korrigiert.
Seit 1.80.0: Hochzeitsseite in ihr/euch-Form; Angebote und Rechnungen mit „Anrede: ihr“ (automatisch bei Anlass Hochzeit, eigene ihr-Texte in den Einstellungen); Mietrechnung mit Übergabe-/Rückgabeprotokoll zum Anhaken und optionalen Unterschriftszeilen; Unterschriftszeilen im Mietvertrag abschaltbar; neuer Spotify-Hinweis; Textkorrekturen auf der ganzen Website.
Seit 1.79.0: WhatsApp-Versand von Angeboten und Rechnungen über WhatsApp Web (Business-Konto im Browser, Einstellung „WhatsApp senden über“), Datenschutzerklärung mit Abschnitt „Spotify-Playlisten“ (wird automatisch eingespielt).
Seit 1.78.0: Spotify-Playlisten direkt auf der Website abspielen (Startseite und Meine Musik) – Shortcode [kjo_playlists stil="karten|chips"], Player wird erst beim Klick auf „Hier anhören“ geladen (2-Klick), Ereignis playlist_play. Seiten neu einspielen.
Seit 1.77.0: Rechnungen – im Angebot (Kasten „Rechnungen“) komplette Rechnung oder Anzahlungs- und Schlussrechnung (Anzahlung wird abgezogen) erstellen, Nummern 2026-137 ff. (jedes Jahr neu ab 001), Zahlungsziel 15 Tage privat / 30 Tage geschäftlich, „bereits bezahlt“ (bar/Überweisung), Versand per E-Mail oder WhatsApp, bezahlt markieren, Storno per Stornorechnung. Liste unter Angebote → Rechnungen. Neue Status „Rechnung gestellt“ und „Rechnung bezahlt“ (Angebot und DJ-Anfrage). Doku: docs/RECHNUNGEN.md.
Seit 1.76.2: Angebots-PDF – Text, der über eine Seite hinausläuft, ist auf der Folgeseite wieder dunkel (war fast unsichtbar hell). Internet-Adressen im Angebotstext sind im PDF anklickbar (z. B. der Link zur Gesprächsbuchung).
Seit 1.76.1: Kontaktseite hat zusätzlich die Sprungmarke #kennenlernen (neben #gespraech) – Links wie dj-kolja-one.de/kontakt/#kennenlernen springen direkt zur Gesprächsbuchung. Seiten neu einspielen.
Seit 1.76.0: Alles in Sie-Form – alle Seiten, Formulare, Bestätigungs-Mails, Kennenlernen, Mietkorb, Musikwunschliste, Songwunsch, DJ-Pult, Angebote (PDF, E-Mail, WhatsApp) und Automationen (Auto-DM, Song-Kommentar, Reel-Text). Gespeicherte Standardtexte werden einmalig automatisch umgestellt (nur wenn unverändert). Seiten neu einspielen.
Seit 1.75.1: WhatsApp-Kacheln (Start, Kontakt, Hochzeit, Geburtstag, Firmenfeier, Event) ohne großes goldenes Symbol – das grüne Symbol vor „WhatsApp“ bleibt. Seiten neu einspielen.
Seit 1.75.0: Angebote aus Telegram – beim Tippen auf „Senden“ im Telegram-Bot legt n8n das DJ-Angebot mit allen finalen Angaben an (Angebote → Automatik: Schlüssel). Ein PDF-Dienst auf dem Server baut das PDF mit demselben Code wie der Editor (neu: assets/pdf/angebot-pdf.js, Dienst: assets/pdf/kjo-pdf-server.js); es hängt an der E-Mail und steht mit Link und Verlauf unter „Angebote“, die passende DJ-Anfrage (gleiche E-Mail) wird verknüpft. Neu im Angebot: eigene Anrede, Sie-Form und Umsatzsteuer (inkl. 19 % MwSt. bzw. netto zzgl. MwSt.; leer = wie bisher § 19 UStG – dann passt das PDF auch den § 19-Satz in den Vertragsbedingungen an).
Seit 1.74.0: DJ-Angebote mit Vertragsbedingungen – Haken „Vertragsbedingungen anhängen“ hängt § 1–16 (Text unter Angebote → Einstellungen → Vertragsbedingungen DJ, Zeile „---“ = neue Seite) als eigene Seiten an das PDF. Ohne Unterschriftszeilen (digitale Unterschrift wird geprüft). Vor dem Einsatz anwaltlich prüfen lassen.
Seit 1.73.1: Fehler „kopf is not a function“ behoben – PDF erzeugen funktioniert wieder für DJ- und Miet-Angebote.
Seit 1.73.0: Miet-Angebote mit Mietvertrag – Haken „Mietvertrag anhängen“ hängt Mietvertrag (§ 1–3 aus dem Angebot, ab § 4 Text aus Angebote → Einstellungen, optional Stornierung), Quittung (Miete, Kaution erhalten, Kaution zurück) und Übergabeprotokoll mit Unterschriften an das PDF. ENTWURF – Vertragstext vor dem Einsatz anwaltlich prüfen lassen.
Seit 1.72.4: Technik mieten – Saison-Abschnitt „Weihnachten & Silvester“ unter dem Seitenkopf (Anker #feiertage). Mein Equipment: Bild des Pioneer DDJ-FLX10 aus der Geräte-Datenbank im Abschnitt „Mein Arbeitsplatz“; [kjo_geraet_bild] kennt jetzt hoehe="…".
Seit 1.72.3: Angebots-PDF gestochen scharf – Logo als transparentes PNG in doppelter Auflösung (statt JPG), der Claim „Jedes Event findet nur einmal statt.“ samt Linien als Vektorschrift.
Seit 1.72.2: Song-Kommentar zuverlässiger – der Instagram-Zugriffsschlüssel wird täglich geprüft; scheitert der Schlüssel oder der Kommentar, kommt eine E-Mail an die Anfrage-Adresse und oben im Admin steht ein Hinweis. Der GitHub-Anstoß ruft die Website dienstags alle 5 statt alle 20 Minuten auf.
Seit 1.72.1: Sicherheits-Update. Kontakt-, Miet- und Kennenlern-Formular lassen sich nicht mehr als Spam-Schleuder nutzen (keine Links in Name/Ort/Gäste/Telefon, eine Bestätigungsmail pro Adresse und Tag, höchstens 20 pro Stunde, Sperre pro IPv6-Netz). Kennenlernen: ein offener Termin pro E-Mail-Adresse, Schutz vor Doppelbuchung, Kalenderdateien nur im temporären Ordner. Bewertungen/Teilen mit Obergrenze pro Song, Song-Videos nur aus echten Videodateien, Cache-Schlüssel ohne Host-Kopf, Purge-Token geschützt. Neue Bilder erscheinen sofort. Datenschutzerklärung um die Begrenzung der Bestätigungsmails ergänzt (wird beim nächsten Öffnen des Dashboards automatisch eingespielt).
Seit 1.72.0: Spotify-Playlisten je Genre – „Meine Musik“ zeigt das Repertoire als Karten mit Button „Auf Spotify anhören“ (Anker #playlisten), die Startseite eine Genre-Zeile unter den Bewertungen. Spotify-Links öffnen in neuem Tab, Klicks zählen als Ereignis playlist_klick.
Seit 1.71.3: Kommentar → WhatsApp zeigt „Letzte Meldung von Meta“ (auch ausgeschaltet) und bei leerer Abo-Liste die genaue Antwort von Meta.
Seit 1.71.2: Kommentar → WhatsApp – „Verbindung prüfen & bei Meta anmelden“ trägt das Webhook-Abo (Instagram: comments, WhatsApp: messages) direkt bei Meta ein und zeigt, was abonniert ist. Kein Umweg über die Menüs der Meta-App mehr.
Seit 1.71.1: WhatsApp-Symbol überall in WhatsApp-Grün (#25D366), auch in der Navigation.
Seit 1.71.0: Social → Kommentar → WhatsApp – wie ManyChat: Wer ein Stichwort (z. B. „DJ“) unter einem Reel kommentiert, bekommt eine Antwort, eine Instagram-DM mit WhatsApp-Link und auf WhatsApp automatisch deinen Link, auf Wunsch mit MP3/PDF aus Google Drive direkt im Chat. Datenschutzerklärung um automatische Antworten ergänzt (wird automatisch eingespielt).
Seit 1.70.1: Jeder WhatsApp-Link (Buttons, Text, Fußzeile) zeigt automatisch das WhatsApp-Symbol; das Navigations-Icon nutzt dasselbe Logo.
Seit 1.70.0: Fotos zu Bewertungen – bewertung_h1 … bewertung_f2 in die Mediathek laden, dann erscheint das Bild oben in der jeweiligen Bewertungskarte. Seiten aus Vorlage einspielen.
Seit 1.69.2: Release-Zeit 18 Uhr; Song-Kommentar ab 18:10 mit bis zu 6 Versuchen alle 20 Minuten, danach Hinweis im Social-Verlauf.
Seit 1.69.1: Song-Kommentar mit einstellbarer Uhrzeit (Standard 18:10 am Release-Tag), pünktlich ausgelöst durch Seitenaufrufe und einen GitHub-Ablauf dienstags.
Seit 1.69.0: Social → Song-Kommentar – erster Instagram-Kommentar automatisch unter dem Release-Reel (Kurzlink dj-kolja-one.de/song/<ID>), Song wird danach als erl. abgehakt.
Seit 1.68.1: Release-Datum und „erl.“ auch direkt beim Song (Mediathek → Song bearbeiten); Got the Summer Feeling auf 18.10.2026 korrigiert, offene Termine neu geplant.
Seit 1.68.0: Plattenkiste mit Spalte „Release“ – jeden Dienstag 19 Uhr ein Song in der Reihenfolge des Pults, „Termine planen“, Abhaken mit „erl.“, Filter und Anzeige des nächsten Release.
Seit 1.67.2: Beispiel-Setup auf der Equipment-Seite per Klick vergrößerbar (Originalgröße, zweiter Klick zoomt heran). Seiten aus Vorlage einspielen.
Seit 1.67.1: Datumsfelder überall (Datum-Check, Anfrage, Verleih, Admin) – ein Klick aufs Kalendersymbol oder ins Feld öffnet den Kalender.
Seit 1.67.0: Intro-Videos auch für Über mich, Technik mieten, Equipment, Einsatzgebiete und alle Ortsseiten; Hochformat mit kräftigerem Verlauf. Seiten aus Vorlage einspielen.
Seit 1.66.0: Intro-Videos auch für Geburtstags-DJ, Firmenfeier-DJ und Event-DJ (Event mit echten Clips, GEMA-Hinweis abgeschnitten). Kein erneutes Einspielen nötig.
Seit 1.65.1: Intro-Video Hochzeit – kleine Schrift größer, heller und mit Schatten, dunklerer Verlauf hinter dem Text; hochkant kürzere Zeile ohne Umbruch.
Seit 1.65.0: Intro-Videos im Kopfbereich der Leistungsseiten (zuerst Hochzeits-DJ): stummer 12-Sekunden-Loop, quer und 4:5 fürs Handy. Seiten aus Vorlage einspielen.
Seit 1.64.0: USt-IdNr. DE331619498 im Impressum (wird beim Einspielen ergänzt), in den Suchmaschinen-Daten (vatID) und in der Fußzeile der Angebots-PDFs.
Seit 1.63.0: Plattenkiste: Songliste per Klick auf die Spaltenköpfe sortieren (Titel, Genre, BPM, Tonart, Qualität, Video, Bewertung, Im Pult) und nach Titel, Genre und „Im Pult“ filtern.
Seit 1.62.2: Meta-Pixel: Der ganze Meta-Tag zur Domain-Bestätigung kann eingefügt werden (vorher blieb das Feld leer).
Seit 1.62.1: Besucher-Statistik: Tagesbeschriftung zweizeilig (Wochentag, darunter Datum) – bricht auf dem Handy nicht mehr um.
Seit 1.62.0: Besucher-Statistik aus Google Analytics 4 (Dashboard → Besucher-Statistik): Dashboard-Box mit „gerade aktiv“, heute pro Stunde und 14 Tagen; Tagesbericht mit Diagrammen jeden Morgen gegen 7 Uhr per E-Mail. Verbindung über ein Dienstkonto mit Leserechten.
Seit 1.61.1: Datenschutzerklärung um Abschnitt 14 „Meta-Pixel“ ergänzt (Seiten aus Vorlage einspielen).
Seit 1.61.0: Meta-Pixel (Social → Meta-Pixel): lädt nur nach Marketing-Zustimmung (Complianz); Ereignisse PageView, ViewContent, SongPlay, SongShare, Contact, Schedule, Lead. Domain-Bestätigung per Meta-Tag. Das Pult meldet „song_play“ einmal pro Song.
Seit 1.60.0: Social: Animationen aus Claude Motion (HTML) hochladen – GitHub rendert sie hochkant als Reel, optional mit eigener Musik.
Seit 1.59.0: Social: Video und Musik direkt auf der Social-Seite hochladen oder aus der Mediathek wählen (ohne Umweg über Medien).
Seit 1.58.2: Social: Der GitHub-Ablauf installiert ffmpeg zum Aufbereiten der Videos selbst.
Seit 1.58.1: Social: Eigene Songs aus der Mediathek lassen sich trotz Download-Schutz darunterlegen (GitHub holt sie per SFTP).
Seit 1.58.0: Social: MOV-Videos, eigene Musik darunterlegen und Querformat aufbereiten (über GitHub), Vorschau-Link.
Seit 1.57.0: Neues Menü „Social“: Reels direkt auf Instagram und die Facebook-Seite posten (Graph-API von Meta, ohne Fremddienst). Einrichtung: social/README.md im Repo.
Seit 1.56.3: Kennenlerngespräch: importierte Termine mit Uhrzeit (z. B. aus Google) sperren nur die überschneidenden Zeiten statt des ganzen Tages.
Seit 1.56.2: Kennenlerngespräch: „In den Kalender eintragen“ funktioniert auf dem iPhone (echte .ics-Datei statt data-Link); Bestätigung „Danke! Euer …“.
Seit 1.56.1: Datenschutzerklärung ergänzt (Kennenlerngespräch buchen, Angebote).
Seit 1.56.0: Kennenlerngespräch direkt buchen (Kontaktseite, Zeiten unter DJ-Anfragen → Kennenlernen: Zeiten). Neues Menü „Angebote“: Miet- und DJ-Angebote aus Anfragen erstellen, als PDF speichern und per E-Mail oder WhatsApp senden.
Seit 1.55.4: Meine Musik auf dem Handy: 2 Platten pro Reihe, Knöpfe (A/B, Automix, Teilen) wieder vollständig bedienbar.
Seit 1.55.3: Startseiten-Video erscheint sofort (nicht erst nach Ablauf des Medien-Zwischenspeichers).
Seit 1.55.2: Das Startseiten-Video liegt im Plugin (assets/motion) und erscheint ohne Upload in die Mediathek.
Seit 1.55.1: Startseite: Abschnitt „DJ KOLJA ONE auf einen Blick“ mit dem 40-Sekunden-Video (start_motion.mp4, auf dem Handy start_motion_hoch.mp4), stumm in Schleife, lädt erst beim Hinscrollen.
Seit 1.55.0: Seiten-Cache – Seiten werden für Besucher ohne Anmeldung bis zu 8 Stunden fertig ausgeliefert (Kontakt und Technik mieten ausgenommen, Aufrufe mit Parametern nie); leert sich bei jeder Änderung und beim Einspielen der Vorlagen von selbst.
Seit 1.54.4: Elementor-CSS bleibt eingebettet (keine Umstellung auf externe Dateien mehr, die bei jedem Admin-Aufruf zurückgesetzt wurde).
Seit 1.54.3: Galerie-Vorschaubilder auf dem Handy in kleinerer Fassung, Logo ohne doppelte Attribute.
Seit 1.54.2: Ladezeit Handy: Logos als kleine WebP (600 px), Fotos erst kurz vor dem Sichtbarwerden und auf dem Handy in kleinerer Fassung, Start-Pult animiert erst nach dem Laden und nur wenn sichtbar, Bilder/Schriften 1 Jahr im Browser-Cache, Titel nicht mehr doppelt.
Seit 1.54.1: Titel und Viewport nur einmal im Seitenkopf, Unternehmensdaten nur noch in einem Schema-Block, Elementor-CSS als externe Datei, keine Block-Theme-Styles und Emoji-Skripte auf Elementor-Seiten, readme.html/license.txt gesperrt.
Seit 1.54.0: Ladezeit: Browser-Cache und Komprimierung per .htaccess (wird beim nächsten Admin-Aufruf eingetragen), Roboto-Schriften entfernt, Kopf-Logo sofort geladen und mit festen Maßen, Datumsfeld springt nicht mehr, Startseite scrollt auf dem Handy nicht mehr von selbst zum Pult.
Seit 1.53.5: Songwunsch- und Musikwunschlisten-Seite mit vollem Logo (inkl. „Jedes Event findet nur einmal statt.“).
Seit 1.53.4: Barrierefreiheit: Logo-Links mit Namen, DJ-Pulte als Gruppe statt Bild, Crossfader mit Startwert, Erklär-Fenster mit Namen, Akkordeon ohne unzulässiges aria-selected.
Seit 1.53.3: Meine Musik: Doppelklick bzw. Doppeltipp auf den Crossfader (oder seine Schiene) stellt ihn in die Mitte; Taste 0 oder Pos1 ebenso.
Seit 1.53.2: Beschreibung und Vorschau-Angaben stehen nur noch einmal im Seitenkopf (vorher doppelt); Seitenname für Google mit alternativer Schreibweise.
Seit 1.53.1: Plattenkiste mit höchstens 4 Platten pro Reihe (mehr brechen um, nichts ragt mehr aus der Kiste), fertige Automixe auch für Genres mit nur einem Song (z. B. R&B).
Seit 1.53.0: Musikwunschlisten – im Menü „Musikwunschlisten“ eine Liste pro Paar anlegen, Link per WhatsApp schicken; das Paar trägt Momente, Lieblingssongs, No-Gos und Musikrichtungen ein, du bekommst beim Abschicken eine E-Mail. Neue Ortsseite DJ Neu-Ulm (wird beim Einspielen angelegt); Ortsbilder ohne Nummer (z. B. event_biberach.jpg) werden jetzt angezeigt.
Seit 1.52.0: Songwünsche per QR-Code – im Menü „Songwünsche“ einen Abend starten, QR-Code herunterladen, Gäste schicken Wünsche, du siehst sie live (gleiche Wünsche werden gezählt, nach 14 Tagen gelöscht).
Seit 1.51.1: Kein weißer Rand mehr beim Zoomen auf dem iPhone (Seitenhintergrund dunkel, nichts ragt seitlich heraus); Datums-Check „Ist euer Datum noch frei?“ (1.51.0).
Seit 1.44.0: Teilen-Knopf an jeder Platte im DJ-Pult (Handy: Teilen-Menü, sonst Link kopieren/WhatsApp/Facebook), Zähler „Geteilt“ in der Mediathek; Sicherheitsheader (HSTS 30 Tage, nosniff, SAMEORIGIN, Referrer-Policy).
Seit 1.43.1: Paket-Buttons (und Preiszeile) stehen in jeder Spalte ganz unten auf gleicher Höhe.
Seit 1.43.0: DJ-Pult: fertige Automixe pro Genre (nach Tempo und Tonart sortiert, ein Klick startet), Direkt-Links ?song=ID (Song auf Deck A) und ?mix=Genre, „Link zum Teilen“ in der Mediathek.
Seit 1.42.1: Texte: Lightbar/Stative ca. 1,5 m, Kaution L mit Lieferung, Auf- und Abbau und Abholung, FAQ Paket L.
Seit 1.42.0: Bild-Reihenfolge pro Gerät/Paket: über den Dateinamen gefundene Bilder erscheinen im Feld „Bilder & Videos“, sortierbar per Ziehen oder ◀ ▶; gespeichert gilt genau diese Liste.
Seit 1.41.1: Paket L auch zur Selbstabholung (Kaution 1.000 €, mit Lieferung 300 €); Transport-Hinweis für M und L angepasst.
Seit 1.41.0: Geräte in den Paketen verlinkt – Info-Fenster mit Bild, Kurztext und Daten bei Mouse-over oder Klick (Technik- und Mietseite).
Seit 1.40.3: Technik-Pakete-Text mit Beratungshinweis.
Seit 1.40.2: Technik-Seite zeigt die Pakete als Technik zur DJ-Buchung (ohne Mietpreise/Mietkorb) mit „Mit Paket X anfragen“; das Kontaktformular übernimmt das Paket.
Seit 1.40.1: Pakete auch auf der Equipment-Seite (Technik), Mietkorb funktioniert dort ebenfalls; Liefer-FAQ mit Preisen.
Seit 1.40.0: Pakete S/M/L neu zusammengestellt (S 89/129 €, M 209/299 €, L 329/479 €), Zusatz Bose-Set zu L, neues Gerät Shure Beta 58A, Traverse mit 8 Haken, C-215 mit Distanzstange, Aktion mit Wert 150 €.
Seit 1.39.1: /favicon.ico wird direkt ausgeliefert (statt Weiterleitung), zusätzlich 192-px-PNG-Icon für Google.
Seit 1.39.0: Mietpreise mit Wochenendtarif (Fr 15 – Mo 21 Uhr, sobald Sa/So im Zeitraum), Kaution, Liefer- und Aufbaupauschalen; Mietkorb rechnet den Zeitraum aus.
Seit 1.38.0: Wash-Scheinwerfer = Cameo Thunder Wash 100 RGB (99 €); neues Gerät Eurolite Spiegelkugel 30 cm mit Motor MD-1515 (71 €) wird automatisch angelegt.
Seit 1.37.9: Nebelmaschine = Showlite SN-1200 (Daten, Neupreis 120 €, Kirstein-Link); UV-Strahler mit Anleitung.
Seit 1.37.8: KLS-Lightbar = Eurolite KLS Laser Bar FX-Set mit Stageworx BLS-315 Pro (Daten, Neupreis 366 €); Bose S1 Pro Neupreis aus Kaufbeleg (631 €).
Seit 1.37.7: Traverse = Stageworx LB-3 Lighting Stand Set Bundle (3 m, mit Taschen und 4 Haken): Daten, Neupreis 219 €, Herstellerseite.
Seit 1.37.6: Pioneer DDJ-FLX10: Neupreis 1.500 € (Kaufpreis).
Seit 1.37.5: LED-Laufschrift = Eurolite ESN Moving Message (65 cm): Daten, Neupreis 245 €, Herstellerseite.
Seit 1.37.4: Roadworx DJ Table (schwarz, mit Zwischenboden, nicht beleuchtet) und Roadworx Speakerstand 2: Daten, Neupreis, Herstellerseite; Paket L und Equipment-Seite angepasst.
Seit 1.37.3: Kirstein-Daten: Pronomic C-118SA (Maße, Gewicht, DSP, Neupreis 498 €), C-215 MA (269 €/Box, Strom-Ausgang), UHF-604 im Original-Karton, ALGAM im Lade-Case oder Koffer.
Seit 1.37.2: ALGAM EVENTPAR412-HEX-IP (6 Stück im Lade-Case, IP65): Daten, Neupreis; Bestand 8 → 6, Paket- und Aktionstexte angepasst.
Seit 1.37.1: Funkmikrofon-Set = Omnitronic UHF-604 (520–554 MHz), Daten und Neupreis.
Seit 1.37.0: Gerätedaten ergänzt: Bose S1 Pro, Bose Sub1, Stairville Tri Flat PAR (40°), Pronomic C-118SA (Beschreibung, Anschlüsse, Neupreis, Herstellerseite).
Seit 1.36.1: Hero Spot 60: Anleitungs-Link (schwarze Version, Thomann) aktualisiert, Wetterfestigkeit „Nur innen“.
Seit 1.36.0: Neues Gerätefeld „Herstellerseite“ (öffentlich als Link in den Gerätedetails); befüllt für DDJ-FLX10 (AlphaTheta), Hero Spot 60, Wild Wash UV, Pronomic C-215.
Seit 1.35.1: DDJ-FLX10: Bedienungsanleitung (DE) bei AlphaTheta statt alter Pioneer-Link, Firmware-Stand 1.14 als interne Notiz.
Seit 1.35.0: Anfrageformular direkt auf den Leistungsseiten (Abschnitt #anfrage, Anlass vorausgewählt); Buttons „Wunschtermin prüfen“ springen dorthin. Seiten neu einspielen.
Seit 1.34.0: Aktionen mit Enddatum (KJO_AKTIONEN): Hinweis-Kasten auf der Firmenfeier-Seite „Licht-Upgrade gratis“ bis 31.10.2026, Code WEIHNACHT26 wird ins Formular übernommen und Anfragen im Lead-System markiert.
Seit 1.33.0: Lead-System für DJ-Anfragen: Status (Neu bis Durchgeführt, Absagen), Pipeline-Board zum Ziehen, Angebotsbetrag, Wiedervorlage, Verlauf mit Notizen, Kalender-Kopplung (Gebucht = fester Termin), Dashboard-Kasten. Backup-Wächter für UpdraftPlus.
Seit 1.32.0: Video-Vorschaubilder: Medien → Bilder optimieren erzeugt sie per Klick aus dem Video; mit Vorschaubild lädt die Galerie ein Video erst beim Abspielen (spart am Handy mehrere MB).
Seit 1.31.0: Eigenes Anfrageformular „Wunschtermin prüfen“ statt WPForms: Anfragen werden unter „DJ-Anfragen“ gespeichert und per E-Mail geschickt, Kunde erhält Bestätigung, Wunschdatum mit Verfügbarkeit und „Als vorreserviert eintragen“; Tracking (generate_lead) unverändert. Bilder optimieren: sehr große Fotos verkleinert der Browser automatisch auf 2560 px.
Seit 1.30.1: Ortsseiten: Stadtbilder 30 % größer (520 px) mit goldenem Doppelrahmen und edlem Schatten; am Handy in voller Breite.
Seit 1.30.0: Eigene Bildoptimierung ohne Credits: Medien → „Bilder optimieren“ erzeugt Web-Versionen (WebP, max. 1600 px) für vorhandene Bilder, neue Uploads automatisch; die Website liefert nur noch die kleinen Versionen aus.
Seit 1.29.2: Pronomic C-215 MA als Set mit 2 Boxen, mit vollständigen Daten und Neupreis.
Seit 1.29.1: UV-Strahler mit Daten des Stairville Wild Wash 9x3W LED UV (thomann.de); recherchierte Gerätedaten werden zentral gepflegt und nur in leere Felder übernommen.
Seit 1.29.0: Geräteverwaltung mit eigenen Feldern für Breite, Länge und Höhe (mm, Volumen wird berechnet) sowie Neupreis/Wiederbeschaffungswert mit Preisquelle; Moving Head mit Daten des Varytec Hero Spot 60.
Seit 1.28.0: Galerie „Eindrücke“ als Karussell auf einer Höhe (Desktop 400 px, Handy 260 px) mit Pfeilen und Wischen, auf allen Seiten mit Eindrücken; wird direkt vom Plugin ausgeliefert. Bild-Text-Abschnitte stehen am Desktop wieder nebeneinander.
Seit 1.27.2: Startseite: Leistungs-Kacheln mit 400 px Bildhöhe, Fotos werden eingepasst statt beschnitten.
Seit 1.27.1: Startseite: Platten in der Plattenkiste mit goldenen Symbolen (Ringe, Torte, Sektgläser, Feuerwerk) und goldenem Titel; Event-Kachel nutzt das neue Feuerwerk-Symbol.
Seit 1.27.0: Überschrift passend zur Suchanzeige: Mit „kw={keyword}“ als URL-Suffix in Google Ads zeigen die Leistungsseiten z. B. „DJ für eure Weihnachtsfeier in Ulm“. Nur feste Wörter, nie Text aus der URL; ohne Parameter bleibt alles wie bisher.
Seit 1.26.3: Google-Unternehmensprofil verlinkt (Social-Symbole, Kontaktseite, strukturierte Daten „sameAs“ zusammen mit Instagram und Facebook). Seiten neu einspielen.
Seit 1.26.2: Technik mieten: Gerätebilder und Paketbilder per Klick groß ansehen (Vollbild, Blättern mit Pfeilen, Wischen oder Tastatur, Schließen mit × oder Esc).
Seit 1.26.1: Startseite: Leistungs-Kacheln mit einheitlicher Bildgröße; fehlt ein Foto, erscheint ein goldenes Symbol statt einer Lücke. „Mehr erfahren“ steht in allen Kacheln auf einer Höhe.
Seit 1.26.0: Geräte und Pakete: Bilder und Videos direkt aus der Mediathek wählen (Dateiname egal, Reihenfolge per Ziehen, erstes Bild = Vorschaubild). Knopf „PDF aus der Mediathek wählen“ bei der Anleitung funktioniert wieder.
Seit 1.25.0: Terminverwaltung (Admin „Kalender“): Monatsansicht, DJ-Auftritte, private Blocker und Vermietungen (fest/vorreserviert, Equipment sperren ja/nein/Auswahl), „Belegt an“ bei jedem Gerät, „Als vorreserviert eintragen“ in Mietanfragen. Verfügbarkeitshinweise im Wunschtermin-Formular und im Mietkorb. Privates iCal-Abo der Termine und stündlicher Import von iCal-Quellen (z. B. Google „DJ-Blocker“) unter Kalender → Abo & Import.
Seit 1.24.1: Kalender im DJ-Anfrageformular öffnet zuverlässig (WPForms-Styles hatten die Position des Kalenderfeldes überschrieben).
Seit 1.24.0: DJ-Pult „Meine Musik“: Display-Kasten über dem Mixer entfernt (Tonart-Anzeige bleibt als Zeile), Drehregler und FX-Knöpfe deutlich größer und leichter zu greifen; neuer Knopf ↺ zum Zurücksetzen des Versatzes auf „auto“.
Seit 1.23.0: DJ-Anfrageformular (WPForms): Das Feld „Wunschdatum“ öffnet einen Kalender; in die Anfrage kommt z. B. „Samstag, 14.11.2026“. Vergangene Tage sind gesperrt. Link „Noch kein festes Datum?“ trägt „noch offen – siehe Nachricht“ ein.
Seit 1.22.3: Mietanfrage: Fehlermeldung verschwindet, sobald das markierte Feld ausgefüllt ist; eigene Meldung bei leerer E-Mail (z. B. nicht übernommener Browser-Vorschlag); Autofill im dunklen Design.
Seit 1.22.2: Mietanfrage: Leere Datumsfelder sehen leer aus (Safari zeigt sonst das heutige Datum als Platzhalter), Fehler werden direkt am Feld markiert und angesprungen, Rückgabe wird beim Wählen des Beginns vorbelegt, keine Daten in der Vergangenheit.
Seit 1.22.1: Spaltenbreiten wieder korrekt (Elementor 4.3.4 übernimmt Breiten nur noch bei „volle Breite“) – Kacheln, Karten und Spalten stehen wieder nebeneinander. Neues Menü: Hochzeit · Geburtstag · Firmen · Events · Technik · Mieten · Über mich · Meine Musik (FAQ und Regionen im Handy-Menü und Footer), bricht nicht mehr um. Einmal „Seiten aus Vorlage einspielen“ und Zwischenspeicher leeren.
Seit 1.22.0: Neuer Admin-Bereich „Verleih“ (Geräte, Pakete, Mietanfragen, Einstellungen) mit Startbestand aus der Equipmentliste. Neue Seiten „Mein Equipment“ und „Musikanlage, Licht & Partyequipment mieten“ mit Paketen S/M/L, Equipment-Browser (Suche, Kategorien, Wetterfestigkeit, Anleitung DE mit „Link defekt? Melden“), Mietkorb und Mietanfrage (E-Mail an anfrage@dj-kolja-one.de, Bestätigung an den Kunden, Ereignis generate_lead). Preise und Kaution erscheinen nur, wenn eingetragen. Datenschutz um den Mietkorb ergänzt (wird automatisch eingespielt). Einmal „Seiten aus Vorlage einspielen“ klicken – die beiden neuen Seiten werden dabei angelegt.
Seit 1.21.7: Mediathek: Bei jedem Bild und Video der Website lässt sich eine eigene Höhe in px einstellen („Website: Höhe (px)“). Sie überschreibt die Standardhöhe von 400 px, die Breite folgt dem Seitenverhältnis – auch in den Galerien am Desktop. Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.21.6: Klick auf die E-Mail-Adresse kopiert sie zusätzlich in die Zwischenablage (Hinweis „E-Mail-Adresse kopiert“) und zählt als Conversion click_email. Instagram- und Facebook-Links öffnen immer in einem neuen Tab.
Seit 1.21.5: Conversion-Ereignisse für Google Analytics/Google Ads und Clarity: generate_lead (Formular abgeschickt), click_whatsapp, click_phone (abschaltbar mit kjo_conversions). Datenschutzerklärung um „Google Ads Conversion-Tracking“ ergänzt – wird beim ersten Dashboard-Aufruf nach dem Update automatisch eingespielt.
Seit 1.21.4: Datenschutzerklärung wird jetzt komplett aus der Vorlage übernommen und beim ersten Dashboard-Aufruf nach dem Update automatisch aktualisiert (neu: Microsoft Clarity, Betreiberangabe wie im Impressum; Google Analytics wie bisher). Der bisherige Text bleibt als Sicherung erhalten („Letzte Einspielung rückgängig“). Das Impressum bleibt unverändert.
Seit 1.21.3: „Meine Musik“ mit neuen Texten (Anrede „ihr“, neuer Abschnitt „Gefällt euch der Sound?“ mit Anfrage-Buttons direkt unter dem Pult). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.21.2: Einsatzgebiete mit neuen, kundenorientierten Texten (H1 mit Memmingen, Allgäu & Schwaben, Abschnitt „Anfahrt? Immer transparent.“). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.21.1: FAQ überarbeitet (klarere, handlungsorientierte Antworten, neue Frage zum kostenlosen Kennenlernen, Preise mit Basis- und Optionspaketen) – gilt auch für die FAQ auf Start-, Leistungs- und Ortsseiten. Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.21.0: Gestaltung kann nicht mehr „verloren gehen“: Elementor-CSS wird direkt in die Seite geschrieben statt als separate Datei (Einstellung „CSS-Ausgabemethode: Intern eingebettet“). Vorher konnte nach dem Leeren des Zwischenspeichers eine Seite ohne Gestaltung erscheinen (weiß, Menü als Liste) – auch in Microsoft-Clarity-Aufzeichnungen. Nach dem Update einmal das Dashboard öffnen; Zwischenspeicher wird automatisch geleert. Abschaltbar mit dem Filter kjo_css_inline.
Seit 1.20.9: Kontaktseite mit neuen, kundenorientierten Texten. Datenschutz-Vorlage um Cookies/Einwilligung und Microsoft Clarity ergänzt (Text im WordPress von Hand übernehmen). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.20.8: Alle acht Ortsseiten mit neuen, kundenorientierten Texten (Kurze Wege, Bewertungen, neue Reihenfolge). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.20.7: „Über mich“ mit neuen, persönlichen Texten (Radio seit 1996, besondere Events, Hobbys) und neuer Reihenfolge. Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.20.6: Event-Seite mit neuen, kundenorientierten Texten und neuer Reihenfolge (wie die anderen Leistungsseiten). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.20.5: Firmenfeier-Seite mit neuen, kundenorientierten Texten und neuer Reihenfolge (wie Hochzeit und Geburtstag). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.20.4: Geburtstagsseite mit neuen, kundenorientierten Texten und neuer Reihenfolge (wie die Hochzeitsseite). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.20.3: Leistungs-Kacheln stehen am Handy und Tablet nebeneinander (seitlich wischen) statt untereinander. Videos mit Vorschaubild zeigen bis zum Abspielen das Bild randlos im Rahmen – kein Schwarz mehr. Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.20.2: Hochzeitsseite mit neuen, kundenorientierten Texten und neuer Reihenfolge (H1 mit Region, „Was ihr davon habt“, Bewertungen weiter oben). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.20.1: Startseite mit neuen, kundenorientierten Texten und neuer Reihenfolge (Leistungen → Was ihr davon habt → Bewertungen → Vorstellung → Ablauf → FAQ → Einsatzgebiete → Abschluss → Kontakt). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.20.0: Alle Bilder und Videos (Porträt, Kacheln, Textbilder, Galerie am Desktop): Höhe genau 400 px, Breite im Seitenverhältnis des Mediums, Rahmen exakt ums Bild ohne Schwarz; auf schmalen Bildschirmen passt sich die Breite an. Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.19.9: Start-Kacheln: Der Rahmen passt exakt zum Bild bzw. Video (kein Schwarz mehr), Höhe höchstens ca. 290 px, Breite höchstens 420 px. Zwischenspeicher leeren und hart neu laden.
Seit 1.19.8: Start-Kacheln: Bild mittig, höchstens 420 px breit und nicht mehr abgeschnitten (echtes Seitenverhältnis). Zwischenspeicher leeren und hart neu laden.
Seit 1.19.7: Start-Kacheln: Bild bzw. Video füllt den Rahmen immer komplett (3:2, höchstens 420 px breit) – keine schwarzen Flächen, nicht mehr riesig. Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.19.6: Am Mac/Desktop sind die Bilder deutlich kleiner: Porträt max. 260 px breit, Galerie-Bilder und -Videos je 240 px breit (mittig). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.19.5: Alle Bilder (Kacheln, Textbilder, Porträt) übernehmen das echte Seitenverhältnis des Fotos und werden nicht mehr zugeschnitten. Zwischenspeicher leeren und hart neu laden.
Seit 1.19.4: Galerien (Start, Über mich, Leistungsseiten): Bilder und Videos stehen am Handy mittig, egal wie viele es sind (ein einzelnes Bild nicht mehr links). Einmal „Seiten aus Vorlage einspielen“ klicken.
Seit 1.19.3: Alt-Texte für alle Bilder und Videos (Porträt, Kacheln, Textbilder, Galerien) – für Google, Barrierefreiheit und Bildersuche. Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.19.2: Startseite: Die Überschrift (H1) lautet „Premium DJ für Hochzeiten & Events in Memmingen, Allgäu & Schwaben“. Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.19.1: Titel und Kopfzeilen nennen überall „Memmingen, Allgäu & Schwaben“ (z. B. „Hochzeits-DJ Memmingen, Allgäu & Schwaben | DJ KOLJA ONE“). Einmal „Seiten aus Vorlage einspielen“ klicken, Zwischenspeicher leeren.
Seit 1.19.0: Seitentitel, Meta-Beschreibung und Social-Vorschau (Open Graph) je Seite mit Region und Anlass. Entfällt, wenn Yoast/Rank Math/AIOSEO/SEOPress aktiv ist; abschaltbar mit kjo_seo_aktiv. Zwischenspeicher leeren.
Seit 1.18.9: Alle Bilder (Start-Kacheln, Textbilder, Porträt) haben den Goldrahmen mit Schatten wie das Porträt auf „Über mich“. Zwischenspeicher leeren und hart neu laden.
Seit 1.18.8: Strukturierte Daten (JSON-LD) für Google: Unternehmen, Leistungen, FAQ und Brotkrumen je Seite. Abschaltbar mit dem Filter kjo_schema_aktiv. Zwischenspeicher leeren.
Seit 1.18.7: Bilder und Videos werden auch mit doppelter Endung erkannt (z. B. start_events.jpg.png), die Grenze liegt bei 2000 Mediendateien statt 800. Zwischenspeicher leeren.
Seit 1.18.6: Start und Über mich: Der Rahmen des Porträts übernimmt das echte Seitenverhältnis des hochgeladenen Fotos – es wird nicht mehr beschnitten (Kopf bleibt im Bild). Zwischenspeicher leeren und hart neu laden.
Seit 1.18.5: Start und Über mich: Das Porträt ist breiter (5:4), beschnitten wird nur noch unten, dazu ein dezenter Goldrahmen mit Schatten. Am Handy 280 px breit. Einmal „Seiten aus Vorlage einspielen“ klicken.
Seit 1.18.4: Start und Über mich: Das Porträt ist bei schmaleren Fenstern (Tablet, kleines Browserfenster, Handy) jetzt wirklich klein (240 px breit, mittig); die Größe galt vorher nicht. Einmal „Seiten aus Vorlage einspielen“ und „Zwischenspeicher leeren“ klicken.
Seit 1.18.3: Start und Über mich: Das Porträt ist kleiner – am Desktop ein Drittel der Breite, am Handy höchstens 300 px. Einmal „Seiten aus Vorlage einspielen“ klicken.
Seit 1.18.2: Startseite: Das Porträt (kolja_portrait.jpg) steht ebenfalls im Hochformat 4:5. Einmal „Seiten aus Vorlage einspielen“ klicken.
Seit 1.18.1: Über mich: Das Porträt (kolja_portrait.jpg) steht im Hochformat 4:5 und wird nicht mehr breit abgeschnitten. Einmal „Seiten aus Vorlage einspielen“ klicken.
Seit 1.18.0: Meine Musik: Neben dem BROWSE-Knopf steht ein „Versatz“-Regler (− / +, Schritte à 20 ms; Doppelklick auf den Wert = automatisch). Er verschiebt die rote Linie und die Wellenform, wenn sie bei Bluetooth-Kopfhörern oder Lautsprechern dem Ton hinterherläuft; der Wert wird im Browser gemerkt. Ohne Einstellung gleicht der Player die vom Gerät gemeldete Ausgabeverzögerung selbst aus. Fußzeile: Im Bereich „Info“ steht „Über mich“ vor „Meine Musik“. Einmal „Seiten aus Vorlage einspielen“ klicken.
Seit 1.17.6: Meine Musik: KEY ist beim Start wieder eingeschaltet (Tonart bleibt beim Tempo-Ändern erhalten), SYNC bleibt aus.
Seit 1.17.4: Meine Musik: Beim Start eines Titels läuft der Ton sofort mit voller Geschwindigkeit an, statt die Abspielgeschwindigkeit in vielen kleinen Schritten hochzufahren (das ließ Safari am Anfang ruckeln). Die Platte dreht weiter sanft hoch.
Seit 1.17.3: Meine Musik: Die Wellenformen laufen flüssig mit. Safari meldet die Abspielzeit nur ruckweise, die Anzeige rechnet jetzt dazwischen mit der Systemuhr weiter, die rote Linie sitzt dadurch genau auf der gespielten Stelle. Zeichnen wieder mit voller Bildrate.
Seit 1.17.2: Meine Musik: Die aktuelle Abspielstelle ist in den Wellenformen eine rote Linie (auch in der Überblicksleiste).
Seit 1.17.1: Meine Musik: Die Wellenformen sitzen wieder außerhalb des Controllers – direkt über ihm, unter dem BROWSE-Knopf, in voller Controller-Breite. Die Mixer-Regler stehen wieder an ihren alten Plätzen.
Seit 1.17.0: Neuer Bereich „Reihenfolge im Pult“ unter Medien → Plattenkiste: Genres und die Songs innerhalb eines Genres lassen sich mit ▲ ▼ (und „A–Z“) sortieren; wird sofort gespeichert. Im Pult und in der Plattenkiste erscheinen die Genres in dieser Reihenfolge (vorher alphabetisch). Neue Genres stehen zunächst am Ende.
Seit 1.16.3: Meine Musik: Die Meldung zur Decksperre erscheint jetzt auch im BROWSE-Dialog (vorher war sie dort verdeckt).
Seit 1.16.2: Meine Musik: Wellenformen doppelt so hoch und über die volle Mixerbreite (ganz oben im Mixer), deutlicheres Beatgrid (kräftigere Beat-Linien, Taktanfang mit Markierung). Ruhigeres Abspielen: Titel werden beim Laden komplett in den Speicher geholt, die Wellenform wird mit 30 Bildern/s gezeichnet, eine Live-Berechnung startet erst, wenn kein Deck läuft. Fader und Pegelanzeige sitzen außen neben den Reglern.
Seit 1.16.1: Springen in den Wellenformen ist quantisiert (rastet auf den nächsten Taktschlag des Beatgrids ein). Meine Musik: Abschlussbox „Spielst Du unsere Lieblingssongs?“. Fußzeile: Die Copyright-Zeile bricht am Mac nicht mehr um und steht auf einer Höhe mit Impressum/Datenschutz. Navigation: größere Schrift am Desktop, „Über mich“ steht vor „Meine Musik“. Einmal „Seiten aus Vorlage einspielen“ klicken.

Seit 1.16.0: DJ-Pult: Titel werden nur noch in ein Deck GELADEN und starten erst mit Play. Läuft ein Deck, erscheint beim Laden eines anderen Titels dorthin eine Meldung (Decksperre) – erst anhalten, dann laden. Der Mixer hat nur noch die Kanäle von Deck A und B; Knöpfe ohne Funktion (Kanal 3/4, Zierknöpfe) sind entfernt, die Pads bleiben. Im oberen Mixerbereich zeigen zwei übereinanderliegende RGB-Wellenformen (Bass rot, Mitten grün, Höhen blau) mit Beatgrid die beiden Decks, darunter je ein Überblick des ganzen Titels; per Klick oder Ziehen springt man an die genaue Stelle. Wellenform und Beatgrid (genaues Tempo, erster Schlag, Taktbeginn) werden beim Upload zusammen mit BPM und Tonart im Browser des Admins berechnet und in der Plattenkiste gespeichert (rund 15 KB je Titel); vorhandene Songs werden einmalig automatisch nachanalysiert (Mediathek öffnen). Fehlt sie noch, berechnet das Pult sie beim Laden einmalig selbst.

Seit 1.15.4: Fußzeile am Handy: Die Links Impressum / Datenschutz / Cookie-Richtlinie haben keinen Innenabstand mehr und stehen damit bündig links unter der Copyright-Zeile. Einmal „Seiten aus Vorlage einspielen“ klicken.

Seit 1.15.3: Einsatzgebiete: Der Kennzahlen-Block (Fellheim, 8 Städte …) entfällt; die Abschlussbox heißt „Wunschtermin verfügbar? Jetzt unverbindlich anfragen.“ Fußzeile am Handy: Die Copyright-Zeile steht linksbündig, bündig mit Impressum/Datenschutz. Einmal „Seiten aus Vorlage einspielen“ klicken.

Seit 1.15.2: „Seiten aus Vorlage einspielen“ erfasst jetzt auch Impressum und Datenschutz – dort wird nur die Fußzeile (mit Instagram/Facebook) ersetzt; der vorhandene Text der Seiten bleibt unverändert.

Seit 1.15.1: Meine Musik: „So geht’s“ beschreibt jetzt die vorhandenen Funktionen (BROWSE, A/B, Sync/KEY, Automix, Video, Bewertung). Instagram (zuerst) und Facebook (danach) stehen als goldene runde Symbole in der Fußzeile und als Karten „DJ KOLJA ONE“ auf der Seite Kontakt. Die Seiten Start, Meine Musik, FAQ und Kontakt werden jetzt auch von „Seiten aus Vorlage einspielen“ erfasst.

Seit 1.15.0 (Plattenkiste): Statt eines Play-Knopfes hat jede Platte jetzt ein Paar [▸A | ▸B] zum gezielten Laden auf Deck A oder B.

Seit 1.15.0: Neuer Knopf „BROWSE · Titel laden“ am Controller: Ein Fenster zeigt alle Titel als Liste (Symbol, Titel, BPM, Camelot, Tonart, Genre, Album) wie in Rekordbox. Ein Klick auf eine Spaltenüberschrift sortiert aufsteigend/absteigend (Pfeil zeigt die Richtung), dazu eine Suche. Die Knöpfe [▸A | ▸B] legen den Titel auf Deck A bzw. B (das belegte Deck leuchtet golden; nochmal tippen = Pause/Play), ☰+ legt ihn in den Automix; Schließen mit ✕, Esc oder Klick daneben. Das Album kommt aus den MP3-Tags (ID3).

Seit 1.14.0: Plattenkiste: Jede Platte hat jetzt zwei klar getrennte Knöpfe – ▶ (gold) zum selbst Auflegen und Mixen, ☰+ (weiß) zum Hinzufügen zum Automix (danach ✓ mit der Position). Eine Hinweiszeile über der Kiste erklärt beide Symbole; die Platten sind etwas höher, damit die Knöpfe Platz haben.

Seit 1.13.7: iPhone/Safari: Kommt nach dem Start eines Songs 5 Sekunden lang kein Ton an (Streaming hängt), lädt das Pult die Datei komplett vor und startet sie dann. Das Diagnose-Protokoll zeigt zusätzlich loadedmetadata, canplay, playing, suspend sowie readyState/networkState und das Ergebnis des Abrufs.

Seit 1.13.6: „Meine Musik“ am Handy: Der Laptop über dem Controller wird oben nicht mehr abgeschnitten. Ursache war der unsichtbare Rest des Kopf-Abschnitts (leere Abstandhalter), der über das Pult ragte; er wird jetzt eingeklappt, und der Kopf-Abschnitt kann das Pult nie mehr überdecken.

Seit 1.13.5: Startseite: Die Bilderreihe unter dem Pult ist jetzt die Galerie (start_1 … start_8, Bild oder Video, nur gefüllte Plätze; ein einzelnes Video steht in natürlicher Größe statt gestreckt). Kennzahl „Süddeutschland & Überregional – Allgäu, Schwaben & Auf Anfrage“. Einsatzgebiete: neue Region „Überregional“ (exklusive Events und Locations in Deutschland und international, auf Anfrage). Einmal „Seiten aus Vorlage einspielen“ klicken.

Seit 1.13.4: Bild-/Video-Platzhalter auf allen Seiten (Kacheln der Leistungen, Textbilder, Bilderreihe der Startseite) werden nur noch angezeigt, wenn es dazu eine Datei in der Mediathek gibt – sonst entfällt der Platz; Textspalten neben einem leeren Bild nutzen die Breite. Das Ausblenden greift sofort; die Breite der Textspalten und die Startseiten-Bilderreihe brauchen einmal „Seiten aus Vorlage einspielen“ (Medien → Plattenkiste).

Seit 1.13.3: Auch die Ortsseiten (DJ Memmingen, Ulm, Biberach, Ravensburg, Kempten, Füssen, Kaufbeuren, Landsberg), „Über mich“ und „Einsatzgebiete“ bekommen die Galerie und zeigen die Kennzahlen dezent weiter unten. Ortsseiten: Platz n = event_<ort>_n (z. B. event_memmingen_1), sonst gemeinsam event_region_n. „Über mich“: ueber_1 … ueber_8. Der Knopf heißt jetzt „Seiten aus Vorlage einspielen“.

Seit 1.13.2: Der automatisch eingeblendete GEMA-Hinweis auf Galerie-Videos ist wieder entfernt (den Hinweis bringst du bei Bedarf direkt im Video an; Videos mit Ton spielen im großen Player mit Ton).

Seit 1.13.1: Die Galerie auf den Leistungsseiten zeigt bis zu 8 Platzhalter (event_<seite>_1 … _8), je Bild oder Video, und nur die, zu denen es eine Datei gibt. Die Bilder-Reihe unter dem Textbild ist entfallen; das Bild neben dem Text heißt jetzt event_<seite>_text.

Seit 1.13.0: Die Leistungsseiten (Hochzeit, Geburtstag, Firmenfeier, Event) bekommen oben eine Video-Galerie (Play-Button, Klick öffnet groß, Ton nur wenn vorhanden); die Kennzahlen stehen dezent weiter unten. Eingespielt wird die neue Fassung per Knopf unter Medien → Plattenkiste („Leistungsseiten aus Vorlage einspielen“, mit Sicherung und „Letzten Stand wiederherstellen“).

Seit 1.12.5: Der Untertitel auf „Meine Musik“ wird nicht mehr vom Pult überdeckt (weiße Reste weg). Safari: Der nächste Titel wird komplett vorab geladen, der Mix startet erst, wenn er spielbereit ist. Dialog auf der Startseite (z. B. „Hochzeit“): das große weiße Kreuz und Dreieck sind weg; das Start-Pult kommt jetzt aus dem Plugin.

Seit 1.12.4: Automix in Safari: Das Tempo gleitet nach dem Mix nur noch in wenigen groben Schritten (erst nach 10 s) zurück, statt zehnmal pro Sekunde; die Datei des nächsten Titels wird erst 4 s nach dem Mix geladen (die Anzeige wechselt sofort). Unter dem Automix gibt es einen Link „Diagnose“ mit einem Protokoll der Medien-Ereignisse (play, pause, waiting, error …) – zum Eingrenzen von Problemen.

Seit 1.12.3: Weiße Artefakte über dem Controller beseitigt: der bewegte Controller trägt keinen CSS-/SVG-Filter mehr (Schatten statisch, Leuchten über Farbe und Strichstärke). Der Abstand zwischen Text und Pult wird aus den Layout-Positionen gemessen, nicht aus animierten Bildschirmpositionen.

Seit 1.12.3 (Automix): Automix: Der nächste Titel erscheint sofort auf dem freien Deck (nicht erst kurz vor dem Mix). Safari/iPhone: Das zweite Deck wird beim Tippen auf „+“ bzw. „Automix starten“ für das automatische Abspielen freigeschaltet; blockiert der Browser den Start trotzdem, erscheint der Knopf „Song freigeben“ – ein Tipp genügt.

Seit 1.12.2: Automix steht jetzt rechts neben der Plattenkiste, die Titel untereinander (auf dem Handy als einklappbare Liste). Die Platten ziehen weniger weit heraus und überdecken die Genre-Überschriften nicht mehr. Der Abstand zwischen Einleitungstext und DJ-Pult wird gemessen und ausgeglichen. Nach dem Deploy leert die Seite ihren Zwischenspeicher automatisch.

Seit 1.12.2 (Zwischenspeicher): Nach jedem Update werden Elementor- und gängige Cache-Plugin-Zwischenspeicher einmalig geleert (sobald jemand das Dashboard öffnet), damit neue Pult-Versionen sofort erscheinen; Knopf „Zwischenspeicher leeren“ unter Medien → Plattenkiste. Die Lücke auf „Meine Musik“ wird jetzt unabhängig vom Seitenaufbau entfernt.

Seit 1.12.1: Klang und Laufruhe des Players verbessert: größerer Audio-Puffer (weniger Aussetzer), Limiter gegen Übersteuern beim Mixen, exakte Wiedergabegeschwindigkeit ohne Umrechnung, Filter in Neutralstellung ohne Höhenverlust; die Anzeige schreibt rund 94 % weniger Änderungen in die Seite und lässt dem Ton mehr Rechenzeit. Auf „Meine Musik“ ist die schwarze Lücke zwischen Einleitungstext und DJ-Pult entfernt.

Seit 1.12.0: Tempo-Regler an beiden Decks (±16 %), SYNC-Knopf (gleicht das Tempo an das andere Deck an, auch halbes/doppeltes Tempo) und KEY-Knopf (Key-Lock: Tonart bleibt beim Tempo-Ändern gleich). Automix: Mit dem + auf den Platten legst du Songs in eine Playlist; „Automix starten“ lädt sie nacheinander auf die Decks und mixt sie mit Tempo-Angleich, Überblendung und Bass-Tausch. Sobald du an Crossfader, Fadern, Tempo, Sync oder einer Platte eingreifst, übernimmst du manuell (die Decks laufen weiter); „Automix fortsetzen“ übergibt wieder. Auf der Seite „Meine Musik“ entfallen die beiden Hero-Buttons. Auf dem Handy erscheint beim Scrollen ein Menü-Knopf (Hamburger) für die Unterseiten.

Seit 1.11.0: Tonart-Erkennung (Camelot-System). Die Tonart wird beim Upload automatisch zusammen mit der BPM erkannt, am Deck und auf der Platte angezeigt; der Mixer zeigt, ob die beiden Songs harmonisch zusammenpassen (z. B. „8A + 9A · PASST“). In der Plattenkiste tragen die Platten Tonart und BPM, passende Songs sind grün/gelb markiert, der Knopf „Passt zu …“ blendet unpassende aus. Bestehende Songs werden einmalig automatisch nachanalysiert.
